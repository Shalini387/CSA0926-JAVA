package scenario;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Scenario {

    private final String id;
    private final String category;
    private final String title;
    private final String description;
    private final String difficulty;
    private final List<ScenarioCard> correctCards;
    private final List<ScenarioCard> distractorCards;
    private final String explanation;

    public Scenario(
            String id,
            String category,
            String title,
            String description,
            String difficulty,
            List<ScenarioCard> correctCards,
            List<ScenarioCard> distractorCards,
            String explanation
    ) {
        this.id = id;
        this.category = category;
        this.title = title;
        this.description = description;
        this.difficulty = difficulty;
        this.correctCards = correctCards;
        this.distractorCards = distractorCards;
        this.explanation = explanation;
    }

    public String getId() {
        return id;
    }

    public String getCategory() {
        return category;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public List<ScenarioCard> getCorrectCards() {
        return correctCards;
    }

    public List<ScenarioCard> getDistractorCards() {
        return distractorCards;
    }

    public String getExplanation() {
        return explanation;
    }

    public List<ScenarioCard> getAllCardsShuffled() {
        List<ScenarioCard> combined = new ArrayList<>();
        combined.addAll(correctCards);
        combined.addAll(distractorCards);
        Collections.shuffle(combined);
        return combined;
    }

    public int getCorrectCount() {
        return correctCards.size();
    }
}
