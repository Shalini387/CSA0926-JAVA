package scenario;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ScenarioDatabase {

    private static final List<Scenario> EASY_SCENARIOS = new ArrayList<>();
    private static final List<Scenario> MEDIUM_SCENARIOS = new ArrayList<>();
    private static final List<Scenario> HARD_SCENARIOS = new ArrayList<>();

    static {
        // =====================================================================
        // EASY SCENARIOS (Simple everyday situations — Pick 2 out of 6)
        // =====================================================================

        // 1. Rainy Day
        EASY_SCENARIOS.add(new Scenario(
                "EASY_1",
                "Weather & Daily Life",
                "Rainy Commute",
                "It is raining heavily outside and you are going to college. Which 2 items would be useful?",
                "EASY",
                Arrays.asList(
                        new ScenarioCard("e1_c1", "Umbrella", "umbrella", true, "Protects from rain overhead."),
                        new ScenarioCard("e1_c2", "Raincoat", "raincoat", true, "Keeps clothes and body dry.")
                ),
                Arrays.asList(
                        new ScenarioCard("e1_d1", "Sunglasses", "sunglasses", false, "Not helpful in heavy rain."),
                        new ScenarioCard("e1_d2", "Football", "football", false, "Not needed for rain protection."),
                        new ScenarioCard("e1_d3", "Pillow", "pillow", false, "Belongs in bed, not in the rain."),
                        new ScenarioCard("e1_d4", "Ice Cream", "ice_cream", false, "Not a rain gear item.")
                ),
                "Umbrella and Raincoat are essential items to protect you and your clothes from heavy rain!"
        ));

        // 2. Sunny Beach Trip
        EASY_SCENARIOS.add(new Scenario(
                "EASY_2",
                "Outdoor & Summer",
                "Sunny Beach Day",
                "You are going to the beach on a sunny day. Which 2 items are useful?",
                "EASY",
                Arrays.asList(
                        new ScenarioCard("e2_c1", "Sunglasses", "sunglasses", true, "Protects eyes from bright sunlight."),
                        new ScenarioCard("e2_c2", "Sunscreen", "sunscreen", true, "Protects skin from sunburn.")
                ),
                Arrays.asList(
                        new ScenarioCard("e2_d1", "Pillow", "pillow", false, "Not needed for sun protection."),
                        new ScenarioCard("e2_d2", "Raincoat", "raincoat", false, "Too warm for a sunny beach day."),
                        new ScenarioCard("e2_d3", "Notebook", "notebook", false, "Not suitable for beach swimming."),
                        new ScenarioCard("e2_d4", "Winter Gloves", "winter_gloves", false, "Used in snow, not on the beach.")
                ),
                "Sunglasses and Sunscreen protect your eyes and skin from strong summer sunshine at the beach!"
        ));

        // 3. Morning School Prep
        EASY_SCENARIOS.add(new Scenario(
                "EASY_3",
                "School & Study",
                "Morning School Prep",
                "You are going to school in the morning. Which 2 things should you take?",
                "EASY",
                Arrays.asList(
                        new ScenarioCard("e3_c1", "School Bag", "school_bag", true, "Carries books and stationery."),
                        new ScenarioCard("e3_c2", "Notebook", "notebook", true, "For writing class notes.")
                ),
                Arrays.asList(
                        new ScenarioCard("e3_d1", "Goggles", "goggles", false, "For swimming pool, not regular class."),
                        new ScenarioCard("e3_d2", "Frying Pan", "frying_pan", false, "Kitchen utensil, not school gear."),
                        new ScenarioCard("e3_d3", "Helmet", "helmet", false, "For cycling or sports safety."),
                        new ScenarioCard("e3_d4", "Beach Towel", "towel", false, "Not needed for daily school lessons.")
                ),
                "A school bag and notebooks are primary essentials for daily classes and study!"
        ));

        // 4. Thirsty After Sports
        EASY_SCENARIOS.add(new Scenario(
                "EASY_4",
                "Health & Hydration",
                "Thirsty After Playing",
                "You are feeling thirsty after playing sports outside. Which 2 choices are appropriate?",
                "EASY",
                Arrays.asList(
                        new ScenarioCard("e4_c1", "Water Bottle", "water_bottle", true, "Contains clean drinking water."),
                        new ScenarioCard("e4_c2", "Glass of Water", "glass_water", true, "Hydrates and cools your body.")
                ),
                Arrays.asList(
                        new ScenarioCard("e4_d1", "Laptop", "laptop", false, "An electronic device, not a drink."),
                        new ScenarioCard("e4_d2", "Raincoat", "raincoat", false, "Clothing item, does not hydrate."),
                        new ScenarioCard("e4_d3", "Pillow", "pillow", false, "For sleeping, not thirst."),
                        new ScenarioCard("e4_d4", "Toy Car", "toy_car", false, "A toy, cannot be consumed.")
                ),
                "Clean drinking water in a glass or bottle is the best and healthiest way to quench your thirst!"
        ));

        // 5. Bedtime Routine
        EASY_SCENARIOS.add(new Scenario(
                "EASY_5",
                "Daily Routine",
                "Getting Ready for Sleep",
                "You are getting ready to sleep in bed at night. Which 2 items do you need?",
                "EASY",
                Arrays.asList(
                        new ScenarioCard("e5_c1", "Soft Pillow", "pillow", true, "Supports head comfortably during sleep."),
                        new ScenarioCard("e5_c2", "Warm Blanket", "blanket", true, "Keeps you cozy and warm at night.")
                ),
                Arrays.asList(
                        new ScenarioCard("e5_d1", "Football", "football", false, "Outdoor sports gear, not for sleep."),
                        new ScenarioCard("e5_d2", "Sunglasses", "sunglasses", false, "For bright daytime sun."),
                        new ScenarioCard("e5_d3", "Frying Pan", "frying_pan", false, "Belongs in the kitchen."),
                        new ScenarioCard("e5_d4", "Bicycle", "bicycle", false, "Vehicle for outdoor riding.")
                ),
                "A soft pillow and cozy blanket ensure restful, comfortable sleep every night!"
        ));

        // 6. Art & Drawing
        EASY_SCENARIOS.add(new Scenario(
                "EASY_6",
                "Creative Arts",
                "Drawing a Picture",
                "You want to draw and color a beautiful scenery picture. Which 2 tools do you need?",
                "EASY",
                Arrays.asList(
                        new ScenarioCard("e6_c1", "Drawing Book", "notebook", true, "Blank paper canvas for artwork."),
                        new ScenarioCard("e6_c2", "Color Crayons", "crayons", true, "Adds vibrant colors to drawings.")
                ),
                Arrays.asList(
                        new ScenarioCard("e6_d1", "Winter Gloves", "winter_gloves", false, "Makes holding pencils difficult."),
                        new ScenarioCard("e6_d2", "Umbrella", "umbrella", false, "Used for rainy weather outside."),
                        new ScenarioCard("e6_d3", "Frying Pan", "frying_pan", false, "Kitchen cooking tool."),
                        new ScenarioCard("e6_d4", "Football", "football", false, "Sporting ball, not for drawing.")
                ),
                "A drawing book and vibrant crayons give you everything you need to create art!"
        ));

        // 7. Swimming Pool Fun
        EASY_SCENARIOS.add(new Scenario(
                "EASY_7",
                "Sports & Recreation",
                "Swimming Pool Visit",
                "You are going for a swim in the swimming pool. Which 2 items are useful?",
                "EASY",
                Arrays.asList(
                        new ScenarioCard("e7_c1", "Swimming Goggles", "goggles", true, "Protects eyes underwater."),
                        new ScenarioCard("e7_c2", "Beach Towel", "towel", true, "Dries you off after swimming.")
                ),
                Arrays.asList(
                        new ScenarioCard("e7_d1", "Winter Gloves", "winter_gloves", false, "Gets soaked and heavy in water."),
                        new ScenarioCard("e7_d2", "Notebook", "notebook", false, "Paper gets damaged in pool water."),
                        new ScenarioCard("e7_d3", "Umbrella", "umbrella", false, "Not used while swimming in a pool."),
                        new ScenarioCard("e7_d4", "Pillow", "pillow", false, "Not needed for swimming in pool.")
                ),
                "Swimming goggles protect your eyes from pool water and a towel dries you off afterwards!"
        ));

        // =====================================================================
        // MEDIUM SCENARIOS (Thoughtful situations — Pick 2 out of 6)
        // =====================================================================

        // 8. Forest Camping
        MEDIUM_SCENARIOS.add(new Scenario(
                "MED_1",
                "Adventure & Outdoor",
                "Forest Night Camping",
                "You are setting up camp in the forest at night. Which 2 items are essential for shelter and vision?",
                "MEDIUM",
                Arrays.asList(
                        new ScenarioCard("m1_c1", "Camping Tent", "tent", true, "Provides safe overnight shelter in the wild."),
                        new ScenarioCard("m1_c2", "Flashlight Torch", "flashlight", true, "Provides clear illumination in pitch darkness.")
                ),
                Arrays.asList(
                        new ScenarioCard("m1_d1", "Laptop", "laptop", false, "Unnecessary electronic for forest sleep."),
                        new ScenarioCard("m1_d2", "Swimming Goggles", "goggles", false, "Not needed on dry land in forest."),
                        new ScenarioCard("m1_d3", "Sunglasses", "sunglasses", false, "Nighttime is already dark."),
                        new ScenarioCard("m1_d4", "Ice Cream", "ice_cream", false, "Melts quickly without refrigeration.")
                ),
                "A sturdy tent provides shelter from the elements and a flashlight ensures night vision!"
        ));

        // 9. First Aid Scrape
        MEDIUM_SCENARIOS.add(new Scenario(
                "MED_2",
                "Health & First Aid",
                "Knee Scrape First-Aid",
                "You scraped your knee while playing soccer in the park. Which 2 first-aid items should you use?",
                "MEDIUM",
                Arrays.asList(
                        new ScenarioCard("m2_c1", "Antiseptic Lotion", "antiseptic", true, "Cleans wound and prevents infection."),
                        new ScenarioCard("m2_c2", "Adhesive Bandage", "bandage", true, "Covers and protects the scrape.")
                ),
                Arrays.asList(
                        new ScenarioCard("m2_d1", "Sunglasses", "sunglasses", false, "Does not treat physical injuries."),
                        new ScenarioCard("m2_d2", "School Bag", "school_bag", false, "Not a medical supply."),
                        new ScenarioCard("m2_d3", "Ice Cream", "ice_cream", false, "Sweet food, not antiseptic care."),
                        new ScenarioCard("m2_d4", "Umbrella", "umbrella", false, "Weather gear, not medical treatment.")
                ),
                "Disinfecting the scrape with antiseptic lotion and covering it with a bandage ensures safe healing!"
        ));

        // 10. Cooking Breakfast
        MEDIUM_SCENARIOS.add(new Scenario(
                "MED_3",
                "Cooking & Kitchen",
                "Cooking Pancakes for Breakfast",
                "You are in the kitchen preparing delicious hot pancakes for breakfast. Which 2 tools do you need?",
                "MEDIUM",
                Arrays.asList(
                        new ScenarioCard("m3_c1", "Frying Pan", "frying_pan", true, "Heats and cooks the pancake batter evenly."),
                        new ScenarioCard("m3_c2", "Cooking Spatula", "spatula", true, "Flips the pancake safely without tearing.")
                ),
                Arrays.asList(
                        new ScenarioCard("m3_d1", "Pillow", "pillow", false, "Bedding item, flammable in kitchen."),
                        new ScenarioCard("m3_d2", "Swimming Goggles", "goggles", false, "Not used for stove cooking."),
                        new ScenarioCard("m3_d3", "Winter Coat", "winter_coat", false, "Too bulky and warm near hot stove."),
                        new ScenarioCard("m3_d4", "Safety Helmet", "helmet", false, "Not needed for cooking breakfast.")
                ),
                "A flat frying pan and turning spatula are the classic culinary tools for perfect pancakes!"
        ));

        // 11. Freezing Winter Snow
        MEDIUM_SCENARIOS.add(new Scenario(
                "MED_4",
                "Winter & Weather",
                "Freezing Snowstorm",
                "It is freezing cold and snowing heavily outside. Which 2 clothing items will keep you warm?",
                "MEDIUM",
                Arrays.asList(
                        new ScenarioCard("m4_c1", "Winter Parka Coat", "winter_coat", true, "Heavy insulated coat protects against frost."),
                        new ScenarioCard("m4_c2", "Winter Gloves", "winter_gloves", true, "Keeps fingers warm and prevents frostbite.")
                ),
                Arrays.asList(
                        new ScenarioCard("m4_d1", "Sunglasses", "sunglasses", false, "Does not generate thermal warmth."),
                        new ScenarioCard("m4_d2", "Swimming Goggles", "goggles", false, "Used for swimming pool, not snow coat."),
                        new ScenarioCard("m4_d3", "Beach Towel", "towel", false, "Thin cotton, inadequate for freezing snow."),
                        new ScenarioCard("m4_d4", "Water Bottle", "water_bottle", false, "Water bottle does not warm the body.")
                ),
                "An insulated winter coat and thermal gloves are critical to stay warm and safe in freezing snow!"
        ));

        // 12. Bicycle Safety
        MEDIUM_SCENARIOS.add(new Scenario(
                "MED_5",
                "Sports & Safety",
                "Bicycle Road Safety",
                "You are going for a fast bicycle ride on the road. Which 2 safety items should you wear?",
                "MEDIUM",
                Arrays.asList(
                        new ScenarioCard("m5_c1", "Bicycle Helmet", "helmet", true, "Protects head from impact injury."),
                        new ScenarioCard("m5_c2", "Knee & Elbow Pads", "knee_pads", true, "Protects joints from road friction scrapes.")
                ),
                Arrays.asList(
                        new ScenarioCard("m5_d1", "Sleeping Blanket", "blanket", false, "Dangerous; can get caught in bicycle chain."),
                        new ScenarioCard("m5_d2", "Pillow", "pillow", false, "Unusable while cycling."),
                        new ScenarioCard("m5_d3", "Frying Pan", "frying_pan", false, "Kitchen item, unrelated to cycling."),
                        new ScenarioCard("m5_d4", "Raincoat", "raincoat", false, "Not needed in clear dry cycling conditions.")
                ),
                "Wearing a certified helmet and protective joint pads prevents serious injuries during bicycle rides!"
        ));

        // 13. Gardening Flowers
        MEDIUM_SCENARIOS.add(new Scenario(
                "MED_6",
                "Gardening & Nature",
                "Planting Garden Flowers",
                "You are planting pretty flower seeds in your front garden. Which 2 gardening tools do you need?",
                "MEDIUM",
                Arrays.asList(
                        new ScenarioCard("m6_c1", "Gardening Shovel", "shovel", true, "Digs small holes in soil for seedlings."),
                        new ScenarioCard("m6_c2", "Watering Can", "watering_can", true, "Gently waters new plants without washing away soil.")
                ),
                Arrays.asList(
                        new ScenarioCard("m6_d1", "Laptop", "laptop", false, "Electronic device; soil can damage it."),
                        new ScenarioCard("m6_d2", "Sleeping Pillow", "pillow", false, "Bedding item, not for garden work."),
                        new ScenarioCard("m6_d3", "Winter Coat", "winter_coat", false, "Too hot and restrictive for gardening."),
                        new ScenarioCard("m6_d4", "Swimming Goggles", "goggles", false, "Not needed for soil planting.")
                ),
                "A trowel shovel to dig soil and a watering can to nourish plants are basic gardening tools!"
        ));

        // 14. Academic Research
        MEDIUM_SCENARIOS.add(new Scenario(
                "MED_7",
                "Education & Research",
                "Science Project Research",
                "You are researching facts for your school science exhibition project. Which 2 study tools will help you?",
                "MEDIUM",
                Arrays.asList(
                        new ScenarioCard("m7_c1", "Study Laptop", "laptop", true, "Allows digital search and writing reports."),
                        new ScenarioCard("m7_c2", "Science Book", "book", true, "Contains verified textbook facts and diagrams.")
                ),
                Arrays.asList(
                        new ScenarioCard("m7_d1", "Frying Pan", "frying_pan", false, "Kitchen tool, not for science study."),
                        new ScenarioCard("m7_d2", "Football", "football", false, "Sports gear, not reference material."),
                        new ScenarioCard("m7_d3", "Umbrella", "umbrella", false, "Weather item, unrelated to project study."),
                        new ScenarioCard("m7_d4", "Swimming Goggles", "goggles", false, "For swimming, not reading papers.")
                ),
                "A computer laptop and authoritative reference books provide accurate research information!"
        ));

        // =====================================================================
        // HARD SCENARIOS (Realistic detailed situations — Pick 2 out of 6)
        // =====================================================================

        // 15. Airport International Travel
        HARD_SCENARIOS.add(new Scenario(
                "HARD_1",
                "Travel & Logistics",
                "Airport International Travel",
                "You are at the international airport boarding gate for a flight. Which 2 travel documents must you present?",
                "HARD",
                Arrays.asList(
                        new ScenarioCard("h1_c1", "Official Passport", "passport", true, "Government identity document for international border entry."),
                        new ScenarioCard("h1_c2", "Boarding Pass", "boarding_pass", true, "Authorizes seat access onto the scheduled airplane.")
                ),
                Arrays.asList(
                        new ScenarioCard("h1_d1", "Sleeping Pillow", "pillow", false, "Luggage comfort accessory, not legal document."),
                        new ScenarioCard("h1_d2", "Beach Towel", "towel", false, "Beach linen, not identification."),
                        new ScenarioCard("h1_d3", "Frying Pan", "frying_pan", false, "Metallic cookware, restricted item."),
                        new ScenarioCard("h1_d4", "Swimming Goggles", "goggles", false, "Pool accessory, unrelated to immigration.")
                ),
                "A valid passport and boarding pass are mandatory legal requirements to board international flights!"
        ));

        // 16. Living Room Floor Cleaning
        HARD_SCENARIOS.add(new Scenario(
                "HARD_2",
                "Home Care & Cleaning",
                "Floor Cleaning & Mopping",
                "You are doing deep weekend cleaning to wash and mop the hard tile living room floor. Which 2 items do you need?",
                "HARD",
                Arrays.asList(
                        new ScenarioCard("h2_c1", "Floor Mop", "mop", true, "Wipes dirt and scrubs tile surfaces."),
                        new ScenarioCard("h2_c2", "Cleaning Bucket", "bucket", true, "Holds soapy water and rinses the mop.")
                ),
                Arrays.asList(
                        new ScenarioCard("h2_d1", "Sunglasses", "sunglasses", false, "Eyewear, unrelated to home sanitation."),
                        new ScenarioCard("h2_d2", "School Bag", "school_bag", false, "Luggage bag, not a floor cleaning tool."),
                        new ScenarioCard("h2_d3", "Flashlight", "flashlight", false, "Illumination tool, does not clean floor."),
                        new ScenarioCard("h2_d4", "Football", "football", false, "Playing with ball messes up clean floor.")
                ),
                "A wet mop paired with a water bucket is the standard method for cleaning household hard floors!"
        ));

        // 17. Mountain Hiking Trek
        HARD_SCENARIOS.add(new Scenario(
                "HARD_3",
                "Outdoor Expedition",
                "Mountain Trail Hiking",
                "You are embarking on a rugged 15 km mountain hiking trail. Which 2 gear items are most important for footing and navigation?",
                "HARD",
                Arrays.asList(
                        new ScenarioCard("h3_c1", "Hiking Boots", "hiking_boots", true, "Offers ankle support and grip on rocky slopes."),
                        new ScenarioCard("h3_c2", "Navigation Compass", "compass", true, "Provides accurate direction finding on trails.")
                ),
                Arrays.asList(
                        new ScenarioCard("h3_d1", "Pillow", "pillow", false, "Too bulky to carry during uphill trekking."),
                        new ScenarioCard("h3_d2", "Frying Pan", "frying_pan", false, "Heavy cast iron cookware, adds dead weight."),
                        new ScenarioCard("h3_d3", "Ice Cream", "ice_cream", false, "Will quickly melt in your backpack."),
                        new ScenarioCard("h3_d4", "Beach Towel", "towel", false, "Bulky towel, not specialized mountain gear.")
                ),
                "High-traction hiking boots prevent slips, while a reliable compass prevents losing the mountain trail!"
        ));

        // 18. Fever & Cold Care
        HARD_SCENARIOS.add(new Scenario(
                "HARD_4",
                "Health & Wellness",
                "Fever and Cold Recovery",
                "You woke up shivering with a high fever and sore throat. Which 2 items will help monitor and soothe your body?",
                "HARD",
                Arrays.asList(
                        new ScenarioCard("h4_c1", "Digital Thermometer", "thermometer", true, "Accurately measures body temperature."),
                        new ScenarioCard("h4_c2", "Warm Soup Bowl", "warm_soup", true, "Provides easy nourishment and soothes the throat.")
                ),
                Arrays.asList(
                        new ScenarioCard("h4_d1", "Swimming Goggles", "goggles", false, "Resting in bed, swimming is prohibited."),
                        new ScenarioCard("h4_d2", "Football Helmet", "helmet", false, "Not a medical diagnostic tool."),
                        new ScenarioCard("h4_d3", "Sunglasses", "sunglasses", false, "Not needed when resting indoors."),
                        new ScenarioCard("h4_d4", "Cold Ice Cream", "ice_cream", false, "Cold dairy can irritate a sore throat.")
                ),
                "Monitoring body temperature with a thermometer and drinking warm soup promotes fast recovery!"
        ));

        // 19. Formal Job Interview
        HARD_SCENARIOS.add(new Scenario(
                "HARD_5",
                "Career & Professional",
                "Formal Job Interview",
                "You are heading to a corporate office for a formal job interview. Which 2 items are appropriate to wear and bring?",
                "HARD",
                Arrays.asList(
                        new ScenarioCard("h5_c1", "Formal Suit / Blazer", "formal_suit", true, "Presents a smart, professional business appearance."),
                        new ScenarioCard("h5_c2", "Printed Resume CV", "resume", true, "Provides interviewers with qualifications and experience.")
                ),
                Arrays.asList(
                        new ScenarioCard("h5_d1", "Winter Gloves", "winter_gloves", false, "Casual winter accessory, awkward for handshakes."),
                        new ScenarioCard("h5_d2", "Football Helmet", "helmet", false, "Sporting equipment, inappropriate for office."),
                        new ScenarioCard("h5_d3", "Beach Towel", "towel", false, "Casual leisure linen, not business attire."),
                        new ScenarioCard("h5_d4", "Toy Car", "toy_car", false, "A children's toy, not a professional item.")
                ),
                "Wearing a crisp formal suit and bringing printed resume copies creates an excellent professional impression!"
        ));

        // 20. Flat Tire Emergency
        HARD_SCENARIOS.add(new Scenario(
                "HARD_6",
                "Automotive & Safety",
                "Highway Flat Tire Emergency",
                "Your car has a punctured tire on the highway roadside. Which 2 mechanical items do you need to change the wheel?",
                "HARD",
                Arrays.asList(
                        new ScenarioCard("h6_c1", "Spare Tire", "spare_tire", true, "Replaces the punctured wheel to resume driving."),
                        new ScenarioCard("h6_c2", "Car Jack", "car_jack", true, "Lifts the vehicle safely off the ground.")
                ),
                Arrays.asList(
                        new ScenarioCard("h6_d1", "Pillow", "pillow", false, "Soft cushion, cannot lift heavy car weight."),
                        new ScenarioCard("h6_d2", "School Bag", "school_bag", false, "Contains books, not automotive tools."),
                        new ScenarioCard("h6_d3", "Sunglasses", "sunglasses", false, "Does not loosen lug nuts or lift wheels."),
                        new ScenarioCard("h6_d4", "Football", "football", false, "Playing with ball near highway is unsafe.")
                ),
                "A hydraulic car jack to elevate the axle and a good spare tire are essential to fix roadside flat tires!"
        ));

        // 21. Outdoor Canvas Oil Painting
        HARD_SCENARIOS.add(new Scenario(
                "HARD_7",
                "Fine Arts & Studio",
                "Outdoor Oil Painting",
                "You are setting up an outdoor oil painting session in a botanical garden. Which 2 art tools do you need?",
                "HARD",
                Arrays.asList(
                        new ScenarioCard("h7_c1", "Painting Easel & Canvas", "easel", true, "Holds the canvas firmly upright at eye level."),
                        new ScenarioCard("h7_c2", "Paint Palette & Brushes", "palette", true, "Mixes pigments and applies paint strokes.")
                ),
                Arrays.asList(
                        new ScenarioCard("h7_d1", "Winter Coat", "winter_coat", false, "Too heavy and restrictive for summer art."),
                        new ScenarioCard("h7_d2", "Frying Pan", "frying_pan", false, "Cooking pan, not for fine art painting."),
                        new ScenarioCard("h7_d3", "Football", "football", false, "Can knock over fragile art easels."),
                        new ScenarioCard("h7_d4", "Floor Mop", "mop", false, "Too coarse for detailed canvas strokes.")
                ),
                "A sturdy easel to support your canvas and a palette for mixing paints are fundamental art studio tools!"
        ));
    }

    public static List<Scenario> getScenariosByDifficulty(String difficulty) {
        if (difficulty == null) return EASY_SCENARIOS;
        String diff = difficulty.trim().toUpperCase();
        switch (diff) {
            case "EASY":
                return EASY_SCENARIOS;
            case "MEDIUM":
                return MEDIUM_SCENARIOS;
            case "HARD":
                return HARD_SCENARIOS;
            default:
                return EASY_SCENARIOS;
        }
    }

    public static int getTotalScenarioCount() {
        return EASY_SCENARIOS.size() + MEDIUM_SCENARIOS.size() + HARD_SCENARIOS.size();
    }
}
