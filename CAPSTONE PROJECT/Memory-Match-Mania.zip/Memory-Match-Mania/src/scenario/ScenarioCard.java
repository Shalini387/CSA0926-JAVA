package scenario;

public class ScenarioCard {

    private final String id;
    private final String title;
    private final String imageKey;
    private final boolean correct;
    private final String feedbackNote;

    public ScenarioCard(String id, String title, String imageKey, boolean correct, String feedbackNote) {
        this.id = id;
        this.title = title;
        this.imageKey = imageKey;
        this.correct = correct;
        this.feedbackNote = feedbackNote;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getImageKey() {
        return imageKey;
    }

    public boolean isCorrect() {
        return correct;
    }

    public String getFeedbackNote() {
        return feedbackNote;
    }
}
