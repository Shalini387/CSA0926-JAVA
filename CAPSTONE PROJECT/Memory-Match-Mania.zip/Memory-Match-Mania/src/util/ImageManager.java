package util;

import gui.UITheme;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class ImageManager {

    private static final String ASSETS_DIR = "assets/images";
    private static final Map<String, Image> imageCache = new HashMap<>();
    private static boolean initialized = false;

    public static synchronized void init() {
        if (initialized) return;
        initialized = true;

        new Thread(() -> {
            try {
                File dir = new File(ASSETS_DIR);
                if (!dir.exists()) {
                    dir.mkdirs();
                }

                // Preload / generate theme backs
                String[] themes = {
                        "fruits", "animals", "vehicles", "sports", "space",
                        "food", "nature", "technology", "ocean", "emoji"
                };
                for (String t : themes) {
                    ensureIllustration("theme_back_" + t);
                }

            } catch (Throwable ignored) {
            }
        }).start();
    }

    public static Image getImage(String key, int width, int height) {
        if (key == null) key = "apple";
        String normalizedKey = key.toLowerCase().replace(" ", "_").trim();

        Image cached = imageCache.get(normalizedKey + "_" + width + "x" + height);
        if (cached != null) return cached;

        File file = new File(ASSETS_DIR, normalizedKey + ".png");
        BufferedImage img = null;

        if (file.exists()) {
            try {
                img = ImageIO.read(file);
            } catch (Exception ignored) {
            }
        }

        if (img == null) {
            img = createIllustration(normalizedKey);
            try {
                ImageIO.write(img, "PNG", file);
            } catch (Exception ignored) {
            }
        }

        Image scaled = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        imageCache.put(normalizedKey + "_" + width + "x" + height, scaled);
        return scaled;
    }

    public static Image getThemeBackImage(String themeName, int width, int height) {
        String key = "theme_back_" + (themeName == null ? "fruits" : themeName.toLowerCase().trim());
        return getImage(key, width, height);
    }

    private static void ensureIllustration(String key) {
        File file = new File(ASSETS_DIR, key + ".png");
        if (!file.exists() || file.length() < 100) {
            try {
                BufferedImage img = createIllustration(key);
                ImageIO.write(img, "PNG", file);
            } catch (Exception ignored) {
            }
        }
    }

    // =========================================================================
    // HIGH-RESOLUTION PROCEDURAL 2D VECTOR CARTOON ARTWORK (200x200 PNG)
    // =========================================================================

    public static BufferedImage createIllustration(String key) {
        int w = 200;
        int h = 200;
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        UITheme.setRenderingHints(g2);

        boolean isBack = key.startsWith("theme_back_");

        if (isBack) {
            // Theme Back Card Design
            Color start = new Color(79, 70, 229);
            Color end = new Color(124, 58, 237);

            if (key.contains("fruits")) { start = new Color(244, 63, 94); end = new Color(225, 29, 72); }
            else if (key.contains("animals")) { start = new Color(249, 115, 22); end = new Color(234, 88, 12); }
            else if (key.contains("vehicles")) { start = new Color(59, 130, 246); end = new Color(37, 99, 235); }
            else if (key.contains("sports")) { start = new Color(16, 185, 129); end = new Color(5, 150, 105); }
            else if (key.contains("space")) { start = new Color(168, 85, 247); end = new Color(126, 34, 206); }
            else if (key.contains("food")) { start = new Color(245, 158, 11); end = new Color(217, 119, 6); }
            else if (key.contains("nature")) { start = new Color(34, 197, 94); end = new Color(22, 163, 74); }
            else if (key.contains("technology")) { start = new Color(99, 102, 241); end = new Color(79, 70, 229); }
            else if (key.contains("ocean")) { start = new Color(6, 182, 212); end = new Color(8, 145, 178); }
            else if (key.contains("emoji")) { start = new Color(234, 179, 8); end = new Color(202, 138, 4); }

            GradientPaint gp = new GradientPaint(0, 0, start, w, h, end);
            g2.setPaint(gp);
            g2.fill(new RoundRectangle2D.Double(6, 6, w - 12, h - 12, 32, 32));

            g2.setColor(new Color(255, 255, 255, 140));
            g2.setStroke(new BasicStroke(3.0f));
            g2.draw(new RoundRectangle2D.Double(14, 14, w - 28, h - 28, 24, 24));

            g2.setColor(new Color(255, 255, 255, 75));
            g2.fillOval(w / 2 - 46, h / 2 - 46, 92, 92);

            drawArtwork(g2, key.replace("theme_back_", ""), w, h);

        } else {
            // Front Card Artwork (Soft glowing disc + Cartoon Object)
            GradientPaint bgGp = new GradientPaint(0, 0, new Color(241, 245, 249), w, h, new Color(226, 232, 240));
            g2.setPaint(bgGp);
            g2.fill(new Ellipse2D.Double(8, 8, w - 16, h - 16));

            g2.setColor(new Color(203, 213, 225));
            g2.setStroke(new BasicStroke(2.5f));
            g2.draw(new Ellipse2D.Double(8, 8, w - 16, h - 16));

            drawArtwork(g2, key, w, h);
        }

        g2.dispose();
        return img;
    }

    private static void drawArtwork(Graphics2D g2, String key, int w, int h) {
        int cx = w / 2;
        int cy = h / 2;

        switch (key) {
            // =================================================================
            // REAL-WORLD DAILY SCENARIO ITEMS (CARTOON / HIGH DETAIL)
            // =================================================================

            case "umbrella": {
                g2.setColor(new Color(14, 165, 233));
                g2.fillArc(cx - 56, cy - 44, 112, 80, 0, 180);
                g2.setColor(new Color(56, 189, 248));
                g2.fillArc(cx - 24, cy - 44, 48, 80, 0, 180);

                g2.setColor(new Color(2, 132, 199));
                g2.setStroke(new BasicStroke(2.5f));
                g2.drawArc(cx - 56, cy - 44, 112, 80, 0, 180);

                g2.setColor(new Color(30, 41, 59));
                g2.setStroke(new BasicStroke(6.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(cx, cy - 44, cx, cy + 32);
                g2.drawArc(cx - 18, cy + 18, 18, 22, 180, 180);

                g2.setColor(new Color(56, 189, 248));
                g2.fillOval(cx - 48, cy + 12, 6, 10);
                g2.fillOval(cx + 44, cy + 14, 6, 10);
                g2.fillOval(cx + 28, cy + 28, 5, 8);
                break;
            }

            case "raincoat": {
                g2.setColor(new Color(245, 158, 11));
                Path2D coat = new Path2D.Double();
                coat.moveTo(cx - 36, cy - 14);
                coat.lineTo(cx + 36, cy - 14);
                coat.lineTo(cx + 46, cy + 46);
                coat.lineTo(cx - 46, cy + 46);
                coat.closePath();
                g2.fill(coat);

                g2.setColor(new Color(217, 119, 6));
                g2.fillArc(cx - 28, cy - 44, 56, 52, 0, 180);

                g2.setColor(new Color(30, 41, 59));
                g2.fillOval(cx - 4, cy - 2, 8, 8);
                g2.fillOval(cx - 4, cy + 14, 8, 8);
                g2.fillOval(cx - 4, cy + 30, 8, 8);

                g2.setColor(new Color(217, 119, 6));
                g2.fill(new RoundRectangle2D.Double(cx - 38, cy + 22, 22, 18, 4, 4));
                g2.fill(new RoundRectangle2D.Double(cx + 16, cy + 22, 22, 18, 4, 4));
                break;
            }

            case "sunglasses": {
                g2.setColor(new Color(15, 23, 42));
                g2.fill(new RoundRectangle2D.Double(cx - 52, cy - 16, 46, 32, 10, 10));
                g2.fill(new RoundRectangle2D.Double(cx + 6, cy - 16, 46, 32, 10, 10));

                g2.setColor(new Color(71, 85, 105));
                g2.setStroke(new BasicStroke(5.0f));
                g2.drawLine(cx - 10, cy - 10, cx + 10, cy - 10);
                g2.drawLine(cx - 10, cy - 4, cx + 10, cy - 4);

                g2.setColor(new Color(255, 255, 255, 160));
                g2.setStroke(new BasicStroke(3.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(cx - 42, cy + 6, cx - 18, cy - 10);
                g2.drawLine(cx + 16, cy + 6, cx + 40, cy - 10);
                break;
            }

            case "football": {
                g2.setColor(Color.WHITE);
                g2.fillOval(cx - 42, cy - 42, 84, 84);
                g2.setColor(new Color(30, 41, 59));
                g2.setStroke(new BasicStroke(3.0f));
                g2.drawOval(cx - 42, cy - 42, 84, 84);

                Polygon penta = new Polygon();
                for (int i = 0; i < 5; i++) {
                    double a = i * 2 * Math.PI / 5 - Math.PI / 2;
                    penta.addPoint((int) (cx + 16 * Math.cos(a)), (int) (cy + 16 * Math.sin(a)));
                }
                g2.fillPolygon(penta);

                for (int i = 0; i < 5; i++) {
                    double a = i * 2 * Math.PI / 5 - Math.PI / 2;
                    int px = (int) (cx + 16 * Math.cos(a));
                    int py = (int) (cy + 16 * Math.sin(a));
                    int ox = (int) (cx + 42 * Math.cos(a));
                    int oy = (int) (cy + 42 * Math.sin(a));
                    g2.drawLine(px, py, ox, oy);
                }
                break;
            }

            case "pillow": {
                g2.setColor(new Color(186, 230, 253));
                g2.fill(new RoundRectangle2D.Double(cx - 48, cy - 32, 96, 64, 22, 22));

                g2.setColor(new Color(56, 189, 248));
                g2.setStroke(new BasicStroke(3.0f));
                g2.draw(new RoundRectangle2D.Double(cx - 48, cy - 32, 96, 64, 22, 22));
                g2.drawArc(cx - 24, cy - 14, 48, 28, 0, 180);
                break;
            }

            case "ice_cream": {
                g2.setColor(new Color(217, 119, 6));
                Polygon cone = new Polygon();
                cone.addPoint(cx, cy + 48);
                cone.addPoint(cx - 26, cy);
                cone.addPoint(cx + 26, cy);
                g2.fillPolygon(cone);

                g2.setColor(new Color(180, 83, 9));
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawLine(cx - 16, cy + 12, cx + 8, cy + 34);
                g2.drawLine(cx + 16, cy + 12, cx - 8, cy + 34);

                g2.setColor(new Color(52, 211, 153));
                g2.fillOval(cx - 30, cy - 24, 60, 42);

                g2.setColor(new Color(244, 114, 182));
                g2.fillOval(cx - 26, cy - 46, 52, 42);

                g2.setColor(new Color(225, 29, 72));
                g2.fillOval(cx - 8, cy - 54, 16, 16);
                g2.setColor(new Color(30, 41, 59));
                g2.setStroke(new BasicStroke(2.0f));
                g2.drawArc(cx + 2, cy - 62, 14, 16, 90, 90);
                break;
            }

            case "sunscreen": {
                g2.setColor(new Color(251, 191, 36));
                g2.fill(new RoundRectangle2D.Double(cx - 24, cy - 16, 48, 60, 12, 12));
                g2.setColor(new Color(239, 68, 68));
                g2.fill(new RoundRectangle2D.Double(cx - 16, cy - 36, 32, 20, 6, 6));

                g2.setColor(new Color(245, 158, 11));
                g2.fillOval(cx - 12, cy + 4, 24, 24);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Arial", Font.BOLD, 12));
                g2.drawString("SPF", cx - 12, cy + 38);
                break;
            }

            case "school_bag": {
                g2.setColor(new Color(79, 70, 229));
                g2.fill(new RoundRectangle2D.Double(cx - 32, cy - 34, 64, 74, 18, 18));
                g2.setColor(new Color(99, 102, 241));
                g2.fill(new RoundRectangle2D.Double(cx - 24, cy - 2, 48, 36, 12, 12));
                g2.setColor(new Color(30, 41, 59));
                g2.setStroke(new BasicStroke(4.0f));
                g2.drawArc(cx - 14, cy - 46, 28, 24, 0, 180);
                break;
            }

            case "notebook":
            case "book": {
                g2.setColor(new Color(16, 185, 129));
                g2.fill(new RoundRectangle2D.Double(cx - 34, cy - 40, 68, 78, 10, 10));

                g2.setColor(Color.WHITE);
                g2.setStroke(new BasicStroke(2.5f));
                g2.drawLine(cx - 20, cy - 20, cx + 20, cy - 20);
                g2.drawLine(cx - 20, cy - 6, cx + 20, cy - 6);
                g2.drawLine(cx - 20, cy + 8, cx + 20, cy + 8);
                g2.drawLine(cx - 20, cy + 22, cx + 20, cy + 22);

                g2.setColor(new Color(251, 191, 36));
                g2.fillRect(cx + 8, cy - 42, 10, 26);
                break;
            }

            case "winter_gloves": {
                g2.setColor(new Color(239, 68, 68));
                g2.fill(new RoundRectangle2D.Double(cx - 44, cy - 26, 36, 52, 14, 14));
                g2.fillOval(cx - 20, cy - 10, 16, 22);
                g2.fill(new RoundRectangle2D.Double(cx + 8, cy - 26, 36, 52, 14, 14));
                g2.fillOval(cx + 4, cy - 10, 16, 22);

                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Double(cx - 46, cy + 18, 40, 14, 6, 6));
                g2.fill(new RoundRectangle2D.Double(cx + 6, cy + 18, 40, 14, 6, 6));
                break;
            }

            case "goggles": {
                g2.setColor(new Color(14, 165, 233));
                g2.fillOval(cx - 42, cy - 16, 36, 32);
                g2.fillOval(cx + 6, cy - 16, 36, 32);
                g2.setColor(new Color(30, 41, 59));
                g2.setStroke(new BasicStroke(4.0f));
                g2.drawLine(cx - 6, cy, cx + 6, cy);
                g2.drawLine(cx - 42, cy, cx - 56, cy);
                g2.drawLine(cx + 42, cy, cx + 56, cy);
                break;
            }

            case "towel": {
                g2.setColor(new Color(244, 63, 94));
                g2.fill(new RoundRectangle2D.Double(cx - 36, cy - 36, 72, 72, 12, 12));
                g2.setColor(new Color(251, 191, 36));
                g2.fillRect(cx - 36, cy - 18, 72, 14);
                g2.fillRect(cx - 36, cy + 10, 72, 14);
                break;
            }

            case "water_bottle": {
                g2.setColor(new Color(14, 165, 233));
                g2.fill(new RoundRectangle2D.Double(cx - 20, cy - 20, 40, 68, 12, 12));
                g2.setColor(new Color(30, 41, 59));
                g2.fill(new RoundRectangle2D.Double(cx - 12, cy - 36, 24, 16, 6, 6));
                g2.setStroke(new BasicStroke(3.5f));
                g2.drawArc(cx - 10, cy - 46, 20, 16, 0, 180);
                break;
            }

            case "glass_water": {
                g2.setColor(new Color(186, 230, 253));
                Polygon glass = new Polygon();
                glass.addPoint(cx - 26, cy - 36);
                glass.addPoint(cx + 26, cy - 36);
                glass.addPoint(cx + 18, cy + 40);
                glass.addPoint(cx - 18, cy + 40);
                g2.fillPolygon(glass);

                g2.setColor(new Color(56, 189, 248));
                Polygon water = new Polygon();
                water.addPoint(cx - 22, cy - 8);
                water.addPoint(cx + 22, cy - 8);
                water.addPoint(cx + 17, cy + 38);
                water.addPoint(cx - 17, cy + 38);
                g2.fillPolygon(water);

                g2.setColor(new Color(255, 255, 255, 200));
                g2.fillRoundRect(cx - 12, cy, 14, 14, 4, 4);
                g2.fillRoundRect(cx + 2, cy + 10, 12, 12, 4, 4);
                break;
            }

            case "laptop":
            case "computer": {
                // Sleek Open Modern Laptop
                g2.setColor(new Color(30, 41, 59));
                g2.fill(new RoundRectangle2D.Double(cx - 40, cy - 36, 80, 52, 6, 6));
                // Cyan glowing screen
                g2.setColor(new Color(14, 165, 233));
                g2.fill(new RoundRectangle2D.Double(cx - 34, cy - 30, 68, 40, 4, 4));
                // Base
                g2.setColor(new Color(100, 116, 139));
                g2.fill(new RoundRectangle2D.Double(cx - 48, cy + 16, 96, 12, 4, 4));
                break;
            }

            case "toy_car": {
                // Cute Red & Yellow Toy Car
                g2.setColor(new Color(239, 68, 68));
                g2.fill(new RoundRectangle2D.Double(cx - 36, cy - 8, 72, 28, 8, 8));
                g2.fill(new RoundRectangle2D.Double(cx - 20, cy - 24, 40, 20, 6, 6));
                // Windows
                g2.setColor(new Color(186, 230, 253));
                g2.fillRect(cx - 16, cy - 20, 14, 14);
                g2.fillRect(cx + 2, cy - 20, 14, 14);
                // Wheels
                g2.setColor(new Color(30, 41, 59));
                g2.fillOval(cx - 30, cy + 12, 20, 20);
                g2.fillOval(cx + 10, cy + 12, 20, 20);
                g2.setColor(new Color(251, 191, 36));
                g2.fillOval(cx - 24, cy + 18, 8, 8);
                g2.fillOval(cx + 16, cy + 18, 8, 8);
                break;
            }

            case "blanket": {
                // Cozy Folded Wool Blanket
                g2.setColor(new Color(139, 92, 246));
                g2.fill(new RoundRectangle2D.Double(cx - 42, cy - 24, 84, 52, 14, 14));
                g2.setColor(new Color(168, 85, 247));
                g2.fill(new RoundRectangle2D.Double(cx - 36, cy - 32, 72, 20, 10, 10));
                g2.setColor(new Color(251, 191, 36));
                g2.fillRect(cx - 42, cy - 6, 84, 8);
                break;
            }

            case "bicycle": {
                // Modern Sport Bicycle
                g2.setColor(new Color(30, 41, 59));
                g2.setStroke(new BasicStroke(4.0f));
                g2.drawOval(cx - 44, cy, 32, 32);
                g2.drawOval(cx + 12, cy, 32, 32);
                // Frame
                g2.setColor(new Color(239, 68, 68));
                g2.drawLine(cx - 28, cy + 16, cx - 8, cy + 16);
                g2.drawLine(cx - 8, cy + 16, cx + 4, cy - 10);
                g2.drawLine(cx + 4, cy - 10, cx - 18, cy - 10);
                g2.drawLine(cx - 18, cy - 10, cx - 28, cy + 16);
                g2.drawLine(cx + 4, cy - 10, cx + 28, cy + 16);
                break;
            }

            case "crayons": {
                // Colorful Art Crayons
                g2.setColor(new Color(251, 191, 36)); // Box
                g2.fill(new RoundRectangle2D.Double(cx - 34, cy - 10, 68, 48, 8, 8));

                // 4 Crayons peeking out (Red, Green, Blue, Purple)
                Color[] crColors = {new Color(239, 68, 68), new Color(34, 197, 94), new Color(59, 130, 246), new Color(168, 85, 247)};
                for (int i = 0; i < 4; i++) {
                    int bx = cx - 26 + (i * 14);
                    g2.setColor(crColors[i]);
                    g2.fill(new RoundRectangle2D.Double(bx, cy - 36, 11, 32, 3, 3));
                    Polygon tip = new Polygon();
                    tip.addPoint(bx, cy - 36);
                    tip.addPoint(bx + 5, cy - 44);
                    tip.addPoint(bx + 11, cy - 36);
                    g2.fillPolygon(tip);
                }
                break;
            }

            case "tent": {
                g2.setColor(new Color(249, 115, 22));
                Polygon t = new Polygon();
                t.addPoint(cx, cy - 40);
                t.addPoint(cx - 48, cy + 36);
                t.addPoint(cx + 48, cy + 36);
                g2.fillPolygon(t);

                g2.setColor(new Color(30, 41, 59));
                Polygon door = new Polygon();
                door.addPoint(cx, cy - 20);
                door.addPoint(cx - 20, cy + 36);
                door.addPoint(cx + 20, cy + 36);
                g2.fillPolygon(door);
                break;
            }

            case "flashlight": {
                g2.setColor(new Color(251, 191, 36, 130));
                Polygon beam = new Polygon();
                beam.addPoint(cx + 10, cy - 16);
                beam.addPoint(cx + 54, cy - 40);
                beam.addPoint(cx + 54, cy + 40);
                beam.addPoint(cx + 10, cy + 16);
                g2.fillPolygon(beam);

                g2.setColor(new Color(30, 41, 59));
                g2.fill(new RoundRectangle2D.Double(cx - 48, cy - 10, 42, 20, 6, 6));
                g2.setColor(new Color(245, 158, 11));
                g2.fill(new RoundRectangle2D.Double(cx - 6, cy - 16, 18, 32, 6, 6));
                break;
            }

            case "bandage": {
                g2.setColor(new Color(251, 191, 36));
                g2.fill(new RoundRectangle2D.Double(cx - 44, cy - 18, 88, 36, 14, 14));
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Double(cx - 16, cy - 16, 32, 32, 4, 4));
                g2.setColor(new Color(239, 68, 68));
                g2.fillRect(cx - 3, cy - 10, 6, 20);
                g2.fillRect(cx - 10, cy - 3, 20, 6);
                break;
            }

            case "antiseptic": {
                g2.setColor(new Color(241, 245, 249));
                g2.fill(new RoundRectangle2D.Double(cx - 24, cy - 18, 48, 60, 10, 10));
                g2.setColor(new Color(14, 165, 233));
                g2.fill(new RoundRectangle2D.Double(cx - 12, cy - 36, 24, 18, 4, 4));
                g2.setColor(new Color(239, 68, 68));
                g2.fillRect(cx - 3, cy + 2, 6, 20);
                g2.fillRect(cx - 10, cy + 9, 20, 6);
                break;
            }

            case "frying_pan": {
                g2.setColor(new Color(51, 65, 85));
                g2.fillOval(cx - 38, cy - 34, 76, 68);
                g2.setColor(new Color(180, 83, 9));
                g2.setStroke(new BasicStroke(8.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(cx + 26, cy + 20, cx + 52, cy + 44);

                g2.setColor(Color.WHITE);
                g2.fillOval(cx - 20, cy - 16, 40, 32);
                g2.setColor(new Color(245, 158, 11));
                g2.fillOval(cx - 8, cy - 8, 16, 16);
                break;
            }

            case "spatula": {
                g2.setColor(new Color(148, 163, 184));
                g2.fill(new RoundRectangle2D.Double(cx - 20, cy - 44, 40, 48, 6, 6));
                g2.setColor(new Color(180, 83, 9));
                g2.fill(new RoundRectangle2D.Double(cx - 6, cy + 4, 12, 46, 6, 6));
                g2.setColor(new Color(51, 65, 85));
                g2.fillRect(cx - 12, cy - 36, 4, 30);
                g2.fillRect(cx - 2, cy - 36, 4, 30);
                g2.fillRect(cx + 8, cy - 36, 4, 30);
                break;
            }

            case "winter_coat": {
                g2.setColor(new Color(239, 68, 68));
                Path2D coat = new Path2D.Double();
                coat.moveTo(cx - 34, cy - 16);
                coat.lineTo(cx + 34, cy - 16);
                coat.lineTo(cx + 44, cy + 44);
                coat.lineTo(cx - 44, cy + 44);
                coat.closePath();
                g2.fill(coat);

                g2.setColor(new Color(254, 243, 199));
                g2.fillArc(cx - 30, cy - 46, 60, 56, 0, 180);
                break;
            }

            case "helmet": {
                g2.setColor(new Color(59, 130, 246));
                g2.fillArc(cx - 40, cy - 34, 80, 56, 0, 180);
                g2.setColor(new Color(30, 41, 59));
                g2.fill(new RoundRectangle2D.Double(cx - 44, cy + 4, 44, 12, 4, 4));
                g2.setColor(Color.WHITE);
                g2.fillOval(cx - 20, cy - 20, 14, 8);
                g2.fillOval(cx + 6, cy - 20, 14, 8);
                break;
            }

            case "knee_pads": {
                // Tough Protective Knee Pads
                g2.setColor(new Color(30, 41, 59));
                g2.fill(new RoundRectangle2D.Double(cx - 32, cy - 32, 64, 64, 16, 16));
                g2.setColor(new Color(245, 158, 11));
                g2.fillOval(cx - 20, cy - 20, 40, 40);
                g2.setColor(Color.WHITE);
                g2.fillRect(cx - 32, cy - 2, 64, 4);
                break;
            }

            case "shovel": {
                // Garden Hand Trowel / Shovel
                g2.setColor(new Color(148, 163, 184)); // Steel blade
                Polygon blade = new Polygon();
                blade.addPoint(cx - 20, cy - 40);
                blade.addPoint(cx + 20, cy - 40);
                blade.addPoint(cx, cy + 4);
                g2.fillPolygon(blade);
                // Handle
                g2.setColor(new Color(180, 83, 9));
                g2.fill(new RoundRectangle2D.Double(cx - 5, cy + 4, 10, 42, 4, 4));
                break;
            }

            case "watering_can": {
                // Classic Green Garden Watering Can
                g2.setColor(new Color(34, 197, 94));
                g2.fill(new RoundRectangle2D.Double(cx - 30, cy - 16, 60, 48, 10, 10));
                // Spout
                g2.setColor(new Color(22, 163, 74));
                Polygon sp = new Polygon();
                sp.addPoint(cx + 20, cy);
                sp.addPoint(cx + 46, cy - 24);
                sp.addPoint(cx + 42, cy - 30);
                sp.addPoint(cx + 16, cy - 6);
                g2.fillPolygon(sp);
                // Handle
                g2.setStroke(new BasicStroke(5.0f));
                g2.drawArc(cx - 46, cy - 26, 32, 44, 90, 180);
                break;
            }

            case "passport": {
                g2.setColor(new Color(30, 41, 59));
                g2.fill(new RoundRectangle2D.Double(cx - 32, cy - 42, 64, 84, 10, 10));
                g2.setColor(new Color(251, 191, 36));
                g2.drawOval(cx - 16, cy - 16, 32, 32);
                g2.setFont(new Font("Arial", Font.BOLD, 10));
                g2.drawString("PASSPORT", cx - 28, cy + 30);
                break;
            }

            case "boarding_pass": {
                // Airplane Boarding Ticket
                g2.setColor(new Color(255, 255, 255));
                g2.fill(new RoundRectangle2D.Double(cx - 44, cy - 24, 88, 48, 8, 8));
                g2.setColor(new Color(59, 130, 246));
                g2.fillRect(cx - 44, cy - 24, 88, 14);
                // Barcode
                g2.setColor(new Color(30, 41, 59));
                for (int i = 0; i < 8; i++) {
                    g2.fillRect(cx - 36 + (i * 9), cy + 2, 4, 16);
                }
                break;
            }

            case "mop": {
                g2.setColor(new Color(14, 165, 233));
                g2.fill(new RoundRectangle2D.Double(cx - 36, cy + 14, 72, 28, 10, 10));
                g2.setColor(new Color(148, 163, 184));
                g2.setStroke(new BasicStroke(6.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawLine(cx, cy - 46, cx, cy + 14);
                break;
            }

            case "bucket": {
                // Cleaning Bucket with Soapy Bubbles
                g2.setColor(new Color(59, 130, 246));
                Polygon bk = new Polygon();
                bk.addPoint(cx - 34, cy - 24);
                bk.addPoint(cx + 34, cy - 24);
                bk.addPoint(cx + 24, cy + 38);
                bk.addPoint(cx - 24, cy + 38);
                g2.fillPolygon(bk);

                // Bubbles
                g2.setColor(new Color(186, 230, 253));
                g2.fillOval(cx - 18, cy - 36, 16, 16);
                g2.fillOval(cx + 4, cy - 32, 14, 14);
                break;
            }

            case "hiking_boots": {
                g2.setColor(new Color(180, 83, 9));
                Polygon boot = new Polygon();
                boot.addPoint(cx - 20, cy - 36);
                boot.addPoint(cx + 12, cy - 36);
                boot.addPoint(cx + 12, cy + 4);
                boot.addPoint(cx + 42, cy + 18);
                boot.addPoint(cx + 42, cy + 34);
                boot.addPoint(cx - 20, cy + 34);
                g2.fillPolygon(boot);

                g2.setColor(new Color(30, 41, 59));
                g2.fillRect(cx - 22, cy + 34, 66, 10);
                break;
            }

            case "compass": {
                // Brass Navigational Compass
                g2.setColor(new Color(251, 191, 36));
                g2.fillOval(cx - 38, cy - 38, 76, 76);
                g2.setColor(Color.WHITE);
                g2.fillOval(cx - 30, cy - 30, 60, 60);

                // Red & Blue Needle
                Polygon north = new Polygon();
                north.addPoint(cx, cy - 26);
                north.addPoint(cx + 8, cy);
                north.addPoint(cx - 8, cy);
                g2.setColor(new Color(239, 68, 68));
                g2.fillPolygon(north);

                Polygon south = new Polygon();
                south.addPoint(cx, cy + 26);
                south.addPoint(cx + 8, cy);
                south.addPoint(cx - 8, cy);
                g2.setColor(new Color(59, 130, 246));
                g2.fillPolygon(south);
                break;
            }

            case "thermometer": {
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Double(cx - 12, cy - 46, 24, 92, 10, 10));
                g2.setColor(new Color(148, 163, 184));
                g2.fill(new RoundRectangle2D.Double(cx - 8, cy + 32, 16, 16, 6, 6));
                g2.setColor(new Color(186, 230, 253));
                g2.fill(new RoundRectangle2D.Double(cx - 8, cy - 20, 16, 26, 4, 4));
                g2.setColor(new Color(239, 68, 68));
                g2.setFont(new Font("Arial", Font.BOLD, 9));
                g2.drawString("98.6", cx - 7, cy - 4);
                break;
            }

            case "warm_soup": {
                // Steaming Bowl of Hot Soup
                g2.setColor(new Color(245, 158, 11)); // Soup bowl
                g2.fillArc(cx - 40, cy - 20, 80, 60, 180, 180);
                // Steam curls
                g2.setColor(new Color(203, 213, 225));
                g2.setStroke(new BasicStroke(3.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawArc(cx - 20, cy - 44, 14, 20, 0, 180);
                g2.drawArc(cx + 4, cy - 44, 14, 20, 180, 180);
                break;
            }

            case "formal_suit": {
                // Navy Blazer with Red Tie
                g2.setColor(new Color(30, 41, 59));
                g2.fill(new RoundRectangle2D.Double(cx - 36, cy - 24, 72, 68, 8, 8));
                // White shirt collar
                g2.setColor(Color.WHITE);
                Polygon collar = new Polygon();
                collar.addPoint(cx, cy + 4);
                collar.addPoint(cx - 16, cy - 24);
                collar.addPoint(cx + 16, cy - 24);
                g2.fillPolygon(collar);
                // Red necktie
                g2.setColor(new Color(239, 68, 68));
                Polygon tie = new Polygon();
                tie.addPoint(cx - 4, cy - 14);
                tie.addPoint(cx + 4, cy - 14);
                tie.addPoint(cx + 6, cy + 24);
                tie.addPoint(cx, cy + 34);
                tie.addPoint(cx - 6, cy + 24);
                g2.fillPolygon(tie);
                break;
            }

            case "resume": {
                // Clean CV / Resume Sheet
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Double(cx - 32, cy - 42, 64, 84, 8, 8));
                g2.setColor(new Color(59, 130, 246));
                g2.fillRect(cx - 24, cy - 32, 20, 20);
                g2.setColor(new Color(148, 163, 184));
                g2.fillRect(cx - 24, cy - 4, 48, 4);
                g2.fillRect(cx - 24, cy + 6, 48, 4);
                g2.fillRect(cx - 24, cy + 16, 48, 4);
                g2.fillRect(cx - 24, cy + 26, 32, 4);
                break;
            }

            case "spare_tire": {
                g2.setColor(new Color(30, 41, 59));
                g2.fillOval(cx - 42, cy - 42, 84, 84);
                g2.setColor(new Color(203, 213, 225));
                g2.fillOval(cx - 26, cy - 26, 52, 52);
                g2.setColor(new Color(51, 65, 85));
                g2.fillOval(cx - 12, cy - 12, 24, 24);
                break;
            }

            case "car_jack": {
                // Scissor Car Jack
                g2.setColor(new Color(239, 68, 68));
                g2.setStroke(new BasicStroke(5.0f));
                g2.drawLine(cx - 36, cy + 16, cx, cy - 24);
                g2.drawLine(cx, cy - 24, cx + 36, cy + 16);
                g2.drawLine(cx - 36, cy + 16, cx, cy + 32);
                g2.drawLine(cx, cy + 32, cx + 36, cy + 16);
                g2.setColor(new Color(30, 41, 59));
                g2.fillRect(cx - 14, cy - 30, 28, 8);
                break;
            }

            case "easel": {
                // Tripod Wooden Easel
                g2.setColor(new Color(180, 83, 9));
                g2.setStroke(new BasicStroke(5.0f));
                g2.drawLine(cx, cy - 44, cx - 32, cy + 44);
                g2.drawLine(cx, cy - 44, cx + 32, cy + 44);
                g2.drawLine(cx, cy - 44, cx, cy + 44);
                // Canvas on easel
                g2.setColor(Color.WHITE);
                g2.fill(new RoundRectangle2D.Double(cx - 28, cy - 22, 56, 40, 4, 4));
                g2.setColor(new Color(239, 68, 68));
                g2.fillOval(cx - 10, cy - 10, 20, 20);
                break;
            }

            case "palette": {
                // Wooden Painter Palette with Colors
                g2.setColor(new Color(217, 119, 6));
                g2.fillOval(cx - 42, cy - 34, 84, 68);
                g2.setColor(new Color(241, 245, 249)); // Thumb hole
                g2.fillOval(cx + 14, cy - 8, 16, 20);

                // Colorful paint spots
                Color[] paints = {new Color(239, 68, 68), new Color(59, 130, 246), new Color(234, 179, 8), new Color(34, 197, 94)};
                int[][] spotPos = {{-24, -14}, {-8, -20}, {-28, 6}, {-12, 14}};
                for (int i = 0; i < 4; i++) {
                    g2.setColor(paints[i]);
                    g2.fillOval(cx + spotPos[i][0], cy + spotPos[i][1], 12, 12);
                }
                break;
            }

            // =================================================================
            // MATCHING CARDS ITEMS (FRUITS, ANIMALS, VEHICLES, SPORTS, ETC.)
            // =================================================================

            case "fruits":
            case "apple": {
                g2.setColor(new Color(239, 68, 68));
                g2.fillOval(cx - 36, cy - 26, 44, 60);
                g2.fillOval(cx - 8, cy - 26, 44, 60);
                g2.setColor(new Color(180, 83, 9));
                g2.setStroke(new BasicStroke(4.0f));
                g2.drawLine(cx, cy - 26, cx + 6, cy - 42);
                g2.setColor(new Color(34, 197, 94));
                g2.fillOval(cx + 6, cy - 44, 22, 14);
                break;
            }

            case "banana": {
                g2.setColor(new Color(234, 179, 8));
                g2.setStroke(new BasicStroke(16.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g2.drawArc(cx - 36, cy - 40, 72, 80, 200, 110);
                g2.setColor(new Color(180, 83, 9));
                g2.fillOval(cx - 26, cy + 22, 10, 10);
                break;
            }

            case "orange": {
                g2.setColor(new Color(249, 115, 22));
                g2.fillOval(cx - 36, cy - 36, 72, 72);
                g2.setColor(new Color(34, 197, 94));
                g2.fillOval(cx - 8, cy - 46, 18, 14);
                break;
            }

            case "strawberry": {
                g2.setColor(new Color(225, 29, 72));
                Polygon sb = new Polygon();
                sb.addPoint(cx - 34, cy - 20);
                sb.addPoint(cx + 34, cy - 20);
                sb.addPoint(cx, cy + 40);
                g2.fillPolygon(sb);
                g2.fillOval(cx - 34, cy - 30, 34, 24);
                g2.fillOval(cx, cy - 30, 34, 24);
                g2.setColor(new Color(34, 197, 94));
                g2.fillOval(cx - 16, cy - 38, 32, 16);
                break;
            }

            case "watermelon": {
                g2.setColor(new Color(22, 163, 74));
                g2.fillArc(cx - 44, cy - 38, 88, 76, 180, 180);
                g2.setColor(new Color(239, 68, 68));
                g2.fillArc(cx - 38, cy - 32, 76, 64, 180, 180);
                g2.setColor(new Color(30, 41, 59));
                g2.fillOval(cx - 14, cy - 4, 5, 7);
                g2.fillOval(cx + 10, cy - 4, 5, 7);
                break;
            }

            case "grapes": {
                g2.setColor(new Color(147, 51, 234));
                int[][] pts = {{-16, -16}, {0, -20}, {16, -16}, {-10, 0}, {10, 0}, {0, 18}};
                for (int[] p : pts) {
                    g2.fillOval(cx + p[0] - 10, cy + p[1] - 10, 24, 24);
                }
                g2.setColor(new Color(34, 197, 94));
                g2.drawLine(cx, cy - 28, cx, cy - 44);
                break;
            }

            case "animals":
            case "lion": {
                g2.setColor(new Color(217, 119, 6));
                g2.fillOval(cx - 44, cy - 42, 88, 88);
                g2.setColor(new Color(251, 191, 36));
                g2.fillOval(cx - 30, cy - 28, 60, 60);
                g2.setColor(new Color(30, 41, 59));
                g2.fillOval(cx - 15, cy - 10, 8, 8);
                g2.fillOval(cx + 7, cy - 10, 8, 8);
                g2.fillOval(cx - 7, cy + 4, 14, 10);
                break;
            }

            case "dog": {
                g2.setColor(new Color(180, 83, 9));
                g2.fillOval(cx - 34, cy - 30, 68, 64);
                g2.setColor(new Color(120, 53, 15));
                g2.fillOval(cx - 44, cy - 26, 20, 44);
                g2.fillOval(cx + 24, cy - 26, 20, 44);
                g2.setColor(new Color(254, 243, 199));
                g2.fillOval(cx - 16, cy - 2, 32, 28);
                g2.setColor(new Color(30, 41, 59));
                g2.fillOval(cx - 6, cy + 2, 12, 10);
                break;
            }

            case "cat": {
                g2.setColor(new Color(100, 116, 139));
                g2.fillOval(cx - 34, cy - 24, 68, 60);
                Polygon leftEar = new Polygon();
                leftEar.addPoint(cx - 30, cy - 16);
                leftEar.addPoint(cx - 24, cy - 44);
                leftEar.addPoint(cx - 6, cy - 24);
                g2.fillPolygon(leftEar);
                Polygon rightEar = new Polygon();
                rightEar.addPoint(cx + 6, cy - 24);
                rightEar.addPoint(cx + 24, cy - 44);
                rightEar.addPoint(cx + 30, cy - 16);
                g2.fillPolygon(rightEar);
                g2.setColor(new Color(34, 197, 94));
                g2.fillOval(cx - 18, cy - 6, 10, 10);
                g2.fillOval(cx + 8, cy - 6, 10, 10);
                break;
            }

            case "vehicles":
            case "car": {
                g2.setColor(new Color(239, 68, 68));
                g2.fill(new RoundRectangle2D.Double(cx - 44, cy - 6, 88, 30, 10, 10));
                g2.fill(new RoundRectangle2D.Double(cx - 24, cy - 26, 48, 24, 8, 8));
                g2.setColor(new Color(30, 41, 59));
                g2.fillOval(cx - 34, cy + 14, 22, 22);
                g2.fillOval(cx + 12, cy + 14, 22, 22);
                break;
            }

            case "space":
            case "rocket": {
                g2.setColor(new Color(239, 68, 68));
                Polygon roc = new Polygon();
                roc.addPoint(cx, cy - 48);
                roc.addPoint(cx + 24, cy + 16);
                roc.addPoint(cx - 24, cy + 16);
                g2.fillPolygon(roc);
                g2.setColor(new Color(14, 165, 233));
                g2.fillOval(cx - 10, cy - 16, 20, 20);
                g2.setColor(new Color(245, 158, 11));
                Polygon flm = new Polygon();
                flm.addPoint(cx - 12, cy + 16);
                flm.addPoint(cx, cy + 44);
                flm.addPoint(cx + 12, cy + 16);
                g2.fillPolygon(flm);
                break;
            }

            default: {
                g2.setColor(new Color(99, 102, 241));
                g2.fillOval(cx - 34, cy - 34, 68, 68);
                g2.setColor(Color.WHITE);
                g2.setFont(new Font("Arial", Font.BOLD, 28));
                g2.drawString("★", cx - 14, cy + 10);
                break;
            }
        }
    }
}
