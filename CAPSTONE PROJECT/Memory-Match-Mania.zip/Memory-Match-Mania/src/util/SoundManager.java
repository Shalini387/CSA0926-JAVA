package util;

import javax.sound.sampled.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Map;

public class SoundManager {

    private static boolean muted = false;
    private static final Map<String, Clip> clipCache = new HashMap<>();
    private static boolean initialized = false;

    private static final String SOUNDS_DIR = "assets/sounds";

    public static final String CARD_FLIP = "card_flip";
    public static final String CORRECT_MATCH = "match_success";
    public static final String WRONG_MATCH = "match_wrong";
    public static final String BUTTON_CLICK = "button_click";
    public static final String LEVEL_COMPLETED = "level_complete";
    public static final String GAME_COMPLETED = "game_completed";
    public static final String SCENARIO_CORRECT = "scenario_correct";
    public static final String SCENARIO_INCORRECT = "scenario_wrong";
    public static final String CELEBRATION = "celebration";

    public static synchronized void init() {
        if (initialized) return;
        initialized = true;

        new Thread(() -> {
            try {
                File dir = new File(SOUNDS_DIR);
                if (!dir.exists()) {
                    dir.mkdirs();
                }

                // Generate synthesized audio files if they don't exist
                ensureSoundFile(CARD_FLIP, SoundManager::generateCardFlip);
                ensureSoundFile(CORRECT_MATCH, SoundManager::generateCorrectMatch);
                ensureSoundFile(WRONG_MATCH, SoundManager::generateWrongMatch);
                ensureSoundFile(BUTTON_CLICK, SoundManager::generateButtonClick);
                ensureSoundFile(LEVEL_COMPLETED, SoundManager::generateLevelComplete);
                ensureSoundFile(GAME_COMPLETED, SoundManager::generateGameComplete);
                ensureSoundFile(SCENARIO_CORRECT, SoundManager::generateScenarioCorrect);
                ensureSoundFile(SCENARIO_INCORRECT, SoundManager::generateScenarioWrong);
                ensureSoundFile(CELEBRATION, SoundManager::generateCelebration);

                // Preload clips into memory for instant low-latency playback
                preloadClip(CARD_FLIP);
                preloadClip(CORRECT_MATCH);
                preloadClip(WRONG_MATCH);
                preloadClip(BUTTON_CLICK);
                preloadClip(LEVEL_COMPLETED);
                preloadClip(GAME_COMPLETED);
                preloadClip(SCENARIO_CORRECT);
                preloadClip(SCENARIO_INCORRECT);
                preloadClip(CELEBRATION);

            } catch (Throwable t) {
                // Audio initialization failed silently; game will continue without sounds
            }
        }).start();
    }

    private interface SoundGenerator {
        byte[] generate();
    }

    private static void ensureSoundFile(String name, SoundGenerator generator) {
        File file = new File(SOUNDS_DIR, name + ".wav");
        if (!file.exists() || file.length() < 44) {
            try {
                byte[] audioData = generator.generate();
                writeWavFile(file, audioData, 44100, 16, 1);
            } catch (Exception ignored) {
            }
        }
    }

    private static void preloadClip(String name) {
        File file = new File(SOUNDS_DIR, name + ".wav");
        if (!file.exists()) return;

        try {
            AudioInputStream ais = AudioSystem.getAudioInputStream(file);
            Clip clip = AudioSystem.getClip();
            clip.open(ais);
            clipCache.put(name, clip);
        } catch (Exception ignored) {
        }
    }

    public static void play(String soundName) {
        if (muted) return;

        new Thread(() -> {
            try {
                Clip clip = clipCache.get(soundName);
                if (clip != null) {
                    if (clip.isRunning()) {
                        clip.stop();
                    }
                    clip.setFramePosition(0);
                    clip.start();
                    return;
                }

                // Fallback: try loading directly from file
                File file = new File(SOUNDS_DIR, soundName + ".wav");
                if (file.exists()) {
                    AudioInputStream ais = AudioSystem.getAudioInputStream(file);
                    Clip newClip = AudioSystem.getClip();
                    newClip.open(ais);
                    newClip.start();
                }
            } catch (Throwable ignored) {
            }
        }).start();
    }

    public static void playCardFlip() {
        play(CARD_FLIP);
    }

    public static void playCorrectMatch() {
        play(CORRECT_MATCH);
    }

    public static void playWrongMatch() {
        play(WRONG_MATCH);
    }

    public static void playButtonClick() {
        play(BUTTON_CLICK);
    }

    public static void playLevelCompleted() {
        play(LEVEL_COMPLETED);
    }

    public static void playGameCompleted() {
        play(GAME_COMPLETED);
    }

    public static void playScenarioCorrect() {
        play(SCENARIO_CORRECT);
    }

    public static void playScenarioIncorrect() {
        play(SCENARIO_INCORRECT);
    }

    public static void playCelebration() {
        play(CELEBRATION);
    }

    public static boolean isMuted() {
        return muted;
    }

    public static void setMuted(boolean isMuted) {
        muted = isMuted;
    }

    public static boolean toggleMute() {
        muted = !muted;
        return muted;
    }

    // =========================================================================
    // PROCEDURAL AUDIO SYNTHESIZERS (High Quality 44.1kHz 16-bit PCM Audio)
    // =========================================================================

    private static byte[] generateCardFlip() {
        int sampleRate = 44100;
        double duration = 0.08;
        int totalSamples = (int) (sampleRate * duration);
        byte[] buffer = new byte[totalSamples * 2];

        for (int i = 0; i < totalSamples; i++) {
            double t = (double) i / sampleRate;
            double freq = 700 + (t / duration) * 800; // Rising whoosh click
            double env = Math.exp(-t * 40.0); // Fast decay
            double sample = Math.sin(2.0 * Math.PI * freq * t) * env * 0.45;

            short s = (short) (sample * Short.MAX_VALUE);
            buffer[i * 2] = (byte) (s & 0xFF);
            buffer[i * 2 + 1] = (byte) ((s >> 8) & 0xFF);
        }
        return buffer;
    }

    private static byte[] generateButtonClick() {
        int sampleRate = 44100;
        double duration = 0.05;
        int totalSamples = (int) (sampleRate * duration);
        byte[] buffer = new byte[totalSamples * 2];

        for (int i = 0; i < totalSamples; i++) {
            double t = (double) i / sampleRate;
            double env = Math.exp(-t * 60.0);
            double sample = Math.sin(2.0 * Math.PI * 1200 * t) * env * 0.35;

            short s = (short) (sample * Short.MAX_VALUE);
            buffer[i * 2] = (byte) (s & 0xFF);
            buffer[i * 2 + 1] = (byte) ((s >> 8) & 0xFF);
        }
        return buffer;
    }

    private static byte[] generateCorrectMatch() {
        // Cheerful ascending 3-note chime: C5 (523Hz) -> E5 (659Hz) -> G5 (784Hz)
        int sampleRate = 44100;
        double duration = 0.35;
        int totalSamples = (int) (sampleRate * duration);
        byte[] buffer = new byte[totalSamples * 2];

        double[] notes = {523.25, 659.25, 783.99};
        double noteDuration = duration / 3.0;

        for (int i = 0; i < totalSamples; i++) {
            double t = (double) i / sampleRate;
            int noteIndex = Math.min(2, (int) (t / noteDuration));
            double noteTime = t - (noteIndex * noteDuration);
            double freq = notes[noteIndex];

            double env = Math.exp(-noteTime * 8.0);
            double sample = (Math.sin(2.0 * Math.PI * freq * t) + 0.3 * Math.sin(2.0 * Math.PI * freq * 2 * t)) * env * 0.5;

            short s = (short) (sample * Short.MAX_VALUE);
            buffer[i * 2] = (byte) (s & 0xFF);
            buffer[i * 2 + 1] = (byte) ((s >> 8) & 0xFF);
        }
        return buffer;
    }

    private static byte[] generateWrongMatch() {
        // Gentle descending boop: 340Hz -> 220Hz
        int sampleRate = 44100;
        double duration = 0.22;
        int totalSamples = (int) (sampleRate * duration);
        byte[] buffer = new byte[totalSamples * 2];

        for (int i = 0; i < totalSamples; i++) {
            double t = (double) i / sampleRate;
            double freq = 340.0 - (t / duration) * 120.0;
            double env = Math.exp(-t * 10.0);
            double sample = Math.sin(2.0 * Math.PI * freq * t) * env * 0.4;

            short s = (short) (sample * Short.MAX_VALUE);
            buffer[i * 2] = (byte) (s & 0xFF);
            buffer[i * 2 + 1] = (byte) ((s >> 8) & 0xFF);
        }
        return buffer;
    }

    private static byte[] generateScenarioCorrect() {
        // Cyber success chime: C5 (523Hz) -> G5 (784Hz) -> C6 (1046Hz)
        int sampleRate = 44100;
        double duration = 0.4;
        int totalSamples = (int) (sampleRate * duration);
        byte[] buffer = new byte[totalSamples * 2];

        double[] notes = {523.25, 783.99, 1046.50};
        double noteDuration = duration / 3.0;

        for (int i = 0; i < totalSamples; i++) {
            double t = (double) i / sampleRate;
            int noteIndex = Math.min(2, (int) (t / noteDuration));
            double noteTime = t - (noteIndex * noteDuration);
            double freq = notes[noteIndex];

            double env = Math.exp(-noteTime * 6.0);
            double sample = (Math.sin(2.0 * Math.PI * freq * t) + 0.25 * Math.sin(2.0 * Math.PI * freq * 3 * t)) * env * 0.55;

            short s = (short) (sample * Short.MAX_VALUE);
            buffer[i * 2] = (byte) (s & 0xFF);
            buffer[i * 2 + 1] = (byte) ((s >> 8) & 0xFF);
        }
        return buffer;
    }

    private static byte[] generateScenarioWrong() {
        // Gentle double pulse
        int sampleRate = 44100;
        double duration = 0.25;
        int totalSamples = (int) (sampleRate * duration);
        byte[] buffer = new byte[totalSamples * 2];

        for (int i = 0; i < totalSamples; i++) {
            double t = (double) i / sampleRate;
            double env = (t < 0.12) ? Math.exp(-t * 20.0) : Math.exp(-(t - 0.12) * 20.0);
            double sample = Math.sin(2.0 * Math.PI * 260.0 * t) * env * 0.35;

            short s = (short) (sample * Short.MAX_VALUE);
            buffer[i * 2] = (byte) (s & 0xFF);
            buffer[i * 2 + 1] = (byte) ((s >> 8) & 0xFF);
        }
        return buffer;
    }

    private static byte[] generateLevelComplete() {
        // Arpeggio Fanfare: C4 (261Hz) -> E4 (329Hz) -> G4 (392Hz) -> C5 (523Hz) -> E5 (659Hz)
        int sampleRate = 44100;
        double duration = 0.65;
        int totalSamples = (int) (sampleRate * duration);
        byte[] buffer = new byte[totalSamples * 2];

        double[] notes = {261.63, 329.63, 392.00, 523.25, 659.25};
        double noteDuration = duration / 5.0;

        for (int i = 0; i < totalSamples; i++) {
            double t = (double) i / sampleRate;
            int noteIndex = Math.min(4, (int) (t / noteDuration));
            double noteTime = t - (noteIndex * noteDuration);
            double freq = notes[noteIndex];

            double env = (noteIndex == 4) ? Math.exp(-noteTime * 3.5) : Math.exp(-noteTime * 6.0);
            double sample = (Math.sin(2.0 * Math.PI * freq * t) + 0.35 * Math.sin(2.0 * Math.PI * freq * 2 * t)) * env * 0.55;

            short s = (short) (sample * Short.MAX_VALUE);
            buffer[i * 2] = (byte) (s & 0xFF);
            buffer[i * 2 + 1] = (byte) ((s >> 8) & 0xFF);
        }
        return buffer;
    }

    private static byte[] generateGameComplete() {
        // Triumphant victory fanfare
        int sampleRate = 44100;
        double duration = 0.85;
        int totalSamples = (int) (sampleRate * duration);
        byte[] buffer = new byte[totalSamples * 2];

        double[] notes = {392.00, 523.25, 659.25, 783.99, 1046.50};
        double noteDuration = duration / 5.0;

        for (int i = 0; i < totalSamples; i++) {
            double t = (double) i / sampleRate;
            int noteIndex = Math.min(4, (int) (t / noteDuration));
            double noteTime = t - (noteIndex * noteDuration);
            double freq = notes[noteIndex];

            double env = (noteIndex == 4) ? Math.exp(-noteTime * 2.5) : Math.exp(-noteTime * 5.0);
            double sample = (Math.sin(2.0 * Math.PI * freq * t) + 0.3 * Math.sin(2.0 * Math.PI * freq * 2 * t)) * env * 0.6;

            short s = (short) (sample * Short.MAX_VALUE);
            buffer[i * 2] = (byte) (s & 0xFF);
            buffer[i * 2 + 1] = (byte) ((s >> 8) & 0xFF);
        }
        return buffer;
    }

    private static byte[] generateCelebration() {
        // Sparkling victory arpeggio with high bells
        int sampleRate = 44100;
        double duration = 0.75;
        int totalSamples = (int) (sampleRate * duration);
        byte[] buffer = new byte[totalSamples * 2];

        double[] notes = {523.25, 659.25, 783.99, 1046.50, 1318.51};
        double noteDuration = duration / 5.0;

        for (int i = 0; i < totalSamples; i++) {
            double t = (double) i / sampleRate;
            int noteIndex = Math.min(4, (int) (t / noteDuration));
            double noteTime = t - (noteIndex * noteDuration);
            double freq = notes[noteIndex];

            double env = Math.exp(-noteTime * 4.0);
            double sample = (Math.sin(2.0 * Math.PI * freq * t) + 0.4 * Math.sin(2.0 * Math.PI * freq * 2.0 * t)) * env * 0.5;

            short s = (short) (sample * Short.MAX_VALUE);
            buffer[i * 2] = (byte) (s & 0xFF);
            buffer[i * 2 + 1] = (byte) ((s >> 8) & 0xFF);
        }
        return buffer;
    }

    private static void writeWavFile(File file, byte[] pcmData, int sampleRate, int bitsPerSample, int channels) throws IOException {
        int byteRate = sampleRate * channels * (bitsPerSample / 8);
        int blockAlign = channels * (bitsPerSample / 8);
        int dataLength = pcmData.length;
        int totalLength = 36 + dataLength;

        try (FileOutputStream fos = new FileOutputStream(file);
             DataOutputStream dos = new DataOutputStream(fos)) {

            // RIFF header
            dos.writeBytes("RIFF");
            dos.write(intToByteArray(totalLength));
            dos.writeBytes("WAVE");

            // fmt subchunk
            dos.writeBytes("fmt ");
            dos.write(intToByteArray(16)); // SubChunk1Size (16 for PCM)
            dos.write(shortToByteArray((short) 1)); // AudioFormat (1 for PCM)
            dos.write(shortToByteArray((short) channels));
            dos.write(intToByteArray(sampleRate));
            dos.write(intToByteArray(byteRate));
            dos.write(shortToByteArray((short) blockAlign));
            dos.write(shortToByteArray((short) bitsPerSample));

            // data subchunk
            dos.writeBytes("data");
            dos.write(intToByteArray(dataLength));
            dos.write(pcmData);
        }
    }

    private static byte[] intToByteArray(int value) {
        return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array();
    }

    private static byte[] shortToByteArray(short value) {
        return ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(value).array();
    }
}
