package data;

public class GameRecord {

    private String id;
    private String playerName;
    private int playerAge;
    private String mode;      // "Matching" or "Scenario"
    private String theme;     // e.g. "Fruits", "Daily Life"
    private String level;     // "Easy", "Medium", "Hard"
    private int score;
    private int timeSeconds;
    private int moves;
    private String date;      // e.g. "27 Aug 2026"
    private String result;    // "Completed"

    public GameRecord() {
    }

    public GameRecord(
            String id,
            String playerName,
            int playerAge,
            String mode,
            String theme,
            String level,
            int score,
            int timeSeconds,
            int moves,
            String date,
            String result
    ) {
        this.id = id;
        this.playerName = playerName;
        this.playerAge = playerAge;
        this.mode = mode;
        this.theme = theme;
        this.level = level;
        this.score = score;
        this.timeSeconds = timeSeconds;
        this.moves = moves;
        this.date = date;
        this.result = result;
    }

    public String getId() {
        return id;
    }

    public String getPlayerName() {
        return playerName;
    }

    public int getPlayerAge() {
        return playerAge;
    }

    public String getMode() {
        return mode;
    }

    public String getTheme() {
        return theme;
    }

    public String getLevel() {
        return level;
    }

    public int getScore() {
        return score;
    }

    public int getTimeSeconds() {
        return timeSeconds;
    }

    public int getMoves() {
        return moves;
    }

    public String getDate() {
        return date;
    }

    public String getResult() {
        return result;
    }

    public String getFormattedTime() {
        int m = timeSeconds / 60;
        int s = timeSeconds % 60;
        return String.format("%02d:%02d", m, s);
    }
}
