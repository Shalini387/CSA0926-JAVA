package data;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class DataManager {

    private static final String DATA_DIR = "data";
    private static final String DATA_FILE = "data/game_records.json";
    private static final List<GameRecord> records = new ArrayList<>();
    private static boolean initialized = false;

    public static synchronized void init() {
        if (initialized) return;
        initialized = true;

        File dir = new File(DATA_DIR);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        loadRecords();

        // Seed with a few initial demo records if file is brand new
        if (records.isEmpty()) {
            addRecord(new GameRecord(UUID.randomUUID().toString(), "Rahul", 12, "Matching", "Fruits", "Hard", 95, 151, 38, getTodayDate(), "Completed"));
            addRecord(new GameRecord(UUID.randomUUID().toString(), "Hari", 10, "Scenario", "Daily Life", "Medium", 90, 190, 14, getTodayDate(), "Completed"));
            addRecord(new GameRecord(UUID.randomUUID().toString(), "Anu", 8, "Matching", "Animals", "Easy", 85, 165, 22, getTodayDate(), "Completed"));
        }
    }

    public static synchronized void addRecord(GameRecord record) {
        records.add(record);
        saveRecords();
    }

    public static synchronized void saveCompletedGame(
            String playerName,
            int playerAge,
            String mode,
            String theme,
            String level,
            int score,
            int timeSeconds,
            int moves
    ) {
        GameRecord record = new GameRecord(
                UUID.randomUUID().toString(),
                playerName,
                playerAge,
                mode,
                theme,
                level,
                score,
                timeSeconds,
                moves,
                getTodayDate(),
                "Completed"
        );
        addRecord(record);
    }

    public static synchronized List<GameRecord> getAllRecords() {
        return new ArrayList<>(records);
    }

    public static synchronized List<GameRecord> getLeaderboard() {
        List<GameRecord> sorted = new ArrayList<>(records);
        sorted.sort((a, b) -> {
            if (b.getScore() != a.getScore()) {
                return Integer.compare(b.getScore(), a.getScore()); // Higher score first
            }
            return Integer.compare(a.getTimeSeconds(), b.getTimeSeconds()); // Lower time first
        });
        return sorted;
    }

    public static synchronized List<GameRecord> getLeaderboardByMode(String mode) {
        if (mode == null || mode.equalsIgnoreCase("ALL")) {
            return getLeaderboard();
        }
        List<GameRecord> filtered = new ArrayList<>();
        for (GameRecord r : getLeaderboard()) {
            if (r.getMode().equalsIgnoreCase(mode)) {
                filtered.add(r);
            }
        }
        return filtered;
    }

    public static synchronized List<GameRecord> getPlayerHistory(String playerName) {
        List<GameRecord> history = new ArrayList<>();
        for (int i = records.size() - 1; i >= 0; i--) {
            GameRecord r = records.get(i);
            if (r.getPlayerName().equalsIgnoreCase(playerName)) {
                history.add(r);
            }
        }
        return history;
    }

    public static class PlayerStats {
        public int totalGamesPlayed = 0;
        public int matchingCompleted = 0;
        public int scenarioCompleted = 0;
        public int totalScore = 0;
        public int bestScore = 0;
        public int totalTimeSeconds = 0;
        public int totalMoves = 0;

        public String getFormattedTotalTime() {
            int m = totalTimeSeconds / 60;
            int s = totalTimeSeconds % 60;
            return String.format("%02d:%02d", m, s);
        }
    }

    public static synchronized PlayerStats getPlayerStats(String playerName) {
        PlayerStats stats = new PlayerStats();
        for (GameRecord r : records) {
            if (r.getPlayerName().equalsIgnoreCase(playerName)) {
                stats.totalGamesPlayed++;
                if ("Matching".equalsIgnoreCase(r.getMode())) {
                    stats.matchingCompleted++;
                } else if ("Scenario".equalsIgnoreCase(r.getMode())) {
                    stats.scenarioCompleted++;
                }
                stats.totalScore += r.getScore();
                if (r.getScore() > stats.bestScore) {
                    stats.bestScore = r.getScore();
                }
                stats.totalTimeSeconds += r.getTimeSeconds();
                stats.totalMoves += r.getMoves();
            }
        }
        return stats;
    }

    public static synchronized int calculateRank(int score, int timeSeconds) {
        List<GameRecord> board = getLeaderboard();
        int rank = 1;
        for (GameRecord r : board) {
            if (r.getScore() > score) {
                rank++;
            } else if (r.getScore() == score && r.getTimeSeconds() < timeSeconds) {
                rank++;
            }
        }
        return rank;
    }

    public static String getTodayDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH);
        return sdf.format(new Date());
    }

    // =========================================================================
    // LOCAL JSON PERSISTENCE
    // =========================================================================

    private static synchronized void loadRecords() {
        records.clear();
        File file = new File(DATA_FILE);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line.trim());
            }

            String json = sb.toString();
            if (json.startsWith("[") && json.endsWith("]")) {
                parseJsonArray(json);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void parseJsonArray(String json) {
        // Simple and robust JSON parser for game records
        String content = json.substring(1, json.length() - 1).trim();
        if (content.isEmpty()) return;

        String[] objects = content.split("\\},\\s*\\{");
        for (String objStr : objects) {
            objStr = objStr.replace("{", "").replace("}", "");
            String[] pairs = objStr.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)");

            Map<String, String> map = new HashMap<>();
            for (String pair : pairs) {
                String[] kv = pair.split(":", 2);
                if (kv.length == 2) {
                    String k = kv[0].replace("\"", "").trim();
                    String v = kv[1].replace("\"", "").trim();
                    map.put(k, v);
                }
            }

            if (map.containsKey("playerName")) {
                GameRecord r = new GameRecord(
                        map.getOrDefault("id", UUID.randomUUID().toString()),
                        map.getOrDefault("playerName", "Player"),
                        parseInt(map.get("playerAge"), 10),
                        map.getOrDefault("mode", "Matching"),
                        map.getOrDefault("theme", "Fruits"),
                        map.getOrDefault("level", "Easy"),
                        parseInt(map.get("score"), 0),
                        parseInt(map.get("timeSeconds"), 0),
                        parseInt(map.get("moves"), 0),
                        map.getOrDefault("date", getTodayDate()),
                        map.getOrDefault("result", "Completed")
                );
                records.add(r);
            }
        }
    }

    private static int parseInt(String val, int def) {
        if (val == null) return def;
        try {
            return Integer.parseInt(val.trim());
        } catch (NumberFormatException e) {
            return def;
        }
    }

    private static synchronized void saveRecords() {
        File file = new File(DATA_FILE);
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"))) {
            writer.write("[\n");
            for (int i = 0; i < records.size(); i++) {
                GameRecord r = records.get(i);
                writer.write("  {\n");
                writer.write("    \"id\": \"" + escapeJson(r.getId()) + "\",\n");
                writer.write("    \"playerName\": \"" + escapeJson(r.getPlayerName()) + "\",\n");
                writer.write("    \"playerAge\": " + r.getPlayerAge() + ",\n");
                writer.write("    \"mode\": \"" + escapeJson(r.getMode()) + "\",\n");
                writer.write("    \"theme\": \"" + escapeJson(r.getTheme()) + "\",\n");
                writer.write("    \"level\": \"" + escapeJson(r.getLevel()) + "\",\n");
                writer.write("    \"score\": " + r.getScore() + ",\n");
                writer.write("    \"timeSeconds\": " + r.getTimeSeconds() + ",\n");
                writer.write("    \"moves\": " + r.getMoves() + ",\n");
                writer.write("    \"date\": \"" + escapeJson(r.getDate()) + "\",\n");
                writer.write("    \"result\": \"" + escapeJson(r.getResult()) + "\"\n");
                writer.write("  }" + (i < records.size() - 1 ? "," : "") + "\n");
            }
            writer.write("]\n");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
