package gui;

import app.Main;
import data.DataManager;
import data.GameRecord;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

public class DashboardPanel extends JPanel {

    public DashboardPanel() {
        setLayout(new BorderLayout());
        setOpaque(false);

        DataManager.init();
        DataManager.PlayerStats stats = DataManager.getPlayerStats(Main.playerName);

        BackgroundPanel bg = new BackgroundPanel();
        bg.setLayout(new BorderLayout(16, 14));
        bg.setBorder(BorderFactory.createEmptyBorder(20, 36, 20, 36));

        // =====================================
        // HEADER & PLAYER PROFILE
        // =====================================
        JPanel header = new JPanel(new BorderLayout(10, 8));
        header.setOpaque(false);

        JPanel titleBox = new JPanel();
        titleBox.setLayout(new BoxLayout(titleBox, BoxLayout.Y_AXIS));
        titleBox.setOpaque(false);

        JLabel title = new JLabel("PLAYER DASHBOARD");
        title.setFont(UITheme.getTitleFont(30));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("Track your brain training progress, stats, and completed game history");
        subtitle.setFont(UITheme.getFont(Font.PLAIN, 14));
        subtitle.setForeground(new Color(203, 213, 225));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        titleBox.add(title);
        titleBox.add(Box.createVerticalStrut(2));
        titleBox.add(subtitle);

        // Player profile chip
        JPanel playerBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 4));
        playerBar.setOpaque(false);

        JLabel playerBadge = new JLabel("PLAYER: " + Main.playerName.toUpperCase() + " (" + Main.playerAge + " YRS)");
        playerBadge.setFont(UITheme.getFont(Font.BOLD, 14));
        playerBadge.setForeground(new Color(251, 191, 36));
        playerBadge.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(251, 191, 36, 140), 1, true),
                BorderFactory.createEmptyBorder(4, 14, 4, 14)
        ));

        GradientButton switchBtn = new GradientButton("SWITCH PLAYER", UITheme.GRADIENT_CYAN);
        switchBtn.setFont(UITheme.getFont(Font.BOLD, 11));
        switchBtn.setPreferredSize(new Dimension(130, 28));
        switchBtn.setGlassMode(true);
        switchBtn.addActionListener(e -> Main.showPlayerSetup());

        playerBar.add(playerBadge);
        playerBar.add(switchBtn);

        header.add(titleBox, BorderLayout.NORTH);
        header.add(playerBar, BorderLayout.SOUTH);
        bg.add(header, BorderLayout.NORTH);

        // =====================================
        // CENTER: STATS GRID & HISTORY TABLE
        // =====================================
        JPanel center = new JPanel(new BorderLayout(14, 14));
        center.setOpaque(false);

        // Top Statistics 4 Badges
        JPanel statsGrid = new JPanel(new GridLayout(1, 4, 14, 14));
        statsGrid.setOpaque(false);
        statsGrid.setPreferredSize(new Dimension(1100, 78));

        statsGrid.add(new StatBadge("●", "Games Played", String.valueOf(stats.totalGamesPlayed), new Color(6, 182, 212)));
        statsGrid.add(new StatBadge("★", "Matching Won", String.valueOf(stats.matchingCompleted), new Color(16, 185, 129)));
        statsGrid.add(new StatBadge("◆", "Scenario Won", String.valueOf(stats.scenarioCompleted), new Color(139, 92, 246)));
        statsGrid.add(new StatBadge("▲", "Total Score", String.valueOf(stats.totalScore), new Color(245, 158, 11)));

        // Secondary Info Bar: Best Score, Total Time, Total Moves
        JPanel subStats = new JPanel(new FlowLayout(FlowLayout.CENTER, 28, 4));
        subStats.setOpaque(false);

        JLabel bestLabel = new JLabel("Best Score: " + stats.bestScore + " pts");
        bestLabel.setFont(UITheme.getFont(Font.BOLD, 13));
        bestLabel.setForeground(new Color(251, 191, 36));

        JLabel timeTotalLabel = new JLabel("Total Time: " + stats.getFormattedTotalTime());
        timeTotalLabel.setFont(UITheme.getFont(Font.BOLD, 13));
        timeTotalLabel.setForeground(new Color(203, 213, 225));

        JLabel movesTotalLabel = new JLabel("Total Moves: " + stats.totalMoves);
        movesTotalLabel.setFont(UITheme.getFont(Font.BOLD, 13));
        movesTotalLabel.setForeground(new Color(203, 213, 225));

        subStats.add(bestLabel);
        subStats.add(timeTotalLabel);
        subStats.add(movesTotalLabel);

        JPanel topContainer = new JPanel(new BorderLayout(4, 4));
        topContainer.setOpaque(false);
        topContainer.add(statsGrid, BorderLayout.NORTH);
        topContainer.add(subStats, BorderLayout.SOUTH);
        center.add(topContainer, BorderLayout.NORTH);

        // My Game History Table Card
        JPanel tableCard = new JPanel(new BorderLayout(8, 6)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                int w = getWidth();
                int h = getHeight();

                g2.setColor(new Color(30, 41, 59, 210));
                g2.fill(new RoundRectangle2D.Double(0, 0, w, h, 20, 20));

                g2.setColor(new Color(255, 255, 255, 30));
                g2.setStroke(new BasicStroke(1.2f));
                g2.draw(new RoundRectangle2D.Double(1, 1, w - 2, h - 2, 20, 20));

                g2.dispose();
            }
        };
        tableCard.setOpaque(false);
        tableCard.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));

        JLabel tableTitle = new JLabel("MY GAME HISTORY");
        tableTitle.setFont(UITheme.getFont(Font.BOLD, 14));
        tableTitle.setForeground(new Color(251, 191, 36));

        // Create JTable
        String[] columns = {"Date", "Mode", "Theme / Category", "Difficulty", "Score", "Time", "Result"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        List<GameRecord> history = DataManager.getPlayerHistory(Main.playerName);
        if (history.isEmpty()) {
            model.addRow(new Object[]{"-", "No games played yet", "-", "-", "-", "-", "-"});
        } else {
            for (GameRecord r : history) {
                model.addRow(new Object[]{
                        r.getDate(),
                        r.getMode(),
                        r.getTheme(),
                        r.getLevel(),
                        r.getScore(),
                        r.getFormattedTime(),
                        r.getResult()
                });
            }
        }

        JTable table = new JTable(model);
        table.setRowHeight(30);
        table.setFont(UITheme.getFont(Font.PLAIN, 13));
        table.setForeground(Color.WHITE);
        table.setBackground(new Color(15, 23, 42));
        table.setSelectionBackground(new Color(99, 102, 241, 120));
        table.setSelectionForeground(Color.WHITE);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 2));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JTableHeader th = table.getTableHeader();
        th.setFont(UITheme.getFont(Font.BOLD, 13));
        th.setBackground(new Color(30, 41, 59));
        th.setForeground(new Color(203, 213, 225));
        th.setPreferredSize(new Dimension(100, 32));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        tableCard.add(tableTitle, BorderLayout.NORTH);
        tableCard.add(scrollPane, BorderLayout.CENTER);
        center.add(tableCard, BorderLayout.CENTER);

        bg.add(center, BorderLayout.CENTER);

        // =====================================
        // FOOTER BUTTONS
        // =====================================
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 0));
        footer.setOpaque(false);

        GradientButton playMatch = new GradientButton("PLAY MATCHING ->", UITheme.GRADIENT_PRIMARY);
        playMatch.setPreferredSize(new Dimension(190, 44));
        playMatch.addActionListener(e -> Main.showThemePanel());

        GradientButton playScen = new GradientButton("PLAY SCENARIOS ->", UITheme.GRADIENT_SECONDARY);
        playScen.setPreferredSize(new Dimension(190, 44));
        playScen.addActionListener(e -> Main.showScenarioMode());

        GradientButton leadBtn = new GradientButton("LEADERBOARD", UITheme.GRADIENT_AMBER);
        leadBtn.setPreferredSize(new Dimension(160, 44));
        leadBtn.addActionListener(e -> Main.showLeaderboard());

        GradientButton homeBtn = new GradientButton("HOME", UITheme.GRADIENT_CYAN);
        homeBtn.setPreferredSize(new Dimension(130, 44));
        homeBtn.setGlassMode(true);
        homeBtn.addActionListener(e -> Main.showHomeScreen());

        footer.add(homeBtn);
        footer.add(playMatch);
        footer.add(playScen);
        footer.add(leadBtn);

        bg.add(footer, BorderLayout.SOUTH);

        add(bg, BorderLayout.CENTER);
    }
}
