package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

public class GradientButton extends JButton {

    private Color colorStart;
    private Color colorEnd;
    private int cornerRadius = 18;
    private boolean isHovered = false;
    private boolean isPressed = false;
    private boolean isGlass = false;
    private Color customTextColor = Color.WHITE;

    public GradientButton(String text) {
        this(text, UITheme.GRADIENT_PRIMARY[0], UITheme.GRADIENT_PRIMARY[1]);
    }

    public GradientButton(String text, Color[] gradient) {
        this(text, gradient[0], gradient[1]);
    }

    public GradientButton(String text, Color colorStart, Color colorEnd) {
        super(text);
        this.colorStart = colorStart;
        this.colorEnd = colorEnd;

        setFont(UITheme.getFont(Font.BOLD, 16));
        setForeground(customTextColor);
        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setOpaque(false);
        setCursor(new Cursor(Cursor.HAND_CURSOR));

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (isEnabled()) {
                    isHovered = true;
                    repaint();
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                isHovered = false;
                repaint();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                if (isEnabled()) {
                    isPressed = true;
                    repaint();
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                isPressed = false;
                repaint();
            }
        });
    }

    public void setGradient(Color start, Color end) {
        this.colorStart = start;
        this.colorEnd = end;
        repaint();
    }

    public void setGradient(Color[] gradient) {
        if (gradient != null && gradient.length >= 2) {
            setGradient(gradient[0], gradient[1]);
        }
    }

    public void setCornerRadius(int radius) {
        this.cornerRadius = radius;
        repaint();
    }

    public void setGlassMode(boolean glass) {
        this.isGlass = glass;
        repaint();
    }

    public void setCustomTextColor(Color c) {
        this.customTextColor = c;
        setForeground(c);
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        UITheme.setRenderingHints(g2);

        int w = getWidth();
        int h = getHeight();

        if (w <= 0 || h <= 0) {
            g2.dispose();
            return;
        }

        int x = 2;
        int y = isPressed ? 3 : 2;
        int width = w - 4;
        int height = h - (isPressed ? 3 : 5);

        if (!isEnabled()) {
            g2.setColor(new Color(100, 116, 139, 100));
            g2.fill(new RoundRectangle2D.Double(x, y, width, height, cornerRadius, cornerRadius));
        } else if (isGlass) {
            // Translucent glass style
            Color glassBg = isHovered ? new Color(255, 255, 255, 60) : new Color(255, 255, 255, 30);
            g2.setColor(glassBg);
            g2.fill(new RoundRectangle2D.Double(x, y, width, height, cornerRadius, cornerRadius));

            // Glowing border
            Color borderColor = isHovered ? new Color(255, 255, 255, 200) : new Color(255, 255, 255, 100);
            g2.setColor(borderColor);
            g2.setStroke(new BasicStroke(1.5f));
            g2.draw(new RoundRectangle2D.Double(x, y, width, height, cornerRadius, cornerRadius));
        } else {
            // Drop shadow
            if (!isPressed) {
                g2.setColor(new Color(0, 0, 0, 35));
                g2.fill(new RoundRectangle2D.Double(x, y + 3, width, height, cornerRadius, cornerRadius));
            }

            // Button gradient
            Color start = colorStart;
            Color end = colorEnd;

            if (isHovered && !isPressed) {
                start = brighten(colorStart, 25);
                end = brighten(colorEnd, 25);
            } else if (isPressed) {
                start = darken(colorStart, 25);
                end = darken(colorEnd, 25);
            }

            GradientPaint gp = new GradientPaint(x, y, start, x + width, y + height, end);
            g2.setPaint(gp);
            g2.fill(new RoundRectangle2D.Double(x, y, width, height, cornerRadius, cornerRadius));

            // Subtle top highlight sheen
            if (!isPressed) {
                GradientPaint sheen = new GradientPaint(
                        x, y, new Color(255, 255, 255, 70),
                        x, y + height / 2, new Color(255, 255, 255, 0)
                );
                g2.setPaint(sheen);
                g2.fill(new RoundRectangle2D.Double(x, y, width, height / 2.0, cornerRadius, cornerRadius));
            }

            // Outline glow on hover
            if (isHovered) {
                g2.setColor(new Color(255, 255, 255, 120));
                g2.setStroke(new BasicStroke(1.5f));
                g2.draw(new RoundRectangle2D.Double(x, y, width, height, cornerRadius, cornerRadius));
            }
        }

        // Draw text & icon
        FontMetrics fm = g2.getFontMetrics(getFont());
        String text = getText();

        if (text != null && !text.isEmpty()) {
            if (text.startsWith("<html>")) {
                // Let Swing handle HTML rendering
                super.paintComponent(g);
                g2.dispose();
                return;
            }

            int textX = (w - fm.stringWidth(text)) / 2;
            int textY = (h - fm.getHeight()) / 2 + fm.getAscent() + (isPressed ? 1 : 0);

            // Text shadow for primary button
            if (!isGlass && isEnabled()) {
                g2.setColor(new Color(0, 0, 0, 80));
                g2.drawString(text, textX, textY + 1);
            }

            g2.setColor(isEnabled() ? customTextColor : new Color(203, 213, 225, 140));
            g2.drawString(text, textX, textY);
        }

        g2.dispose();
    }

    private Color brighten(Color c, int amount) {
        int r = Math.min(255, c.getRed() + amount);
        int g = Math.min(255, c.getGreen() + amount);
        int b = Math.min(255, c.getBlue() + amount);
        return new Color(r, g, b, c.getAlpha());
    }

    private Color darken(Color c, int amount) {
        int r = Math.max(0, c.getRed() - amount);
        int g = Math.max(0, c.getGreen() - amount);
        int b = Math.max(0, c.getBlue() - amount);
        return new Color(r, g, b, c.getAlpha());
    }
}
