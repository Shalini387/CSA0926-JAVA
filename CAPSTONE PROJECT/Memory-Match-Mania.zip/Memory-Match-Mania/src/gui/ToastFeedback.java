package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class ToastFeedback extends JPanel {

    private String message = "";
    private Color bgColor = new Color(16, 185, 129, 230); // Default emerald green
    private Color borderColor = new Color(5, 150, 105);
    private javax.swing.Timer fadeTimer;
    private float opacity = 0f;

    public ToastFeedback() {
        setOpaque(false);
        setVisible(false);
    }

    public void showPositive(String message) {
        showToast(message, new Color(16, 185, 129, 235), new Color(5, 150, 105));
    }

    public void showGentle(String message) {
        showToast(message, new Color(245, 158, 11, 235), new Color(217, 119, 6));
    }

    public void showToast(String message, Color bg, Color border) {
        this.message = message;
        this.bgColor = bg;
        this.borderColor = border;
        this.opacity = 1.0f;

        if (fadeTimer != null && fadeTimer.isRunning()) {
            fadeTimer.stop();
        }

        setVisible(true);
        repaint();

        fadeTimer = new javax.swing.Timer(1500, e -> {
            setVisible(false);
            fadeTimer.stop();
        });
        fadeTimer.setRepeats(false);
        fadeTimer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        if (!isVisible() || message == null || message.isEmpty()) return;

        Graphics2D g2 = (Graphics2D) g.create();
        UITheme.setRenderingHints(g2);

        int w = getWidth();
        int h = getHeight();

        // Calculate text width
        g2.setFont(UITheme.getFont(Font.BOLD, 15));
        FontMetrics fm = g2.getFontMetrics();
        int textW = fm.stringWidth(message);
        int pillW = textW + 36;
        int pillH = 38;

        int px = (w - pillW) / 2;
        int py = (h - pillH) / 2;

        // Shadow
        g2.setColor(new Color(0, 0, 0, 40));
        g2.fill(new RoundRectangle2D.Double(px, py + 2, pillW, pillH, 19, 19));

        // Background pill
        g2.setColor(bgColor);
        g2.fill(new RoundRectangle2D.Double(px, py, pillW, pillH, 19, 19));

        // Border
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(1.5f));
        g2.draw(new RoundRectangle2D.Double(px, py, pillW, pillH, 19, 19));

        // Text
        g2.setColor(Color.WHITE);
        int tx = px + (pillW - textW) / 2;
        int ty = py + (pillH - fm.getHeight()) / 2 + fm.getAscent();
        g2.drawString(message, tx, ty);

        g2.dispose();
    }
}
