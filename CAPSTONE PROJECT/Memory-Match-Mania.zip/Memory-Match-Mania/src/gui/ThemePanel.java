package gui;

import app.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class ThemePanel extends JPanel {

    private final String[] themes = {
            "Animals",
            "Fruits",
            "Vehicles",
            "Sports",
            "Space",
            "Nature",
            "Technology",
            "Food",
            "Ocean",
            "Emoji"
    };

    public ThemePanel() {
        setLayout(new BorderLayout());
        setOpaque(false);

        BackgroundPanel bg = new BackgroundPanel();
        bg.setLayout(new BorderLayout(20, 20));
        bg.setBorder(BorderFactory.createEmptyBorder(25, 40, 25, 40));

        // =====================================
        // HEADER
        // =====================================
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setOpaque(false);

        JLabel title = new JLabel("CHOOSE A THEME");
        title.setFont(UITheme.getTitleFont(32));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("Pick your favorite category to start matching cards!");
        subtitle.setFont(UITheme.getFont(Font.PLAIN, 15));
        subtitle.setForeground(new Color(203, 213, 225));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        header.add(title);
        header.add(Box.createVerticalStrut(4));
        header.add(subtitle);
        bg.add(header, BorderLayout.NORTH);

        // =====================================
        // THEME GRID
        // =====================================
        JPanel grid = new JPanel(new GridLayout(2, 5, 16, 16));
        grid.setOpaque(false);

        for (String themeName : themes) {
            UITheme.ThemeInfo info = UITheme.getThemeInfo(themeName);

            JButton themeBtn = createThemeButton(info);
            themeBtn.addActionListener(e -> showLevels(themeName));
            grid.add(themeBtn);
        }

        bg.add(grid, BorderLayout.CENTER);

        // =====================================
        // FOOTER
        // =====================================
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footer.setOpaque(false);

        GradientButton back = new GradientButton("<- BACK TO HOME", UITheme.GRADIENT_PRIMARY);
        back.setPreferredSize(new Dimension(240, 46));
        back.setGlassMode(true);
        back.addActionListener(e -> Main.showHomeScreen());

        footer.add(back);
        bg.add(footer, BorderLayout.SOUTH);

        add(bg, BorderLayout.CENTER);
    }

    private JButton createThemeButton(UITheme.ThemeInfo info) {
        JButton btn = new JButton() {
            private boolean hovered = false;

            {
                addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseEntered(java.awt.event.MouseEvent e) {
                        hovered = true;
                        repaint();
                    }

                    @Override
                    public void mouseExited(java.awt.event.MouseEvent e) {
                        hovered = false;
                        repaint();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                int w = getWidth();
                int h = getHeight();

                // Drop shadow
                g2.setColor(new Color(0, 0, 0, 40));
                g2.fill(new RoundRectangle2D.Double(2, 4, w - 4, h - 6, 20, 20));

                // Card Gradient
                Color start = info.gradient[0];
                Color end = info.gradient[1];
                if (hovered) {
                    start = new Color(
                            Math.min(255, start.getRed() + 25),
                            Math.min(255, start.getGreen() + 25),
                            Math.min(255, start.getBlue() + 25)
                    );
                    end = new Color(
                            Math.min(255, end.getRed() + 25),
                            Math.min(255, end.getGreen() + 25),
                            Math.min(255, end.getBlue() + 25)
                    );
                }

                GradientPaint gp = new GradientPaint(2, 2, start, w - 4, h - 4, end);
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Double(2, 2, w - 4, h - 6, 20, 20));

                // Hover glow ring
                if (hovered) {
                    g2.setColor(new Color(255, 255, 255, 170));
                    g2.setStroke(new BasicStroke(2.0f));
                    g2.draw(new RoundRectangle2D.Double(2, 2, w - 4, h - 6, 20, 20));
                }

                // Inner circle badge
                int circleSize = Math.max(38, h / 3 - 6);
                int cx = (w - circleSize) / 2;
                int cy = (h / 2) - circleSize + 2;

                g2.setColor(new Color(255, 255, 255, 45));
                g2.fillOval(cx, cy, circleSize, circleSize);

                // Draw vector theme icon
                UITheme.drawThemeIcon(g2, info.name, cx + circleSize / 2, cy + circleSize / 2, circleSize * 3 / 5);

                // Theme Name
                g2.setFont(UITheme.getFont(Font.BOLD, 17));
                g2.setColor(Color.WHITE);
                FontMetrics fmText = g2.getFontMetrics();
                int tx = (w - fmText.stringWidth(info.name)) / 2;
                int ty = (h / 2) + fmText.getAscent() + 10;
                g2.drawString(info.name, tx, ty);

                // Subtitle
                g2.setFont(UITheme.getFont(Font.PLAIN, 11));
                g2.setColor(new Color(255, 255, 255, 200));
                FontMetrics fmSub = g2.getFontMetrics();
                String sub = "18 Pairs";
                int sx = (w - fmSub.stringWidth(sub)) / 2;
                int sy = ty + fmSub.getAscent() + 4;
                g2.drawString(sub, sx, sy);

                g2.dispose();
            }
        };

        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        return btn;
    }

    private void showLevels(String theme) {
        BackgroundPanel bg = new BackgroundPanel();
        bg.setLayout(new BorderLayout(20, 24));
        bg.setBorder(BorderFactory.createEmptyBorder(30, 80, 30, 80));

        // Header
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setOpaque(false);

        JLabel title = new JLabel(theme.toUpperCase() + " - SELECT LEVEL");
        title.setFont(UITheme.getTitleFont(30));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("Choose difficulty for your " + theme + " memory challenge:");
        subtitle.setFont(UITheme.getFont(Font.PLAIN, 15));
        subtitle.setForeground(new Color(203, 213, 225));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        header.add(title);
        header.add(Box.createVerticalStrut(4));
        header.add(subtitle);
        bg.add(header, BorderLayout.NORTH);

        // Levels container (3 large cards)
        JPanel levelsPanel = new JPanel(new GridLayout(3, 1, 16, 16));
        levelsPanel.setOpaque(false);

        JButton level1 = createLevelCard(
                "LEVEL 1 - EASY",
                "4 x 4 Grid  •  16 Cards  •  8 Matching Pairs",
                "Great for a quick and fun memory warmup",
                UITheme.GRADIENT_SUCCESS,
                () -> startGame(theme, 1)
        );

        JButton level2 = createLevelCard(
                "LEVEL 2 - MEDIUM",
                "5 x 5 Grid  •  25 Cards  •  12 Pairs + 1 Bonus Card",
                "Medium challenge with an extra golden bonus card for +5 pts",
                UITheme.GRADIENT_AMBER,
                () -> startGame(theme, 2)
        );

        JButton level3 = createLevelCard(
                "LEVEL 3 - HARD",
                "6 x 6 Grid  •  36 Cards  •  18 Matching Pairs",
                "High difficulty test of sharp focus and spatial recall",
                UITheme.GRADIENT_SECONDARY,
                () -> startGame(theme, 3)
        );

        levelsPanel.add(level1);
        levelsPanel.add(level2);
        levelsPanel.add(level3);

        bg.add(levelsPanel, BorderLayout.CENTER);

        // Footer
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER));
        footer.setOpaque(false);

        GradientButton back = new GradientButton("<- BACK TO THEMES", UITheme.GRADIENT_PRIMARY);
        back.setPreferredSize(new Dimension(220, 46));
        back.setGlassMode(true);
        back.addActionListener(e -> Main.showThemePanel());

        footer.add(back);
        bg.add(footer, BorderLayout.SOUTH);

        Main.frame.setContentPane(bg);
        Main.frame.revalidate();
        Main.frame.repaint();
    }

    private JButton createLevelCard(
            String title,
            String gridInfo,
            String desc,
            Color[] gradient,
            Runnable onAction
    ) {
        JButton btn = new JButton() {
            private boolean hovered = false;

            {
                addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseEntered(java.awt.event.MouseEvent e) {
                        hovered = true;
                        repaint();
                    }

                    @Override
                    public void mouseExited(java.awt.event.MouseEvent e) {
                        hovered = false;
                        repaint();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                int w = getWidth();
                int h = getHeight();

                // Card background
                g2.setColor(new Color(30, 41, 59, 210));
                g2.fill(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, 20, 20));

                // Left accent gradient bar
                GradientPaint barGp = new GradientPaint(2, 2, gradient[0], 14, h - 2, gradient[1]);
                g2.setPaint(barGp);
                g2.fill(new RoundRectangle2D.Double(2, 2, 10, h - 4, 8, 8));

                // Glow on hover
                if (hovered) {
                    g2.setColor(new Color(gradient[0].getRed(), gradient[0].getGreen(), gradient[0].getBlue(), 80));
                    g2.fill(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, 20, 20));

                    g2.setColor(new Color(gradient[0].getRed(), gradient[0].getGreen(), gradient[0].getBlue(), 200));
                    g2.setStroke(new BasicStroke(2.0f));
                    g2.draw(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, 20, 20));
                } else {
                    g2.setColor(new Color(255, 255, 255, 30));
                    g2.setStroke(new BasicStroke(1.2f));
                    g2.draw(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, 20, 20));
                }

                // Title
                g2.setFont(UITheme.getFont(Font.BOLD, 19));
                g2.setColor(Color.WHITE);
                g2.drawString(title, 36, (h / 2) - 10);

                // Grid Info
                g2.setFont(UITheme.getFont(Font.BOLD, 14));
                g2.setColor(gradient[0]);
                g2.drawString(gridInfo, 36, (h / 2) + 12);

                // Description
                g2.setFont(UITheme.getFont(Font.PLAIN, 13));
                g2.setColor(new Color(203, 213, 225));
                g2.drawString(desc, 36, (h / 2) + 30);

                // Arrow indicator on right
                g2.setFont(UITheme.getFont(Font.BOLD, 20));
                g2.setColor(hovered ? Color.WHITE : new Color(148, 163, 184));
                g2.drawString("->", w - 45, (h / 2) + 8);

                g2.dispose();
            }
        };

        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> onAction.run());

        return btn;
    }

    private void startGame(String theme, int level) {
        Main.startMemoryGame(theme, level);
    }
}