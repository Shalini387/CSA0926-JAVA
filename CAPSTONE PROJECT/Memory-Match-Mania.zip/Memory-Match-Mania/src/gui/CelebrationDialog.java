package gui;

import app.Main;
import util.SoundManager;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CelebrationDialog extends JDialog {

    private final List<Particle> particles = new ArrayList<>();
    private final Timer animationTimer;
    private final Random random = new Random();

    public CelebrationDialog(
            JFrame parent,
            String titleText,
            String playerName,
            int score,
            int timeSeconds,
            int rank,
            int stars,
            String nextButtonText,
            Runnable onNext,
            Runnable onLeaderboard,
            Runnable onDashboard
    ) {
        super(parent, "Victory!", true);
        setUndecorated(true);
        setSize(580, 500);
        setLocationRelativeTo(parent);
        setBackground(new Color(0, 0, 0, 0));

        SoundManager.playCelebration();

        // Spawn initial bursts from both left and right sides
        spawnDualSideFireworks(580, 500);

        JPanel mainPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                int w = getWidth();
                int h = getHeight();

                // Drop shadow
                g2.setColor(new Color(0, 0, 0, 90));
                g2.fill(new RoundRectangle2D.Double(6, 6, w - 12, h - 12, 28, 28));

                // Glass card background
                g2.setColor(new Color(24, 24, 48, 245));
                g2.fill(new RoundRectangle2D.Double(6, 6, w - 12, h - 12, 28, 28));

                // Top golden festival glow
                GradientPaint topGlow = new GradientPaint(
                        0, 0, new Color(245, 158, 11, 120),
                        w, (float) (h * 0.45), new Color(236, 72, 153, 35)
                );
                g2.setPaint(topGlow);
                g2.fill(new RoundRectangle2D.Double(6, 6, w - 12, h - 12, 28, 28));

                // Golden festival border
                g2.setColor(new Color(245, 158, 11, 190));
                g2.setStroke(new BasicStroke(2.2f));
                g2.draw(new RoundRectangle2D.Double(6, 6, w - 12, h - 12, 28, 28));

                // Render dynamic cracker / firework particles
                synchronized (particles) {
                    for (Particle p : particles) {
                        p.render(g2);
                    }
                }

                g2.dispose();
            }
        };

        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setOpaque(false);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(24, 32, 24, 32));

        // Clean plain title without unmapped Unicode glyphs
        String cleanTitle = (titleText != null) ? titleText.replaceAll("[^a-zA-Z0-9 !?—]", "").trim() : "LEVEL COMPLETED!";
        JLabel title = new JLabel(cleanTitle);
        title.setFont(UITheme.getTitleFont(26));
        title.setForeground(new Color(251, 191, 36)); // Gold
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Congratulations subtitle
        JLabel congrats = new JLabel("Congratulations, " + (playerName != null ? playerName : "Player") + "!");
        congrats.setFont(UITheme.getFont(Font.BOLD, 17));
        congrats.setForeground(Color.WHITE);
        congrats.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Star Rating Panel
        JPanel starsPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);

                int w = getWidth();
                int starCount = 3;
                int starSize = 34;
                int spacing = 16;
                int totalW = (starCount * starSize) + ((starCount - 1) * spacing);
                int startX = (w - totalW) / 2;
                int cy = getHeight() / 2;

                for (int i = 0; i < starCount; i++) {
                    int cx = startX + (i * (starSize + spacing)) + starSize / 2;
                    boolean earned = (i < stars);
                    drawGoldStar(g2, cx, cy, starSize / 2, earned);
                }

                g2.dispose();
            }
        };
        starsPanel.setOpaque(false);
        starsPanel.setPreferredSize(new Dimension(460, 44));
        starsPanel.setMaximumSize(new Dimension(460, 44));
        starsPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Stats Summary: SCORE | TIME | RANK
        JPanel statsGrid = new JPanel(new GridLayout(1, 3, 12, 12));
        statsGrid.setOpaque(false);
        statsGrid.setMaximumSize(new Dimension(480, 74));
        statsGrid.setPreferredSize(new Dimension(480, 74));
        statsGrid.setAlignmentX(Component.CENTER_ALIGNMENT);

        int m = timeSeconds / 60;
        int s = timeSeconds % 60;
        String timeFormatted = String.format("%02d:%02d", m, s);

        statsGrid.add(createMiniStat("SCORE", String.valueOf(score), new Color(245, 158, 11)));
        statsGrid.add(createMiniStat("TIME", timeFormatted, new Color(16, 185, 129)));
        statsGrid.add(createMiniStat("RANK", "#" + rank, new Color(139, 92, 246)));

        // Action Buttons Row
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        btnPanel.setOpaque(false);
        btnPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        if (onNext != null && nextButtonText != null) {
            GradientButton nextBtn = new GradientButton(nextButtonText, UITheme.GRADIENT_PRIMARY);
            nextBtn.setPreferredSize(new Dimension(155, 46));
            nextBtn.addActionListener(e -> {
                stopAnimation();
                dispose();
                onNext.run();
            });
            btnPanel.add(nextBtn);
        }

        GradientButton leadBtn = new GradientButton("LEADERBOARD", UITheme.GRADIENT_SECONDARY);
        leadBtn.setPreferredSize(new Dimension(155, 46));
        leadBtn.addActionListener(e -> {
            stopAnimation();
            dispose();
            if (onLeaderboard != null) {
                onLeaderboard.run();
            } else {
                Main.showLeaderboard();
            }
        });
        btnPanel.add(leadBtn);

        GradientButton dashBtn = new GradientButton("DASHBOARD", UITheme.GRADIENT_CYAN);
        dashBtn.setPreferredSize(new Dimension(145, 46));
        dashBtn.setGlassMode(true);
        dashBtn.addActionListener(e -> {
            stopAnimation();
            dispose();
            if (onDashboard != null) {
                onDashboard.run();
            } else {
                Main.showDashboard();
            }
        });
        btnPanel.add(dashBtn);

        mainPanel.add(title);
        mainPanel.add(Box.createVerticalStrut(6));
        mainPanel.add(congrats);
        mainPanel.add(Box.createVerticalStrut(14));
        mainPanel.add(starsPanel);
        mainPanel.add(Box.createVerticalStrut(16));
        mainPanel.add(statsGrid);
        mainPanel.add(Box.createVerticalStrut(26));
        mainPanel.add(btnPanel);
        mainPanel.add(Box.createVerticalGlue());

        setContentPane(mainPanel);

        // 60 FPS Particle animation timer
        animationTimer = new Timer(16, e -> {
            updateParticles(580, 500);
            mainPanel.repaint();
        });
        animationTimer.start();
    }

    private void stopAnimation() {
        if (animationTimer != null && animationTimer.isRunning()) {
            animationTimer.stop();
        }
    }

    private void spawnDualSideFireworks(int width, int height) {
        Color[] festiveColors = {
                new Color(251, 191, 36), // Gold
                new Color(239, 68, 68),  // Crimson Red
                new Color(236, 72, 153), // Spark Pink
                new Color(6, 182, 212),  // Cyan
                new Color(16, 185, 129), // Emerald
                new Color(139, 92, 246)  // Purple
        };

        synchronized (particles) {
            // Left firework bursts shooting inward
            for (int i = 0; i < 40; i++) {
                double angle = (random.nextDouble() * 1.2 - 0.6);
                double speed = 4.0 + random.nextDouble() * 7.0;
                double vx = Math.cos(angle) * speed;
                double vy = -Math.sin(angle) * speed - 1.5;
                Color col = festiveColors[random.nextInt(festiveColors.length)];
                particles.add(new Particle(15 + random.nextInt(30), height * 0.4 + random.nextInt(80), vx, vy, col));
            }

            // Right firework bursts shooting inward
            for (int i = 0; i < 40; i++) {
                double angle = Math.PI - (random.nextDouble() * 1.2 - 0.6);
                double speed = 4.0 + random.nextDouble() * 7.0;
                double vx = Math.cos(angle) * speed;
                double vy = -Math.sin(angle) * speed - 1.5;
                Color col = festiveColors[random.nextInt(festiveColors.length)];
                particles.add(new Particle(width - 45 + random.nextInt(30), height * 0.4 + random.nextInt(80), vx, vy, col));
            }
        }
    }

    private void updateParticles(int width, int height) {
        synchronized (particles) {
            for (int i = particles.size() - 1; i >= 0; i--) {
                Particle p = particles.get(i);
                p.update();
                if (p.isDead()) {
                    particles.remove(i);
                }
            }

            if (particles.size() < 60) {
                spawnDualSideFireworks(width, height);
            }
        }
    }

    private static JPanel createMiniStat(String label, String value, Color color) {
        JPanel p = new JPanel(new BorderLayout(2, 2));
        p.setOpaque(false);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(color.getRed(), color.getGreen(), color.getBlue(), 130), 1, true),
                BorderFactory.createEmptyBorder(6, 8, 6, 8)
        ));

        JLabel l = new JLabel(label, SwingConstants.CENTER);
        l.setFont(UITheme.getFont(Font.BOLD, 11));
        l.setForeground(new Color(203, 213, 225));

        JLabel v = new JLabel(value, SwingConstants.CENTER);
        v.setFont(UITheme.getFont(Font.BOLD, 19));
        v.setForeground(Color.WHITE);

        p.add(l, BorderLayout.NORTH);
        p.add(v, BorderLayout.CENTER);
        return p;
    }

    private static void drawGoldStar(Graphics2D g2, int cx, int cy, int radius, boolean earned) {
        Path2D star = new Path2D.Double();
        int points = 5;
        double innerRadius = radius * 0.45;

        for (int i = 0; i < points * 2; i++) {
            double angle = Math.PI / 2 + i * Math.PI / points;
            double r = (i % 2 == 0) ? radius : innerRadius;
            double x = cx + r * Math.cos(angle);
            double y = cy - r * Math.sin(angle);
            if (i == 0) star.moveTo(x, y);
            else star.lineTo(x, y);
        }
        star.closePath();

        if (earned) {
            GradientPaint gp = new GradientPaint(
                    cx - radius, cy - radius, new Color(251, 191, 36),
                    cx + radius, cy + radius, new Color(245, 158, 11)
            );
            g2.setPaint(gp);
            g2.fill(star);

            g2.setColor(new Color(254, 240, 138));
            g2.setStroke(new BasicStroke(1.5f));
            g2.draw(star);
        } else {
            g2.setColor(new Color(71, 85, 105, 120));
            g2.fill(star);
            g2.setColor(new Color(148, 163, 184, 100));
            g2.draw(star);
        }
    }

    private static class Particle {
        double x, y;
        double vx, vy;
        Color color;
        int life = 60;
        int maxLife = 60;
        int size;

        Particle(double x, double y, double vx, double vy, Color color) {
            this.x = x;
            this.y = y;
            this.vx = vx;
            this.vy = vy;
            this.color = color;
            this.size = 4 + (int) (Math.random() * 5);
        }

        void update() {
            x += vx;
            y += vy;
            vy += 0.12; // Gravity
            vx *= 0.98; // Air resistance
            life--;
        }

        boolean isDead() {
            return life <= 0;
        }

        void render(Graphics2D g2) {
            float alpha = Math.max(0f, (float) life / maxLife);
            g2.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (alpha * 255)));
            g2.fillOval((int) x, (int) y, size, size);
        }
    }
}
