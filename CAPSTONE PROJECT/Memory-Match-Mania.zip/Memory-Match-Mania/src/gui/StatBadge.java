package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class StatBadge extends JPanel {

    private final String title;
    private String value;
    private final Color accentColor;
    private JLabel valueLabel;

    public StatBadge(String symbol, String title, String value, Color accentColor) {
        this.title = title;
        this.value = value;
        this.accentColor = accentColor;

        setOpaque(false);
        setLayout(new BorderLayout(5, 4));
        setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));

        createContent();
    }

    private void createContent() {
        removeAll();

        // Top Row: Title with colored bullet
        JPanel top = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                g2.setColor(accentColor);
                g2.fillOval(4, 5, 8, 8);
                g2.dispose();
            }
        };
        top.setOpaque(false);
        top.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 0));

        JLabel titleLabel = new JLabel(title.toUpperCase());
        titleLabel.setFont(UITheme.getFont(Font.BOLD, 12));
        titleLabel.setForeground(new Color(203, 213, 225));

        top.add(titleLabel);

        // Center: Large Value
        valueLabel = new JLabel(value, SwingConstants.CENTER);
        valueLabel.setFont(UITheme.getFont(Font.BOLD, 22));
        valueLabel.setForeground(Color.WHITE);

        add(top, BorderLayout.NORTH);
        add(valueLabel, BorderLayout.CENTER);
    }

    public void setValue(String val) {
        this.value = val;
        if (valueLabel != null) {
            valueLabel.setText(val);
        }
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        UITheme.setRenderingHints(g2);

        int w = getWidth();
        int h = getHeight();
        int corner = 18;

        // Glass background
        g2.setColor(new Color(30, 41, 59, 180));
        g2.fill(new RoundRectangle2D.Double(0, 0, w, h, corner, corner));

        // Subtle gradient sheen
        GradientPaint gp = new GradientPaint(
                0, 0, new Color(accentColor.getRed(), accentColor.getGreen(), accentColor.getBlue(), 45),
                0, h, new Color(0, 0, 0, 0)
        );
        g2.setPaint(gp);
        g2.fill(new RoundRectangle2D.Double(0, 0, w, h, corner, corner));

        // Border with accent glow
        g2.setColor(new Color(accentColor.getRed(), accentColor.getGreen(), accentColor.getBlue(), 130));
        g2.setStroke(new BasicStroke(1.5f));
        g2.draw(new RoundRectangle2D.Double(1, 1, w - 2, h - 2, corner, corner));

        g2.dispose();
    }
}
