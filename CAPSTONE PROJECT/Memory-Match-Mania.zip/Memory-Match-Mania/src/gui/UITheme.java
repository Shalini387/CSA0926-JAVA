package gui;

import java.awt.*;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.util.HashMap;
import java.util.Map;

public class UITheme {

    // Primary & Accent Colors
    public static final Color BG_DARK_TOP = new Color(15, 23, 42);      // #0F172A (Deep Slate)
    public static final Color BG_DARK_BOTTOM = new Color(30, 27, 75);  // #1E1B4B (Deep Indigo)
    public static final Color BG_ACCENT_GLOW = new Color(99, 102, 241, 40); // Indigo glow

    public static final Color CARD_BG = new Color(255, 255, 255, 245);
    public static final Color CARD_BORDER = new Color(226, 232, 240);
    public static final Color CARD_SHADOW = new Color(0, 0, 0, 45);

    // Vibrant Gradients
    public static final Color[] GRADIENT_PRIMARY = {
            new Color(99, 102, 241), // #6366F1
            new Color(139, 92, 246)  // #8B5CF6
    };

    public static final Color[] GRADIENT_SECONDARY = {
            new Color(236, 72, 153), // #EC4899
            new Color(244, 63, 94)   // #F43F5E
    };

    public static final Color[] GRADIENT_SUCCESS = {
            new Color(16, 185, 129), // #10B981
            new Color(5, 150, 105)   // #059669
    };

    public static final Color[] GRADIENT_CYAN = {
            new Color(6, 182, 212),  // #06B6D4
            new Color(2, 132, 199)   // #0284C7
    };

    public static final Color[] GRADIENT_AMBER = {
            new Color(245, 158, 11), // #F59E0B
            new Color(217, 119, 6)   // #D97706
    };

    public static final Color[] GRADIENT_CORAL = {
            new Color(255, 107, 107), // #FF6B6B
            new Color(255, 142, 83)   // #FF8E53
    };

    // Text Colors
    public static final Color TEXT_DARK = new Color(30, 41, 59);
    public static final Color TEXT_MUTED = new Color(100, 116, 139);
    public static final Color TEXT_LIGHT = new Color(248, 250, 252);
    public static final Color TEXT_ACCENT = new Color(99, 102, 241);

    // Fonts
    public static final String FONT_FAMILY = "Segoe UI";

    public static Font getFont(int style, float size) {
        return new Font(FONT_FAMILY, style, (int) size);
    }

    public static Font getTitleFont(float size) {
        return new Font(FONT_FAMILY, Font.BOLD, (int) size);
    }

    // Antialiasing rendering hints
    public static void setRenderingHints(Graphics2D g2) {
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
    }

    // Draw clean vector theme icon
    public static void drawThemeIcon(Graphics2D g2, String theme, int cx, int cy, int size) {
        String key = (theme != null) ? theme.trim().toUpperCase() : "EMOJI";
        g2.setColor(Color.WHITE);

        int half = size / 2;

        switch (key) {
            case "ANIMALS":
                // Cute paw / circular badge
                g2.fillOval(cx - half / 2, cy - half / 3, half, half);
                g2.fillOval(cx - half + 2, cy - half + 2, half / 2, half / 2);
                g2.fillOval(cx + 2, cy - half + 2, half / 2, half / 2);
                break;

            case "FRUITS":
            case "FOOD":
                // Apple / Fruit circle with small leaf
                g2.fillOval(cx - half + 2, cy - half + 4, size - 4, size - 4);
                g2.fillOval(cx - 2, cy - half - 2, 6, 6);
                break;

            case "VEHICLES":
            case "OCEAN":
                // Sleek triangle
                Polygon tri = new Polygon();
                tri.addPoint(cx, cy - half);
                tri.addPoint(cx + half, cy + half);
                tri.addPoint(cx - half, cy + half);
                g2.fillPolygon(tri);
                break;

            case "SPORTS":
                // Trophy / Ball ring
                g2.setStroke(new BasicStroke(3.0f));
                g2.drawOval(cx - half + 3, cy - half + 3, size - 6, size - 6);
                g2.fillOval(cx - 3, cy - 3, 6, 6);
                break;

            case "SPACE":
                // 4-pointed Star
                Path2D star = new Path2D.Double();
                star.moveTo(cx, cy - half);
                star.quadTo(cx, cy, cx + half, cy);
                star.quadTo(cx, cy, cx, cy + half);
                star.quadTo(cx, cy, cx - half, cy);
                star.quadTo(cx, cy, cx, cy - half);
                g2.fill(star);
                break;

            case "NATURE":
                // Diamond leaf
                Polygon leaf = new Polygon();
                leaf.addPoint(cx, cy - half);
                leaf.addPoint(cx + half, cy);
                leaf.addPoint(cx, cy + half);
                leaf.addPoint(cx - half, cy);
                g2.fillPolygon(leaf);
                break;

            case "TECHNOLOGY":
                // Chip / Screen rounded rect
                g2.fill(new RoundRectangle2D.Double(cx - half + 2, cy - half + 3, size - 4, size - 6, 6, 6));
                break;

            default: // EMOJI / SHAPES
                // Happy smiley circle
                g2.setStroke(new BasicStroke(2.5f));
                g2.drawOval(cx - half + 2, cy - half + 2, size - 4, size - 4);
                g2.fillOval(cx - half / 2, cy - half / 3, 4, 4);
                g2.fillOval(cx + half / 4, cy - half / 3, 4, 4);
                g2.drawArc(cx - half / 2, cy - half / 4, half, half / 2, 200, 140);
                break;
        }
    }

    // Theme definitions with icons and colors
    public static class ThemeInfo {
        public final String name;
        public final Color[] gradient;
        public final String description;

        public ThemeInfo(String name, Color[] gradient, String description) {
            this.name = name;
            this.gradient = gradient;
            this.description = description;
        }
    }

    public static final Map<String, ThemeInfo> THEME_MAP = new HashMap<>();

    static {
        THEME_MAP.put("ANIMALS", new ThemeInfo("Animals",
                new Color[]{new Color(255, 107, 107), new Color(255, 142, 83)},
                "Cute & wild creatures"));

        THEME_MAP.put("FRUITS", new ThemeInfo("Fruits",
                new Color[]{new Color(236, 72, 153), new Color(244, 63, 94)},
                "Sweet & juicy fruits"));

        THEME_MAP.put("VEHICLES", new ThemeInfo("Vehicles",
                new Color[]{new Color(6, 182, 212), new Color(59, 130, 246)},
                "Cars, planes & ships"));

        THEME_MAP.put("SPORTS", new ThemeInfo("Sports",
                new Color[]{new Color(16, 185, 129), new Color(5, 150, 105)},
                "Action & athletic games"));

        THEME_MAP.put("SPACE", new ThemeInfo("Space",
                new Color[]{new Color(139, 92, 246), new Color(192, 38, 211)},
                "Planets, stars & cosmos"));

        THEME_MAP.put("NATURE", new ThemeInfo("Nature",
                new Color[]{new Color(34, 197, 94), new Color(16, 185, 129)},
                "Trees, flowers & forests"));

        THEME_MAP.put("TECHNOLOGY", new ThemeInfo("Technology",
                new Color[]{new Color(79, 70, 229), new Color(6, 182, 212)},
                "Gadgets & computers"));

        THEME_MAP.put("FOOD", new ThemeInfo("Food",
                new Color[]{new Color(249, 115, 22), new Color(234, 88, 12)},
                "Delicious meals & snacks"));

        THEME_MAP.put("OCEAN", new ThemeInfo("Ocean",
                new Color[]{new Color(14, 165, 233), new Color(30, 64, 175)},
                "Deep sea wonders"));

        THEME_MAP.put("EMOJI", new ThemeInfo("Emoji",
                new Color[]{new Color(234, 179, 8), new Color(249, 115, 22)},
                "Fun expressive vibes"));
    }

    public static ThemeInfo getThemeInfo(String theme) {
        if (theme == null) return THEME_MAP.get("EMOJI");
        ThemeInfo info = THEME_MAP.get(theme.trim().toUpperCase());
        if (info != null) return info;
        return new ThemeInfo(theme, GRADIENT_PRIMARY, "Memory match cards");
    }
}
