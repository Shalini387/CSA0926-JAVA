package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.geom.RoundRectangle2D;

public class ModernTextField extends JTextField {

    private String placeholder = "";
    private boolean isFocused = false;
    private final int cornerRadius = 14;

    public ModernTextField(String placeholder) {
        super();
        this.placeholder = placeholder;

        setFont(UITheme.getFont(Font.PLAIN, 16));
        setForeground(UITheme.TEXT_DARK);
        setBackground(Color.WHITE);
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));

        addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                isFocused = true;
                repaint();
            }

            @Override
            public void focusLost(FocusEvent e) {
                isFocused = false;
                repaint();
            }
        });
    }

    public void setPlaceholder(String placeholder) {
        this.placeholder = placeholder;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        UITheme.setRenderingHints(g2);

        int w = getWidth();
        int h = getHeight();

        // Background fill
        g2.setColor(Color.WHITE);
        g2.fill(new RoundRectangle2D.Double(1, 1, w - 2, h - 2, cornerRadius, cornerRadius));

        // Border / Glow
        if (isFocused) {
            // Focus ring glow
            g2.setColor(new Color(99, 102, 241, 60));
            g2.setStroke(new BasicStroke(4.0f));
            g2.draw(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, cornerRadius, cornerRadius));

            g2.setColor(UITheme.GRADIENT_PRIMARY[0]);
            g2.setStroke(new BasicStroke(2.0f));
            g2.draw(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, cornerRadius, cornerRadius));
        } else {
            g2.setColor(new Color(203, 213, 225));
            g2.setStroke(new BasicStroke(1.5f));
            g2.draw(new RoundRectangle2D.Double(1, 1, w - 2, h - 2, cornerRadius, cornerRadius));
        }

        super.paintComponent(g);

        // Draw placeholder if text is empty and not focused
        if (getText().isEmpty() && !isFocused && placeholder != null && !placeholder.isEmpty()) {
            g2.setColor(new Color(148, 163, 184));
            g2.setFont(getFont());
            FontMetrics fm = g2.getFontMetrics();
            int y = (h - fm.getHeight()) / 2 + fm.getAscent();
            g2.drawString(placeholder, 18, y);
        }

        g2.dispose();
    }
}
