package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.Ellipse2D;

public class BackgroundPanel extends JPanel {

    private final Color topColor;
    private final Color bottomColor;
    private final boolean drawOrbs;

    public BackgroundPanel() {
        this(UITheme.BG_DARK_TOP, UITheme.BG_DARK_BOTTOM, true);
    }

    public BackgroundPanel(Color topColor, Color bottomColor, boolean drawOrbs) {
        this.topColor = topColor;
        this.bottomColor = bottomColor;
        this.drawOrbs = drawOrbs;
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        UITheme.setRenderingHints(g2);

        int w = getWidth();
        int h = getHeight();

        // Multi-stop gradient
        GradientPaint bgGradient = new GradientPaint(
                0, 0, topColor,
                w, h, bottomColor
        );
        g2.setPaint(bgGradient);
        g2.fillRect(0, 0, w, h);

        if (drawOrbs) {
            // Ambient glowing orbs for depth
            // Orb 1: Top-right violet glow
            g2.setPaint(new RadialGradientPaint(
                    (float) (w * 0.85), (float) (h * 0.15), (float) (w * 0.4),
                    new float[]{0.0f, 1.0f},
                    new Color[]{new Color(139, 92, 246, 60), new Color(139, 92, 246, 0)}
            ));
            g2.fill(new Ellipse2D.Double(w * 0.5, -h * 0.2, w * 0.7, w * 0.7));

            // Orb 2: Bottom-left cyan glow
            g2.setPaint(new RadialGradientPaint(
                    (float) (w * 0.15), (float) (h * 0.85), (float) (w * 0.35),
                    new float[]{0.0f, 1.0f},
                    new Color[]{new Color(6, 182, 212, 50), new Color(6, 182, 212, 0)}
            ));
            g2.fill(new Ellipse2D.Double(-w * 0.2, h * 0.5, w * 0.7, w * 0.7));

            // Orb 3: Center-right pink accent glow
            g2.setPaint(new RadialGradientPaint(
                    (float) (w * 0.6), (float) (h * 0.55), (float) (w * 0.25),
                    new float[]{0.0f, 1.0f},
                    new Color[]{new Color(236, 72, 153, 35), new Color(236, 72, 153, 0)}
            ));
            g2.fill(new Ellipse2D.Double(w * 0.35, h * 0.3, w * 0.5, w * 0.5));
        }

        g2.dispose();
    }
}
