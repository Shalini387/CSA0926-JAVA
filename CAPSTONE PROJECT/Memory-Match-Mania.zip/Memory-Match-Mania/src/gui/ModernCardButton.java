package gui;

import util.ImageManager;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class ModernCardButton extends JButton {

    private String rawValue = "?";
    private String themeName = "Fruits";
    private boolean isMatched = false;
    private boolean hovered = false;
    private Color themeAccentColor = new Color(99, 102, 241);
    private final int cornerRadius = 16;
    private final int shineOffset;

    public ModernCardButton(String text) {
        super();
        this.rawValue = text;
        this.shineOffset = (int) (Math.random() * 1000);

        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setOpaque(false);
        setCursor(new Cursor(Cursor.HAND_CURSOR));

        addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                if (isEnabled() && !isMatched && "?".equals(rawValue)) {
                    hovered = true;
                    repaint();
                }
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                hovered = false;
                repaint();
            }
        });
    }

    public void setThemeName(String theme) {
        this.themeName = theme;
        repaint();
    }

    public void setThemeAccentColor(Color color) {
        this.themeAccentColor = color;
        repaint();
    }

    @Override
    public void setText(String text) {
        this.rawValue = text;
        repaint();
    }

    public String getRawValue() {
        return rawValue;
    }

    public void setMatched(boolean matched) {
        this.isMatched = matched;
        if (matched) {
            setEnabled(false);
        }
        repaint();
    }

    public boolean isMatched() {
        return isMatched;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        UITheme.setRenderingHints(g2);

        int w = getWidth();
        int h = getHeight();

        if (w <= 0 || h <= 0) {
            g2.dispose();
            return;
        }

        int x = 3;
        int y = 3;
        int width = w - 6;
        int height = h - 6;

        // Card Drop shadow
        g2.setColor(new Color(0, 0, 0, 45));
        g2.fill(new RoundRectangle2D.Double(x, y + 2, width, height, cornerRadius, cornerRadius));

        boolean isHidden = "?".equals(rawValue);

        if (isHidden) {
            // =========================================================================
            // 1. MATCHING CARDS MODE (FACE DOWN): SAME THEME CARD BACK + SHINE EFFECT
            // =========================================================================
            RoundRectangle2D cardShape = new RoundRectangle2D.Double(x, y, width, height, cornerRadius, cornerRadius);

            Image backImg = ImageManager.getThemeBackImage(themeName, width, height);
            if (backImg != null) {
                g2.drawImage(backImg, x, y, width, height, null);
            } else {
                GradientPaint gp = new GradientPaint(
                        x, y, themeAccentColor,
                        x + width, y + height, themeAccentColor.darker()
                );
                g2.setPaint(gp);
                g2.fill(cardShape);
            }

            // =========================================================================
            // ANIMATED SHINING EFFECT (ONLY ON FACE-DOWN CARDS)
            // =========================================================================
            Shape origClip = g2.getClip();
            g2.clip(cardShape);

            long now = System.currentTimeMillis();
            float progress = ((now + shineOffset) % 2400L) / 2400.0f;
            int totalTravel = width + height + 80;
            int shineX = (int) (-40 + progress * totalTravel);

            Polygon shinePoly = new Polygon();
            shinePoly.addPoint(shineX, y);
            shinePoly.addPoint(shineX + 35, y);
            shinePoly.addPoint(shineX + 35 - height, y + height);
            shinePoly.addPoint(shineX - height, y + height);

            GradientPaint shineGp = new GradientPaint(
                    shineX - 10, y, new Color(255, 255, 255, 0),
                    shineX + 18, y, new Color(255, 255, 255, 115),
                    true
            );
            g2.setPaint(shineGp);
            g2.fill(shinePoly);

            g2.setClip(origClip);

            // Hover ring
            if (hovered) {
                g2.setColor(new Color(255, 255, 255, 200));
                g2.setStroke(new BasicStroke(2.2f));
                g2.draw(cardShape);
            } else {
                g2.setColor(new Color(255, 255, 255, 75));
                g2.setStroke(new BasicStroke(1.2f));
                g2.draw(cardShape);
            }

        } else if ("BONUS".equals(rawValue)) {
            // =========================================================================
            // BONUS GOLDEN CARD (FACE UP: NO SHINE)
            // =========================================================================
            GradientPaint gp = new GradientPaint(
                    x, y, new Color(251, 191, 36),
                    x + width, y + height, new Color(217, 119, 6)
            );
            g2.setPaint(gp);
            g2.fill(new RoundRectangle2D.Double(x, y, width, height, cornerRadius, cornerRadius));

            g2.setColor(Color.WHITE);
            g2.setFont(UITheme.getFont(Font.BOLD, Math.max(13, h / 5)));
            FontMetrics fm = g2.getFontMetrics();
            String bonusText = "+5 BONUS";
            int tx = (w - fm.stringWidth(bonusText)) / 2;
            int ty = (h - fm.getHeight()) / 2 + fm.getAscent();
            g2.drawString(bonusText, tx, ty);

        } else {
            // =========================================================================
            // REVEALED CARD (FACE UP: ACTUAL IMAGE + NAME, SHINE DISAPPEARS)
            // =========================================================================
            Color bg = isMatched ? new Color(240, 253, 244) : Color.WHITE;
            Color border = isMatched ? new Color(16, 185, 129) : themeAccentColor;

            g2.setColor(bg);
            g2.fill(new RoundRectangle2D.Double(x, y, width, height, cornerRadius, cornerRadius));

            // Illustration
            int imgSize = Math.min(width - 12, Math.max(36, height - 36));
            Image img = ImageManager.getImage(rawValue, imgSize, imgSize);
            if (img != null) {
                int ix = (w - imgSize) / 2;
                int iy = y + 6;
                g2.drawImage(img, ix, iy, null);
            }

            // Object Name Label below illustration
            g2.setFont(UITheme.getFont(Font.BOLD, Math.max(11, Math.min(13, h / 7))));
            g2.setColor(isMatched ? new Color(6, 95, 70) : UITheme.TEXT_DARK);
            FontMetrics fm = g2.getFontMetrics();
            int tx = (w - fm.stringWidth(rawValue)) / 2;
            int ty = y + imgSize + fm.getAscent() + 6;
            if (ty < h - 4) {
                g2.drawString(rawValue, tx, ty);
            }

            // Matched badge
            if (isMatched) {
                g2.setColor(new Color(16, 185, 129));
                g2.fillOval(w - 22, y + 4, 16, 16);
                g2.setColor(Color.WHITE);
                g2.setFont(UITheme.getFont(Font.BOLD, 10));
                g2.drawString("✓", w - 18, y + 16);
            }

            g2.setColor(border);
            g2.setStroke(new BasicStroke(isMatched ? 2.8f : 1.8f));
            g2.draw(new RoundRectangle2D.Double(x, y, width, height, cornerRadius, cornerRadius));
        }

        g2.dispose();
    }
}
