package gui;

import app.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class PlayerSetupPanel extends JPanel {

    private ModernTextField nameField;
    private ModernTextField ageField;
    private JLabel errorLabel;

    public PlayerSetupPanel(Runnable startGame) {
        setLayout(new BorderLayout());
        setOpaque(false);

        BackgroundPanel bg = new BackgroundPanel();
        bg.setLayout(new GridBagLayout());

        // Glass Card Container
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                int w = getWidth();
                int h = getHeight();

                // Glass card background
                g2.setColor(new Color(30, 41, 59, 230));
                g2.fill(new RoundRectangle2D.Double(0, 0, w, h, 28, 28));

                // Glowing top border sheen
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(99, 102, 241, 95),
                        w, (float) (h * 0.3), new Color(236, 72, 153, 25)
                );
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Double(0, 0, w, h, 28, 28));

                // Border
                g2.setColor(new Color(99, 102, 241, 150));
                g2.setStroke(new BasicStroke(1.8f));
                g2.draw(new RoundRectangle2D.Double(1, 1, w - 2, h - 2, 28, 28));

                g2.dispose();
            }
        };

        card.setPreferredSize(new Dimension(540, 560));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(36, 48, 36, 48));

        // Emblem Banner
        JLabel banner = new JLabel("★ ◆ ★");
        banner.setFont(UITheme.getFont(Font.BOLD, 28));
        banner.setForeground(new Color(251, 191, 36));
        banner.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Title
        JLabel title = new JLabel("MEMORY MATCH MANIA");
        title.setFont(UITheme.getTitleFont(28));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Subtitle
        JLabel subtitle = new JLabel("Match. Remember. Think. Win!");
        subtitle.setFont(UITheme.getFont(Font.PLAIN, 15));
        subtitle.setForeground(new Color(203, 213, 225));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Form Fields
        JLabel nameLabel = new JLabel("PLAYER NAME");
        nameLabel.setFont(UITheme.getFont(Font.BOLD, 13));
        nameLabel.setForeground(new Color(203, 213, 225));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        nameField = new ModernTextField("Enter your player name");
        nameField.setText(Main.playerName);
        nameField.setMaximumSize(new Dimension(420, 48));
        nameField.setPreferredSize(new Dimension(420, 48));
        nameField.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel ageLabel = new JLabel("PLAYER AGE");
        ageLabel.setFont(UITheme.getFont(Font.BOLD, 13));
        ageLabel.setForeground(new Color(203, 213, 225));
        ageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        ageField = new ModernTextField("Enter your age (1 - 100)");
        ageField.setText(String.valueOf(Main.playerAge));
        ageField.setMaximumSize(new Dimension(420, 48));
        ageField.setPreferredSize(new Dimension(420, 48));
        ageField.setAlignmentX(Component.CENTER_ALIGNMENT);

        errorLabel = new JLabel(" ");
        errorLabel.setFont(UITheme.getFont(Font.BOLD, 13));
        errorLabel.setForeground(new Color(248, 113, 113));
        errorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Start Button
        GradientButton startBtn = new GradientButton("LET'S PLAY ->", UITheme.GRADIENT_PRIMARY);
        startBtn.setFont(UITheme.getFont(Font.BOLD, 17));
        startBtn.setPreferredSize(new Dimension(260, 52));
        startBtn.setMaximumSize(new Dimension(260, 52));
        startBtn.setAlignmentX(Component.CENTER_ALIGNMENT);

        startBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            String ageText = ageField.getText().trim();

            if (name.isEmpty()) {
                errorLabel.setText("! Name is required");
                return;
            }

            if (ageText.isEmpty()) {
                errorLabel.setText("! Age is required");
                return;
            }

            try {
                int age = Integer.parseInt(ageText);
                if (age < 1 || age > 100) {
                    errorLabel.setText("! Age must be between 1 and 100");
                    return;
                }

                Main.playerName = name;
                Main.playerAge = age;
                errorLabel.setText(" ");
                startGame.run();

            } catch (NumberFormatException ex) {
                errorLabel.setText("! Please enter a valid numerical age");
            }
        });

        // Assemble Card
        card.add(banner);
        card.add(Box.createVerticalStrut(8));
        card.add(title);
        card.add(Box.createVerticalStrut(4));
        card.add(subtitle);
        card.add(Box.createVerticalStrut(28));

        card.add(nameLabel);
        card.add(Box.createVerticalStrut(6));
        card.add(nameField);
        card.add(Box.createVerticalStrut(18));

        card.add(ageLabel);
        card.add(Box.createVerticalStrut(6));
        card.add(ageField);
        card.add(Box.createVerticalStrut(12));

        card.add(errorLabel);
        card.add(Box.createVerticalStrut(12));
        card.add(startBtn);

        bg.add(card);
        add(bg, BorderLayout.CENTER);
    }
}