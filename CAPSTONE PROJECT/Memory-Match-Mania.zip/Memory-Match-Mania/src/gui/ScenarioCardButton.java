package gui;

import scenario.ScenarioCard;
import util.ImageManager;
import util.SoundManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

public class ScenarioCardButton extends JButton {

    private final ScenarioCard scenarioCard;
    private boolean selected = false;
    private boolean hovered = false;
    private boolean revealed = false;
    private final int cornerRadius = 22;

    public ScenarioCardButton(ScenarioCard scenarioCard) {
        this.scenarioCard = scenarioCard;

        setFocusPainted(false);
        setBorderPainted(false);
        setContentAreaFilled(false);
        setOpaque(false);
        setCursor(new Cursor(Cursor.HAND_CURSOR));

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                if (isEnabled()) {
                    hovered = true;
                    repaint();
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                hovered = false;
                repaint();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                if (isEnabled()) {
                    SoundManager.playCardFlip();
                }
            }
        });
    }

    public ScenarioCard getScenarioCard() {
        return scenarioCard;
    }

    public boolean isSelectedChoice() {
        return selected;
    }

    public void setSelectedChoice(boolean sel) {
        this.selected = sel;
        repaint();
    }

    public void toggleSelected() {
        this.selected = !this.selected;
        repaint();
    }

    public void setRevealed(boolean rev) {
        this.revealed = rev;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        UITheme.setRenderingHints(g2);

        int w = getWidth();
        int h = getHeight();

        if (w <= 0 || h <= 0) {
            g2.dispose();
            return;
        }

        // Apply scale/enlarge effect when selected
        int inset = selected ? 2 : 5;
        int x = inset;
        int y = inset;
        int width = w - (inset * 2);
        int height = h - (inset * 2);

        // Ambient glow when selected or hovered
        if (selected) {
            // Cyan/electric blue outer glow
            g2.setColor(new Color(6, 182, 212, 100));
            g2.fill(new RoundRectangle2D.Double(x - 2, y - 2, width + 4, height + 4, cornerRadius + 4, cornerRadius + 4));
        } else if (hovered) {
            // Purple/indigo outer glow
            g2.setColor(new Color(99, 102, 241, 75));
            g2.fill(new RoundRectangle2D.Double(x - 2, y - 2, width + 4, height + 4, cornerRadius + 4, cornerRadius + 4));
        } else {
            // Soft Drop Shadow
            g2.setColor(new Color(0, 0, 0, 45));
            g2.fill(new RoundRectangle2D.Double(x, y + 3, width, height, cornerRadius, cornerRadius));
        }

        // Card background colors
        Color cardBg = Color.WHITE;
        Color borderColor = new Color(226, 232, 240);
        float borderWidth = 1.8f;

        if (revealed) {
            if (scenarioCard.isCorrect()) {
                cardBg = new Color(240, 253, 244); // light emerald
                borderColor = new Color(16, 185, 129);
                borderWidth = 3.5f;
            } else if (selected) {
                cardBg = new Color(254, 242, 242); // light red
                borderColor = new Color(239, 68, 68);
                borderWidth = 3.5f;
            }
        } else if (selected) {
            cardBg = new Color(240, 249, 255); // light cyan/blue
            borderColor = new Color(6, 182, 212);
            borderWidth = 3.5f;
        } else if (hovered) {
            borderColor = new Color(99, 102, 241);
            borderWidth = 2.4f;
        }

        g2.setColor(cardBg);
        g2.fill(new RoundRectangle2D.Double(x, y, width, height, cornerRadius, cornerRadius));

        // Draw Card Illustration Image occupying prominent center area
        int imgSize = Math.min(width - 24, Math.max(70, height - 60));
        Image img = ImageManager.getImage(scenarioCard.getImageKey(), imgSize, imgSize);

        if (img != null) {
            int ix = (w - imgSize) / 2;
            int iy = y + 8;
            g2.drawImage(img, ix, iy, null);
        }

        // Draw Card Object Title / Label below image
        String title = scenarioCard.getTitle();
        g2.setFont(UITheme.getFont(Font.BOLD, 15));

        if (revealed && scenarioCard.isCorrect()) {
            g2.setColor(new Color(6, 95, 70));
        } else if (revealed && selected) {
            g2.setColor(new Color(153, 27, 27));
        } else if (selected) {
            g2.setColor(new Color(14, 116, 144));
        } else {
            g2.setColor(UITheme.TEXT_DARK);
        }

        FontMetrics fm = g2.getFontMetrics();
        int ty = y + imgSize + 24;

        if (fm.stringWidth(title) > width - 14) {
            String[] words = title.split(" ");
            StringBuilder line1 = new StringBuilder();
            StringBuilder line2 = new StringBuilder();
            for (String word : words) {
                if (line1.length() == 0 || fm.stringWidth(line1 + " " + word) < width - 16) {
                    if (line1.length() > 0) line1.append(" ");
                    line1.append(word);
                } else {
                    if (line2.length() > 0) line2.append(" ");
                    line2.append(word);
                }
            }
            int t1x = (w - fm.stringWidth(line1.toString())) / 2;
            g2.drawString(line1.toString(), t1x, ty);
            if (line2.length() > 0) {
                int t2x = (w - fm.stringWidth(line2.toString())) / 2;
                g2.drawString(line2.toString(), t2x, ty + fm.getHeight() - 2);
            }
        } else {
            int tx = (w - fm.stringWidth(title)) / 2;
            g2.drawString(title, tx, ty);
        }

        // Selection / Status Badge Indicator at Top-Right
        if (revealed) {
            if (scenarioCard.isCorrect()) {
                g2.setColor(new Color(16, 185, 129));
                g2.fillOval(w - 36, y + 8, 24, 24);
                g2.setColor(Color.WHITE);
                g2.setFont(UITheme.getFont(Font.BOLD, 14));
                g2.drawString("✓", w - 30, y + 25);
            } else if (selected) {
                g2.setColor(new Color(239, 68, 68));
                g2.fillOval(w - 36, y + 8, 24, 24);
                g2.setColor(Color.WHITE);
                g2.setFont(UITheme.getFont(Font.BOLD, 14));
                g2.drawString("✗", w - 30, y + 25);
            }
        } else if (selected) {
            // Glowing cyan badge with checkmark
            g2.setColor(new Color(6, 182, 212));
            g2.fillOval(w - 36, y + 8, 24, 24);
            g2.setColor(Color.WHITE);
            g2.setFont(UITheme.getFont(Font.BOLD, 14));
            g2.drawString("✓", w - 30, y + 25);
        }

        // Card Border
        g2.setColor(borderColor);
        g2.setStroke(new BasicStroke(borderWidth));
        g2.draw(new RoundRectangle2D.Double(x, y, width, height, cornerRadius, cornerRadius));

        g2.dispose();
    }
}
