package gui;

import app.Main;
import data.DataManager;
import scenario.Scenario;
import scenario.ScenarioCard;
import scenario.ScenarioDatabase;
import util.SoundManager;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ScenarioGamePanel extends JPanel {

    private final String playerName;
    private final int age;
    private final String difficulty;

    private List<Scenario> scenarios;
    private int currentScenarioIndex = 0;
    private int score = 50; // Starting baseline score
    private int attempts = 0;

    private JLabel progressLabel;
    private JLabel scoreLabel;
    private JLabel attemptsLabel;
    private JLabel timeLabel;
    private GradientButton soundToggleBtn;

    private JLabel categoryLabel;
    private JLabel questionLabel;
    private JLabel counterLabel;

    private List<ScenarioCardButton> cardButtons = new ArrayList<>();
    private JPanel cardGridPanel;
    private GradientButton checkAnswerBtn;
    private ToastFeedback toastFeedback;

    private boolean answeredCorrectly = false;
    private long startTime;
    private javax.swing.Timer gameTimer;
    private javax.swing.Timer autoAdvanceTimer;

    public ScenarioGamePanel(String playerName, int age, String difficulty) {
        this.playerName = playerName;
        this.age = age;
        this.difficulty = difficulty;

        setLayout(new BorderLayout());
        setOpaque(false);

        loadScenarios();
        startTime = System.currentTimeMillis();

        createInterface();
        startTimer();
    }

    private void loadScenarios() {
        List<Scenario> pool = new ArrayList<>(ScenarioDatabase.getScenariosByDifficulty(difficulty));
        Collections.shuffle(pool);
        // Play up to 10 questions per round (or available pool size)
        int roundCount = Math.min(pool.size(), 10);
        this.scenarios = new ArrayList<>(pool.subList(0, roundCount));
        this.currentScenarioIndex = 0;
    }

    private Scenario getCurrentScenario() {
        if (scenarios == null || scenarios.isEmpty()) {
            return ScenarioDatabase.getScenariosByDifficulty("EASY").get(0);
        }
        return scenarios.get(Math.min(currentScenarioIndex, scenarios.size() - 1));
    }

    private void createInterface() {
        removeAll();

        BackgroundPanel bg = new BackgroundPanel();
        bg.setLayout(new BorderLayout(15, 12));
        bg.setBorder(BorderFactory.createEmptyBorder(16, 28, 16, 28));

        createTop(bg);
        createCenter(bg);
        createBottom(bg);

        add(bg, BorderLayout.CENTER);

        revalidate();
        repaint();
    }

    private void createTop(JPanel parent) {
        JPanel top = new JPanel(new BorderLayout(15, 4));
        top.setOpaque(false);

        // Title
        JLabel title = new JLabel("SCENARIO MATCH — " + difficulty.toUpperCase());
        title.setFont(UITheme.getTitleFont(22));
        title.setForeground(Color.WHITE);

        // Stats & Sound Toggle Right
        JPanel info = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        info.setOpaque(false);

        progressLabel = createHudChip("QUESTION: " + (currentScenarioIndex + 1) + " / " + scenarios.size(), new Color(139, 92, 246));
        scoreLabel = createHudChip("SCORE: " + score, new Color(245, 158, 11));
        attemptsLabel = createHudChip("MOVES: " + attempts, new Color(6, 182, 212));
        timeLabel = createHudChip("TIME: 00:00", new Color(16, 185, 129));

        soundToggleBtn = new GradientButton(SoundManager.isMuted() ? "SOUND: OFF" : "SOUND: ON", UITheme.GRADIENT_PRIMARY);
        soundToggleBtn.setFont(UITheme.getFont(Font.BOLD, 12));
        soundToggleBtn.setPreferredSize(new Dimension(115, 32));
        soundToggleBtn.setGlassMode(true);
        soundToggleBtn.addActionListener(e -> {
            boolean muted = SoundManager.toggleMute();
            soundToggleBtn.setText(muted ? "SOUND: OFF" : "SOUND: ON");
        });

        info.add(progressLabel);
        info.add(scoreLabel);
        info.add(attemptsLabel);
        info.add(timeLabel);
        info.add(soundToggleBtn);

        top.add(title, BorderLayout.WEST);
        top.add(info, BorderLayout.EAST);

        parent.add(top, BorderLayout.NORTH);
    }

    private JLabel createHudChip(String text, Color accent) {
        JLabel chip = new JLabel(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                int w = getWidth();
                int h = getHeight();

                g2.setColor(new Color(30, 41, 59, 210));
                g2.fillRoundRect(0, 0, w, h, 14, 14);

                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 160));
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(0, 0, w - 1, h - 1, 14, 14);

                g2.dispose();
                super.paintComponent(g);
            }
        };

        chip.setFont(UITheme.getFont(Font.BOLD, 12));
        chip.setForeground(Color.WHITE);
        chip.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        chip.setOpaque(false);
        return chip;
    }

    private void createCenter(JPanel parent) {
        JPanel center = new JPanel(new BorderLayout(12, 10));
        center.setOpaque(false);

        Scenario current = getCurrentScenario();

        // Scenario Briefing Box
        JPanel briefingCard = new JPanel(new BorderLayout(8, 4)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                int w = getWidth();
                int h = getHeight();

                g2.setColor(new Color(30, 41, 59, 225));
                g2.fill(new RoundRectangle2D.Double(0, 0, w, h, 18, 18));

                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(99, 102, 241, 75),
                        w, h, new Color(236, 72, 153, 35)
                );
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Double(0, 0, w, h, 18, 18));

                g2.setColor(new Color(99, 102, 241, 150));
                g2.setStroke(new BasicStroke(1.8f));
                g2.draw(new RoundRectangle2D.Double(1, 1, w - 2, h - 2, 18, 18));

                g2.dispose();
            }
        };
        briefingCard.setOpaque(false);
        briefingCard.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        // Category Tag
        categoryLabel = new JLabel("SCENARIO: " + current.getCategory().toUpperCase());
        categoryLabel.setFont(UITheme.getFont(Font.BOLD, 12));
        categoryLabel.setForeground(new Color(251, 191, 36)); // Gold

        // Question Description
        questionLabel = new JLabel("<html><b>" + current.getTitle() + "</b> — " + current.getDescription() + "</html>");
        questionLabel.setFont(UITheme.getFont(Font.PLAIN, 16));
        questionLabel.setForeground(Color.WHITE);
        questionLabel.setBorder(BorderFactory.createEmptyBorder(3, 0, 0, 0));

        briefingCard.add(categoryLabel, BorderLayout.NORTH);
        briefingCard.add(questionLabel, BorderLayout.CENTER);
        center.add(briefingCard, BorderLayout.NORTH);

        // 6 Cards in a clean 2x3 Grid
        List<ScenarioCard> cards = current.getAllCardsShuffled();
        cardButtons.clear();

        cardGridPanel = new JPanel(new GridLayout(2, 3, 16, 14));
        cardGridPanel.setOpaque(false);

        for (ScenarioCard sc : cards) {
            ScenarioCardButton btn = new ScenarioCardButton(sc);
            btn.addActionListener(e -> handleCardClick(btn));
            cardButtons.add(btn);
            cardGridPanel.add(btn);
        }

        // Overlay Toast container
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setLayout(new OverlayLayout(layeredPane));

        toastFeedback = new ToastFeedback();
        toastFeedback.setAlignmentX(0.5f);
        toastFeedback.setAlignmentY(0.06f);

        layeredPane.add(toastFeedback, JLayeredPane.PALETTE_LAYER);
        layeredPane.add(cardGridPanel, JLayeredPane.DEFAULT_LAYER);

        center.add(layeredPane, BorderLayout.CENTER);
        parent.add(center, BorderLayout.CENTER);
    }

    private void createBottom(JPanel parent) {
        JPanel bottom = new JPanel(new BorderLayout(10, 8));
        bottom.setOpaque(false);

        // Top line of bottom: Selection Counter and Instruction
        JPanel counterPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 0));
        counterPanel.setOpaque(false);

        counterLabel = new JLabel("Select exactly 2 cards   •   Selected: 0 / 2");
        counterLabel.setFont(UITheme.getFont(Font.BOLD, 14));
        counterLabel.setForeground(new Color(203, 213, 225));

        counterPanel.add(counterLabel);
        bottom.add(counterPanel, BorderLayout.NORTH);

        // Action Buttons Row
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 0));
        btnRow.setOpaque(false);

        GradientButton back = new GradientButton("<- DASHBOARD", UITheme.GRADIENT_PRIMARY);
        back.setPreferredSize(new Dimension(170, 44));
        back.setGlassMode(true);
        back.addActionListener(e -> {
            stopTimer();
            if (autoAdvanceTimer != null) autoAdvanceTimer.stop();
            Main.showDashboard();
        });

        checkAnswerBtn = new GradientButton("CHECK ANSWER", UITheme.GRADIENT_PRIMARY);
        checkAnswerBtn.setPreferredSize(new Dimension(220, 44));
        checkAnswerBtn.addActionListener(e -> handleCheckAnswerOrNext());

        GradientButton clearBtn = new GradientButton("CLEAR", UITheme.GRADIENT_CYAN);
        clearBtn.setPreferredSize(new Dimension(120, 44));
        clearBtn.setGlassMode(true);
        clearBtn.addActionListener(e -> {
            if (!answeredCorrectly) {
                for (ScenarioCardButton b : cardButtons) {
                    b.setSelectedChoice(false);
                    b.setRevealed(false);
                }
                updateSelectionCounter();
            }
        });

        btnRow.add(back);
        btnRow.add(clearBtn);
        btnRow.add(checkAnswerBtn);

        bottom.add(btnRow, BorderLayout.SOUTH);

        parent.add(bottom, BorderLayout.SOUTH);
    }

    private int getSelectedCardCount() {
        int count = 0;
        for (ScenarioCardButton b : cardButtons) {
            if (b.isSelectedChoice()) count++;
        }
        return count;
    }

    private void handleCardClick(ScenarioCardButton btn) {
        if (answeredCorrectly) return;

        btn.setRevealed(false);

        if (btn.isSelectedChoice()) {
            btn.setSelectedChoice(false);
        } else {
            if (getSelectedCardCount() >= 2) {
                toastFeedback.showGentle("You can only select 2 cards! Deselect one first.");
                return;
            }
            btn.setSelectedChoice(true);
        }

        attempts++;
        updateSelectionCounter();
        updateHUD();
    }

    private void updateSelectionCounter() {
        int count = getSelectedCardCount();
        if (counterLabel != null) {
            counterLabel.setText("Select exactly 2 cards   •   Selected: " + count + " / 2");
            if (count == 2) {
                counterLabel.setForeground(new Color(251, 191, 36)); // Gold when 2 selected
            } else {
                counterLabel.setForeground(new Color(203, 213, 225));
            }
        }
    }

    private void handleCheckAnswerOrNext() {
        if (answeredCorrectly) {
            if (autoAdvanceTimer != null) autoAdvanceTimer.stop();
            advanceToNextScenario();
            return;
        }

        int count = getSelectedCardCount();
        if (count < 2) {
            toastFeedback.showGentle("Please select exactly 2 cards before checking your answer!");
            return;
        }

        List<ScenarioCardButton> selectedButtons = new ArrayList<>();
        for (ScenarioCardButton b : cardButtons) {
            if (b.isSelectedChoice()) {
                selectedButtons.add(b);
            }
        }

        boolean allCorrect = true;
        for (ScenarioCardButton b : selectedButtons) {
            b.setRevealed(true);
            if (!b.getScenarioCard().isCorrect()) {
                allCorrect = false;
            }
        }

        if (allCorrect && selectedButtons.size() == 2) {
            answeredCorrectly = true;
            score += 100;
            SoundManager.playScenarioCorrect();
            toastFeedback.showPositive("✓ Correct! Well Done! +100 Points");

            checkAnswerBtn.setText("NEXT SCENARIO ->");
            checkAnswerBtn.setGradient(UITheme.GRADIENT_SUCCESS);

            updateHUD();

            // Auto-advance smoothly after 1.4 seconds
            autoAdvanceTimer = new javax.swing.Timer(1400, e -> {
                autoAdvanceTimer.stop();
                advanceToNextScenario();
            });
            autoAdvanceTimer.setRepeats(false);
            autoAdvanceTimer.start();

        } else {
            // Subtract exactly 5 points for incorrect selection
            score = Math.max(0, score - 5);
            SoundManager.playScenarioIncorrect();
            toastFeedback.showGentle("✗ Incorrect! -5 Points");
            updateHUD();
        }
    }

    private void advanceToNextScenario() {
        currentScenarioIndex++;
        if (currentScenarioIndex >= scenarios.size()) {
            scenarioRoundCompleted();
        } else {
            answeredCorrectly = false;
            createInterface();
        }
    }

    private void updateHUD() {
        if (progressLabel != null) progressLabel.setText("QUESTION: " + (currentScenarioIndex + 1) + " / " + scenarios.size());
        if (scoreLabel != null) scoreLabel.setText("SCORE: " + score);
        if (attemptsLabel != null) attemptsLabel.setText("MOVES: " + attempts);
        updateTime();
    }

    private void startTimer() {
        gameTimer = new javax.swing.Timer(1000, e -> updateTime());
        gameTimer.start();
        updateTime();
    }

    private void updateTime() {
        if (timeLabel != null) {
            long elapsed = System.currentTimeMillis() - startTime;
            long seconds = elapsed / 1000;
            int m = (int) (seconds / 60);
            int s = (int) (seconds % 60);
            timeLabel.setText("TIME: " + String.format("%02d:%02d", m, s));
            timeLabel.repaint();
        }
    }

    private void stopTimer() {
        if (gameTimer != null) {
            gameTimer.stop();
            gameTimer = null;
        }
    }

    private void scenarioRoundCompleted() {
        stopTimer();
        if (autoAdvanceTimer != null) autoAdvanceTimer.stop();

        int seconds = (int) ((System.currentTimeMillis() - startTime) / 1000);
        int finalScore = score;

        // Persist completed record
        DataManager.saveCompletedGame(
                playerName,
                age,
                "Scenario",
                "Daily Life",
                difficulty,
                finalScore,
                seconds,
                attempts
        );

        int rank = DataManager.calculateRank(finalScore, seconds);
        int stars = (finalScore >= 500) ? 3 : ((finalScore >= 250) ? 2 : 1);

        CelebrationDialog dialog = new CelebrationDialog(
                Main.frame,
                "★ SCENARIO COMPLETED! ★",
                playerName,
                finalScore,
                seconds,
                rank,
                stars,
                "PLAY AGAIN ->",
                () -> Main.showScenarioGame(playerName, age, difficulty),
                () -> Main.showLeaderboard(),
                () -> Main.showDashboard()
        );
        dialog.setVisible(true);
    }
}