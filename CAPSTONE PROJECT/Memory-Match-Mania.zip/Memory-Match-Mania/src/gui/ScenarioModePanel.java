package gui;

import app.Main;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class ScenarioModePanel extends JPanel {

    private final String playerName;
    private final int age;

    public ScenarioModePanel(String playerName, int age) {
        this.playerName = playerName;
        this.age = age;

        setLayout(new BorderLayout());
        setOpaque(false);

        BackgroundPanel bg = new BackgroundPanel();
        bg.setLayout(new BorderLayout(20, 20));
        bg.setBorder(BorderFactory.createEmptyBorder(28, 60, 28, 60));

        // =========================
        // TITLE & PLAYER INFO
        // =========================
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setOpaque(false);

        JLabel title = new JLabel("SCENARIO MATCH MODE");
        title.setFont(UITheme.getTitleFont(32));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        String recommended = getRecommendedDifficulty();

        JLabel info = new JLabel(
                "PLAYER: " + playerName.toUpperCase() +
                "  •  AGE: " + age +
                "  •  RECOMMENDED LEVEL: " + recommended
        );
        info.setFont(UITheme.getFont(Font.BOLD, 14));
        info.setForeground(new Color(251, 191, 36));
        info.setAlignmentX(Component.CENTER_ALIGNMENT);

        header.add(title);
        header.add(Box.createVerticalStrut(6));
        header.add(info);
        bg.add(header, BorderLayout.NORTH);

        // =========================
        // DIFFICULTY CARDS
        // =========================
        JPanel center = new JPanel(new GridLayout(3, 1, 16, 16));
        center.setOpaque(false);

        JButton easyCard = createDifficultyCard(
                "EASY — DAILY ESSENTIALS",
                "Simple everyday situations: Rain, school, beach, hydration & bedtime (Ages 1 - 10)",
                UITheme.GRADIENT_SUCCESS,
                "EASY".equalsIgnoreCase(recommended),
                () -> startScenario("EASY")
        );

        JButton mediumCard = createDifficultyCard(
                "MEDIUM — THOUGHTFUL DECISIONS",
                "Practical daily situations: Camping, cooking, first-aid, winter & gardening (Ages 11 - 20)",
                UITheme.GRADIENT_AMBER,
                "MEDIUM".equalsIgnoreCase(recommended),
                () -> startScenario("MEDIUM")
        );

        JButton hardCard = createDifficultyCard(
                "HARD — REAL-WORLD SCENARIOS",
                "Detailed life situations: Airport travel, floor cleaning, hiking gear & roadside repairs (Ages 21+)",
                UITheme.GRADIENT_SECONDARY,
                "HARD".equalsIgnoreCase(recommended),
                () -> startScenario("HARD")
        );

        center.add(easyCard);
        center.add(mediumCard);
        center.add(hardCard);

        bg.add(center, BorderLayout.CENTER);

        // =========================
        // BOTTOM BUTTONS
        // =========================
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 18, 0));
        bottom.setOpaque(false);

        GradientButton playRecBtn = new GradientButton(
                "PLAY RECOMMENDED (" + recommended + ") ->",
                getDifficultyGradient(recommended)
        );
        playRecBtn.setPreferredSize(new Dimension(280, 48));
        playRecBtn.setFont(UITheme.getFont(Font.BOLD, 14));
        playRecBtn.addActionListener(e -> startScenario(recommended));

        GradientButton back = new GradientButton("<- BACK TO HOME", UITheme.GRADIENT_PRIMARY);
        back.setPreferredSize(new Dimension(220, 48));
        back.setGlassMode(true);
        back.addActionListener(e -> Main.showHomeScreen());

        bottom.add(playRecBtn);
        bottom.add(back);

        bg.add(bottom, BorderLayout.SOUTH);

        add(bg, BorderLayout.CENTER);
    }

    private Color[] getDifficultyGradient(String diff) {
        if ("EASY".equalsIgnoreCase(diff)) return UITheme.GRADIENT_SUCCESS;
        if ("MEDIUM".equalsIgnoreCase(diff)) return UITheme.GRADIENT_AMBER;
        return UITheme.GRADIENT_SECONDARY;
    }

    private String getRecommendedDifficulty() {
        if (age <= 10) return "EASY";
        if (age <= 20) return "MEDIUM";
        return "HARD";
    }

    private JButton createDifficultyCard(
            String title,
            String desc,
            Color[] gradient,
            boolean isRecommended,
            Runnable onAction
    ) {
        JButton btn = new JButton() {
            private boolean hovered = false;

            {
                addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseEntered(java.awt.event.MouseEvent e) {
                        hovered = true;
                        repaint();
                    }

                    @Override
                    public void mouseExited(java.awt.event.MouseEvent e) {
                        hovered = false;
                        repaint();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                int w = getWidth();
                int h = getHeight();

                // Card background
                g2.setColor(new Color(30, 41, 59, 210));
                g2.fill(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, 20, 20));

                // Left accent bar
                GradientPaint barGp = new GradientPaint(2, 2, gradient[0], 12, h - 2, gradient[1]);
                g2.setPaint(barGp);
                g2.fill(new RoundRectangle2D.Double(2, 2, 10, h - 4, 8, 8));

                // Glow / Border
                if (hovered) {
                    g2.setColor(new Color(gradient[0].getRed(), gradient[0].getGreen(), gradient[0].getBlue(), 70));
                    g2.fill(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, 20, 20));

                    g2.setColor(gradient[0]);
                    g2.setStroke(new BasicStroke(2.0f));
                    g2.draw(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, 20, 20));
                } else if (isRecommended) {
                    g2.setColor(new Color(251, 191, 36, 160));
                    g2.setStroke(new BasicStroke(1.8f));
                    g2.draw(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, 20, 20));
                } else {
                    g2.setColor(new Color(255, 255, 255, 30));
                    g2.setStroke(new BasicStroke(1.2f));
                    g2.draw(new RoundRectangle2D.Double(2, 2, w - 4, h - 4, 20, 20));
                }

                // Title
                g2.setFont(UITheme.getFont(Font.BOLD, 18));
                g2.setColor(Color.WHITE);
                g2.drawString(title, 28, (h / 2) - 8);

                // Recommended badge
                if (isRecommended) {
                    int titleWidth = g2.getFontMetrics().stringWidth(title);
                    g2.setColor(new Color(251, 191, 36));
                    g2.fillRoundRect(28 + titleWidth + 12, (h / 2) - 24, 110, 20, 8, 8);

                    g2.setFont(UITheme.getFont(Font.BOLD, 10));
                    g2.setColor(new Color(30, 41, 59));
                    g2.drawString("RECOMMENDED", 28 + titleWidth + 14, (h / 2) - 10);
                }

                // Description
                g2.setFont(UITheme.getFont(Font.PLAIN, 13));
                g2.setColor(new Color(203, 213, 225));
                g2.drawString(desc, 28, (h / 2) + 16);

                // Arrow
                g2.setFont(UITheme.getFont(Font.BOLD, 20));
                g2.setColor(hovered ? Color.WHITE : new Color(148, 163, 184));
                g2.drawString("->", w - 45, (h / 2) + 8);

                g2.dispose();
            }
        };

        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> onAction.run());

        return btn;
    }

    private void startScenario(String difficulty) {
        Main.showScenarioGame(playerName, age, difficulty);
    }
}