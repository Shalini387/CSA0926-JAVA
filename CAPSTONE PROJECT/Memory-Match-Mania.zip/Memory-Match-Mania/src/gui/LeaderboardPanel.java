package gui;

import app.Main;
import data.DataManager;
import data.GameRecord;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

public class LeaderboardPanel extends JPanel {

    private String currentFilter = "ALL";
    private JTable table;
    private DefaultTableModel tableModel;

    public LeaderboardPanel() {
        setLayout(new BorderLayout());
        setOpaque(false);

        DataManager.init();

        BackgroundPanel bg = new BackgroundPanel();
        bg.setLayout(new BorderLayout(16, 16));
        bg.setBorder(BorderFactory.createEmptyBorder(22, 40, 22, 40));

        // =====================================
        // HEADER
        // =====================================
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setOpaque(false);

        JLabel title = new JLabel("GLOBAL LEADERBOARD");
        title.setFont(UITheme.getTitleFont(32));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("Top brain training champions ranked by highest scores and fastest completion times");
        subtitle.setFont(UITheme.getFont(Font.PLAIN, 14));
        subtitle.setForeground(new Color(203, 213, 225));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        header.add(title);
        header.add(Box.createVerticalStrut(4));
        header.add(subtitle);
        bg.add(header, BorderLayout.NORTH);

        // =====================================
        // CENTER: FILTER TABS & LEADERBOARD TABLE
        // =====================================
        JPanel center = new JPanel(new BorderLayout(12, 12));
        center.setOpaque(false);

        // Filter buttons row
        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        filterRow.setOpaque(false);

        GradientButton allBtn = new GradientButton("ALL MODES", UITheme.GRADIENT_PRIMARY);
        allBtn.setPreferredSize(new Dimension(130, 36));
        allBtn.setFont(UITheme.getFont(Font.BOLD, 12));
        allBtn.addActionListener(e -> setFilter("ALL"));

        GradientButton matchBtn = new GradientButton("MATCHING", UITheme.GRADIENT_CYAN);
        matchBtn.setPreferredSize(new Dimension(130, 36));
        matchBtn.setFont(UITheme.getFont(Font.BOLD, 12));
        matchBtn.setGlassMode(true);
        matchBtn.addActionListener(e -> setFilter("Matching"));

        GradientButton scenBtn = new GradientButton("SCENARIO", UITheme.GRADIENT_SECONDARY);
        scenBtn.setPreferredSize(new Dimension(130, 36));
        scenBtn.setFont(UITheme.getFont(Font.BOLD, 12));
        scenBtn.setGlassMode(true);
        scenBtn.addActionListener(e -> setFilter("Scenario"));

        filterRow.add(allBtn);
        filterRow.add(matchBtn);
        filterRow.add(scenBtn);
        center.add(filterRow, BorderLayout.NORTH);

        // Table Card
        JPanel tableCard = new JPanel(new BorderLayout(8, 6)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                int w = getWidth();
                int h = getHeight();

                g2.setColor(new Color(30, 41, 59, 220));
                g2.fill(new RoundRectangle2D.Double(0, 0, w, h, 20, 20));

                g2.setColor(new Color(251, 191, 36, 120));
                g2.setStroke(new BasicStroke(1.5f));
                g2.draw(new RoundRectangle2D.Double(1, 1, w - 2, h - 2, 20, 20));

                g2.dispose();
            }
        };
        tableCard.setOpaque(false);
        tableCard.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));

        String[] columns = {"Rank", "Player", "Mode", "Theme / Category", "Difficulty", "Score", "Time"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setRowHeight(34);
        table.setFont(UITheme.getFont(Font.BOLD, 13));
        table.setForeground(Color.WHITE);
        table.setBackground(new Color(15, 23, 42));
        table.setSelectionBackground(new Color(99, 102, 241, 120));
        table.setSelectionForeground(Color.WHITE);
        table.setShowGrid(false);

        // Custom Cell Renderer for highlighting top 3 ranks
        DefaultTableCellRenderer rankRenderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(JLabel.CENTER);
                if (row == 0) {
                    c.setForeground(new Color(251, 191, 36)); // Gold for #1
                } else if (row == 1) {
                    c.setForeground(new Color(226, 232, 240)); // Silver for #2
                } else if (row == 2) {
                    c.setForeground(new Color(249, 115, 22)); // Bronze for #3
                } else {
                    c.setForeground(Color.WHITE);
                }
                return c;
            }
        };

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(rankRenderer);
        }

        JTableHeader th = table.getTableHeader();
        th.setFont(UITheme.getFont(Font.BOLD, 13));
        th.setBackground(new Color(30, 41, 59));
        th.setForeground(new Color(251, 191, 36));
        th.setPreferredSize(new Dimension(100, 34));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        tableCard.add(scrollPane, BorderLayout.CENTER);
        center.add(tableCard, BorderLayout.CENTER);

        bg.add(center, BorderLayout.CENTER);

        // =====================================
        // FOOTER BUTTONS
        // =====================================
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 0));
        footer.setOpaque(false);

        GradientButton backBtn = new GradientButton("<- BACK TO DASHBOARD", UITheme.GRADIENT_PRIMARY);
        backBtn.setPreferredSize(new Dimension(220, 44));
        backBtn.setGlassMode(true);
        backBtn.addActionListener(e -> Main.showDashboard());

        GradientButton homeBtn = new GradientButton("HOME SCREEN", UITheme.GRADIENT_CYAN);
        homeBtn.setPreferredSize(new Dimension(160, 44));
        homeBtn.setGlassMode(true);
        homeBtn.addActionListener(e -> Main.showHomeScreen());

        footer.add(backBtn);
        footer.add(homeBtn);

        bg.add(footer, BorderLayout.SOUTH);

        add(bg, BorderLayout.CENTER);

        refreshTable();
    }

    private void setFilter(String filter) {
        this.currentFilter = filter;
        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        List<GameRecord> list = DataManager.getLeaderboardByMode(currentFilter);

        int rank = 1;
        for (GameRecord r : list) {
            tableModel.addRow(new Object[]{
                    "#" + rank,
                    r.getPlayerName(),
                    r.getMode(),
                    r.getTheme(),
                    r.getLevel(),
                    r.getScore() + " pts",
                    r.getFormattedTime()
            });
            rank++;
        }

        if (list.isEmpty()) {
            tableModel.addRow(new Object[]{"-", "No records found", "-", "-", "-", "-", "-"});
        }
    }
}
