package gui;

import app.Main;
import data.DataManager;
import util.SoundManager;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MemoryGamePanel extends JPanel {

    private final String playerName;
    private final String theme;
    private final int level;

    private ModernCardButton[] cards;
    private String[] values;

    private ModernCardButton firstCard = null;
    private ModernCardButton secondCard = null;

    private String firstValue = null;
    private String secondValue = null;

    private int moves = 0;
    private int matches = 0;
    private int score = 0;

    private long startTime;

    private JLabel movesLabel;
    private JLabel scoreLabel;
    private JLabel timeLabel;
    private GradientButton soundToggleBtn;
    private ToastFeedback toastFeedback;

    private javax.swing.Timer gameTimer;

    // =====================================================
    // THEMES
    // =====================================================

    private static final String[] ANIMALS = {
            "LION", "DOG", "CAT", "ELEPHANT",
            "TIGER", "RABBIT", "PANDA", "MONKEY",
            "FOX", "FROG", "BEAR", "HORSE",
            "ZEBRA", "GIRAFFE", "WOLF", "DEER",
            "KOALA", "PIG"
    };

    private static final String[] FRUITS = {
            "APPLE", "BANANA", "ORANGE", "STRAWBERRY",
            "WATERMELON", "GRAPES", "CHERRY", "MANGO",
            "PINEAPPLE", "KIWI", "PEACH", "LEMON",
            "PEAR", "PAPAYA", "GUAVA", "COCONUT",
            "PLUM", "MELON"
    };

    private static final String[] SPORTS = {
            "FOOTBALL", "BASKETBALL", "TENNIS", "CRICKET",
            "VOLLEYBALL", "HOCKEY", "BOXING", "GOLF",
            "BADMINTON", "SWIMMING", "RUNNING", "RACING",
            "BASEBALL", "CYCLING", "SKATING", "ARCHERY",
            "WRESTLING", "SURFING"
    };

    private static final String[] SPACE = {
            "ROCKET", "EARTH", "PLANET", "STAR",
            "MOON", "SUN", "ALIEN", "UFO",
            "GALAXY", "COMET", "ASTEROID", "SATELLITE",
            "MARS", "VENUS", "JUPITER", "SATURN",
            "NEPTUNE", "METEOR"
    };

    private static final String[] VEHICLES = {
            "CAR", "BUS", "AIRPLANE", "TRAIN",
            "HELICOPTER", "TAXI", "POLICE", "AMBULANCE",
            "FIRE TRUCK", "TRACTOR", "RACE CAR", "BICYCLE",
            "SHIP", "TRUCK", "MOTORCYCLE", "SCOOTER",
            "SUBMARINE", "VAN"
    };

    private static final String[] FOOD = {
            "PIZZA", "BURGER", "FRIES", "HOTDOG",
            "POPCORN", "DONUT", "COOKIE", "CAKE",
            "CHOCOLATE", "CANDY", "TACO", "NOODLES",
            "SANDWICH", "ICE CREAM", "PUDDING", "PASTA",
            "SOUP", "RICE"
    };

    private static final String[] NATURE = {
            "TREE", "FLOWER", "SUNFLOWER", "ROSE",
            "PINE TREE", "CLOVER", "LEAF", "PALM TREE",
            "CACTUS", "MAPLE", "GRASS", "FOREST",
            "MOUNTAIN", "RIVER", "RAIN", "CLOUD",
            "RAINBOW", "VOLCANO"
    };

    private static final String[] TECHNOLOGY = {
            "LAPTOP", "COMPUTER", "ROBOT", "PHONE",
            "KEYBOARD", "MOUSE", "PRINTER", "CAMERA",
            "HEADPHONES", "TV", "MEMORY", "BATTERY",
            "RADIO", "TABLET", "SERVER", "DRONE",
            "ROUTER", "USB"
    };

    private static final String[] OCEAN = {
            "FISH", "DOLPHIN", "WHALE", "SHARK",
            "OCTOPUS", "CRAB", "SHELL", "SEAL",
            "SQUID", "TURTLE", "WAVE", "STARFISH",
            "JELLYFISH", "SEAHORSE", "CORAL", "LOBSTER",
            "RAY", "PENGUIN"
    };

    private static final String[] EMOJI = {
            "HAPPY", "SMILE", "LAUGH", "LOVE",
            "COOL", "WOW", "PARTY", "THINK",
            "SLEEP", "ANGRY", "SAD", "SURPRISE",
            "CRY", "HEART", "FIRE", "STAR",
            "CLAP", "GOOD"
    };

    // =====================================================
    // CONSTRUCTOR
    // =====================================================

    public MemoryGamePanel(
            String playerName,
            String theme,
            int level
    ) {
        this.playerName = playerName;
        this.theme = theme;
        this.level = level;

        setLayout(new BorderLayout());
        setOpaque(false);

        startTime = System.currentTimeMillis();

        createGame();
        startTimer();
    }

    // =====================================================
    // CREATE GAME
    // =====================================================

    private void createGame() {
        removeAll();

        BackgroundPanel bg = new BackgroundPanel();
        bg.setLayout(new BorderLayout(15, 12));
        bg.setBorder(BorderFactory.createEmptyBorder(16, 25, 16, 25));

        createHeader(bg);
        createCards(bg);
        createBottom(bg);

        add(bg, BorderLayout.CENTER);

        revalidate();
        repaint();
    }

    // =====================================================
    // HEADER
    // =====================================================

    private void createHeader(JPanel parent) {
        JPanel header = new JPanel(new BorderLayout(15, 4));
        header.setOpaque(false);

        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setOpaque(false);

        JLabel title = new JLabel("MATCHING CARDS — " + theme.toUpperCase());
        title.setFont(UITheme.getTitleFont(22));
        title.setForeground(Color.WHITE);

        String levelName = (level == 1) ? "EASY" : ((level == 2) ? "MEDIUM" : "HARD");
        JLabel details = new JLabel(
                "PLAYER: " + playerName.toUpperCase() +
                "  •  THEME: " + theme.toUpperCase() +
                "  •  DIFFICULTY: " + levelName + " (" + getColumns() + "x" + getRows() + ")"
        );
        details.setFont(UITheme.getFont(Font.BOLD, 13));
        details.setForeground(new Color(203, 213, 225));

        left.add(title);
        left.add(Box.createVerticalStrut(2));
        left.add(details);

        // Stats Right
        JPanel stats = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        stats.setOpaque(false);

        movesLabel = createHudChip("MOVES: " + moves, new Color(6, 182, 212));
        scoreLabel = createHudChip("SCORE: " + score, new Color(245, 158, 11));
        timeLabel = createHudChip("TIME: 00:00", new Color(16, 185, 129));

        soundToggleBtn = new GradientButton(SoundManager.isMuted() ? "SOUND: OFF" : "SOUND: ON", UITheme.GRADIENT_PRIMARY);
        soundToggleBtn.setFont(UITheme.getFont(Font.BOLD, 12));
        soundToggleBtn.setPreferredSize(new Dimension(115, 32));
        soundToggleBtn.setGlassMode(true);
        soundToggleBtn.addActionListener(e -> {
            boolean isMuted = SoundManager.toggleMute();
            soundToggleBtn.setText(isMuted ? "SOUND: OFF" : "SOUND: ON");
        });

        stats.add(movesLabel);
        stats.add(scoreLabel);
        stats.add(timeLabel);
        stats.add(soundToggleBtn);

        header.add(left, BorderLayout.WEST);
        header.add(stats, BorderLayout.EAST);

        parent.add(header, BorderLayout.NORTH);
    }

    private JLabel createHudChip(String text, Color accent) {
        JLabel chip = new JLabel(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                int w = getWidth();
                int h = getHeight();

                g2.setColor(new Color(30, 41, 59, 210));
                g2.fillRoundRect(0, 0, w, h, 14, 14);

                g2.setColor(new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), 160));
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(0, 0, w - 1, h - 1, 14, 14);

                g2.dispose();
                super.paintComponent(g);
            }
        };

        chip.setFont(UITheme.getFont(Font.BOLD, 12));
        chip.setForeground(Color.WHITE);
        chip.setBorder(BorderFactory.createEmptyBorder(6, 12, 6, 12));
        chip.setOpaque(false);
        return chip;
    }

    // =====================================================
    // CREATE CARDS
    // =====================================================

    private void createCards(JPanel parent) {
        String[] items = getThemeItems();
        int totalCards = getTotalCards();
        int pairs = totalCards / 2;

        List<String> list = new ArrayList<>();

        for (int i = 0; i < pairs; i++) {
            list.add(items[i % items.length]);
            list.add(items[i % items.length]);
        }

        if (totalCards % 2 != 0) {
            list.add("BONUS");
        }

        Collections.shuffle(list);
        values = list.toArray(new String[0]);
        cards = new ModernCardButton[totalCards];

        int columns = getColumns();
        int rows = getRows();

        JPanel cardPanel = new JPanel(new GridLayout(rows, columns, 10, 10));
        cardPanel.setOpaque(false);

        UITheme.ThemeInfo themeInfo = UITheme.getThemeInfo(theme);
        Color accent = themeInfo.gradient[0];

        for (int i = 0; i < totalCards; i++) {
            ModernCardButton card = new ModernCardButton("?");
            card.setThemeName(theme);
            card.setThemeAccentColor(accent);
            cards[i] = card;

            final int index = i;
            card.addActionListener(e -> cardClicked(index));

            cardPanel.add(card);
        }

        // Overlay with ToastFeedback
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setLayout(new OverlayLayout(layeredPane));

        toastFeedback = new ToastFeedback();
        toastFeedback.setAlignmentX(0.5f);
        toastFeedback.setAlignmentY(0.08f);

        layeredPane.add(toastFeedback, JLayeredPane.PALETTE_LAYER);
        layeredPane.add(cardPanel, JLayeredPane.DEFAULT_LAYER);

        parent.add(layeredPane, BorderLayout.CENTER);
    }

    // =====================================================
    // GRID SIZE
    // =====================================================

    private int getColumns() {
        if (level == 1) return 4;
        if (level == 2) return 5;
        return 6;
    }

    private int getRows() {
        if (level == 1) return 4;
        if (level == 2) return 5;
        return 6;
    }

    private int getTotalCards() {
        if (level == 1) return 16;
        if (level == 2) return 25;
        return 36;
    }

    private int getPairCount() {
        return getTotalCards() / 2;
    }

    // =====================================================
    // THEME ITEMS
    // =====================================================

    private String[] getThemeItems() {
        String selected = theme.trim().toUpperCase();

        switch (selected) {
            case "ANIMALS": return ANIMALS;
            case "FRUITS": return FRUITS;
            case "SPORTS": return SPORTS;
            case "SPACE": return SPACE;
            case "VEHICLES": return VEHICLES;
            case "FOOD": return FOOD;
            case "NATURE": return NATURE;
            case "OBJECTS":
            case "TECHNOLOGY": return TECHNOLOGY;
            case "OCEAN": return OCEAN;
            case "EMOJI": return EMOJI;
            default: return FRUITS;
        }
    }

    // =====================================================
    // CARD CLICK
    // =====================================================

    private void cardClicked(int index) {
        if (firstCard != null && secondCard != null) {
            return; // Lock input while checking 2 cards
        }

        ModernCardButton card = cards[index];

        if (!card.getRawValue().equals("?")) {
            return;
        }

        SoundManager.playCardFlip();
        String value = values[index];

        // BONUS CARD
        if ("BONUS".equals(value)) {
            card.setText("BONUS");
            score += 15;
            SoundManager.playCorrectMatch();
            toastFeedback.showPositive("+15 Bonus Points!");
            updateStats();

            javax.swing.Timer bonusTimer = new javax.swing.Timer(700, e -> card.setText("?"));
            bonusTimer.setRepeats(false);
            bonusTimer.start();
            return;
        }

        // SHOW CARD
        card.setText(value);

        // FIRST CARD
        if (firstCard == null) {
            firstCard = card;
            firstValue = value;
            return;
        }

        // SECOND CARD
        secondCard = card;
        secondValue = value;
        moves++;

        updateStats();

        javax.swing.Timer checkTimer = new javax.swing.Timer(650, e -> checkMatch());
        checkTimer.setRepeats(false);
        checkTimer.start();
    }

    // =====================================================
    // CHECK MATCH
    // =====================================================

    private void checkMatch() {
        if (firstValue != null && firstValue.equals(secondValue)) {
            matches++;
            int points = 10 * level;
            score += points;

            SoundManager.playCorrectMatch();

            String[] praises = {"Great Match! +" + points, "Excellent! +" + points, "Awesome! +" + points, "Perfect! +" + points};
            String praise = praises[(int) (Math.random() * praises.length)];
            toastFeedback.showPositive(praise);

            firstCard.setMatched(true);
            secondCard.setMatched(true);

            firstCard = null;
            secondCard = null;
            firstValue = null;
            secondValue = null;

            updateStats();

            if (matches >= getPairCount()) {
                levelCompleted();
            }

        } else {
            SoundManager.playWrongMatch();
            toastFeedback.showGentle("Try Again!");

            if (firstCard != null) firstCard.setText("?");
            if (secondCard != null) secondCard.setText("?");

            firstCard = null;
            secondCard = null;
            firstValue = null;
            secondValue = null;
        }
    }

    // =====================================================
    // LEVEL COMPLETED
    // =====================================================

    private void levelCompleted() {
        stopTimer();
        int seconds = getElapsedSeconds();
        int finalScore = score;
        String levelName = (level == 1) ? "Easy" : ((level == 2) ? "Medium" : "Hard");

        // Persist completed record
        DataManager.saveCompletedGame(
                playerName,
                Main.playerAge,
                "Matching",
                theme,
                levelName,
                finalScore,
                seconds,
                moves
        );
        Main.saveGameResult(theme, level, finalScore, moves, seconds);

        int rank = DataManager.calculateRank(finalScore, seconds);

        int stars = 3;
        int expectedMoves = getPairCount() * 2;
        if (moves > expectedMoves + 6) stars = 2;
        if (moves > expectedMoves + 14) stars = 1;

        CelebrationDialog dialog = new CelebrationDialog(
                Main.frame,
                "★ LEVEL " + level + " COMPLETED! ★",
                playerName,
                finalScore,
                seconds,
                rank,
                stars,
                (level < 3) ? "NEXT LEVEL ->" : null,
                (level < 3) ? () -> Main.showMemoryGame(playerName, theme, level + 1) : null,
                () -> Main.showLeaderboard(),
                () -> Main.showDashboard()
        );
        dialog.setVisible(true);
    }

    // =====================================================
    // BOTTOM
    // =====================================================

    private void createBottom(JPanel parent) {
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 0));
        bottom.setOpaque(false);

        GradientButton back = new GradientButton("<- BACK TO THEMES", UITheme.GRADIENT_PRIMARY);
        back.setPreferredSize(new Dimension(200, 44));
        back.setGlassMode(true);
        back.addActionListener(e -> {
            stopTimer();
            Main.showThemePanel();
        });

        GradientButton restart = new GradientButton("RESTART LEVEL", UITheme.GRADIENT_CYAN);
        restart.setPreferredSize(new Dimension(170, 44));
        restart.setGlassMode(true);
        restart.addActionListener(e -> {
            stopTimer();
            Main.showMemoryGame(playerName, theme, level);
        });

        GradientButton dash = new GradientButton("DASHBOARD", UITheme.GRADIENT_SECONDARY);
        dash.setPreferredSize(new Dimension(160, 44));
        dash.setGlassMode(true);
        dash.addActionListener(e -> {
            stopTimer();
            Main.showDashboard();
        });

        bottom.add(back);
        bottom.add(restart);
        bottom.add(dash);

        parent.add(bottom, BorderLayout.SOUTH);
    }

    private javax.swing.Timer shineAnimationTimer;

    private void startTimer() {
        startTime = System.currentTimeMillis();

        gameTimer = new javax.swing.Timer(1000, e -> updateTime());
        gameTimer.setInitialDelay(1000);
        gameTimer.start();

        // 35ms shine sweep animation loop across face-down cards
        shineAnimationTimer = new javax.swing.Timer(35, e -> {
            if (cards != null) {
                for (ModernCardButton card : cards) {
                    if (card != null && "?".equals(card.getRawValue()) && !card.isMatched()) {
                        card.repaint();
                    }
                }
            }
        });
        shineAnimationTimer.start();

        updateTime();
    }

    private void updateTime() {
        if (timeLabel == null) return;
        int seconds = getElapsedSeconds();
        int m = seconds / 60;
        int s = seconds % 60;
        timeLabel.setText("TIME: " + String.format("%02d:%02d", m, s));
        timeLabel.repaint();
    }

    private int getElapsedSeconds() {
        long elapsed = System.currentTimeMillis() - startTime;
        return (int) (elapsed / 1000L);
    }

    private void stopTimer() {
        if (gameTimer != null) {
            gameTimer.stop();
            gameTimer = null;
        }
        if (shineAnimationTimer != null) {
            shineAnimationTimer.stop();
            shineAnimationTimer = null;
        }
    }

    // =====================================================
    // UPDATE STATS
    // =====================================================

    private void updateStats() {
        if (movesLabel != null) {
            movesLabel.setText("MOVES: " + moves);
            movesLabel.repaint();
        }
        if (scoreLabel != null) {
            scoreLabel.setText("SCORE: " + score);
            scoreLabel.repaint();
        }
        updateTime();
    }
}