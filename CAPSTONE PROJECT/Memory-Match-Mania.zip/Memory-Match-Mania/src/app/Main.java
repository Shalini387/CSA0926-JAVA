package app;

import data.DataManager;
import gui.BackgroundPanel;
import gui.DashboardPanel;
import gui.GradientButton;
import gui.LeaderboardPanel;
import gui.MemoryGamePanel;
import gui.PlayerSetupPanel;
import gui.ScenarioGamePanel;
import gui.ScenarioModePanel;
import gui.StatBadge;
import gui.ThemePanel;
import gui.UITheme;
import util.ImageManager;
import util.SoundManager;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class Main {

    public static JFrame frame;

    public static String playerName = "Player";
    public static int playerAge = 10;

    // Latest game result
    public static int lastScore = 0;
    public static int lastMoves = 0;
    public static int lastTime = 0;
    public static String lastTheme = "-";
    public static int lastLevel = 0;

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }

        // Initialize audio sound system, image asset generators, and local database
        SoundManager.init();
        ImageManager.init();
        DataManager.init();

        SwingUtilities.invokeLater(() -> {
            frame = new JFrame("Memory Match Mania — Brain & Real-World Decision Training");
            frame.setSize(1200, 820);
            frame.setMinimumSize(new Dimension(1000, 700));
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);

            showPlayerSetup();

            frame.setVisible(true);
        });
    }

    // =========================================
    // PLAYER SETUP
    // =========================================

    public static void showPlayerSetup() {
        SoundManager.playButtonClick();
        frame.setContentPane(new PlayerSetupPanel(() -> showHomeScreen()));
        frame.revalidate();
        frame.repaint();
    }

    // =========================================
    // HOME SCREEN
    // =========================================

    public static void showHomeScreen() {
        BackgroundPanel panel = new BackgroundPanel();
        panel.setLayout(new BorderLayout(20, 16));
        panel.setBorder(BorderFactory.createEmptyBorder(22, 40, 22, 40));

        // =====================================
        // HEADER
        // =====================================
        JPanel header = new JPanel(new BorderLayout(10, 8));
        header.setOpaque(false);

        JPanel titleBox = new JPanel();
        titleBox.setLayout(new BoxLayout(titleBox, BoxLayout.Y_AXIS));
        titleBox.setOpaque(false);

        JLabel title = new JLabel("MEMORY MATCH MANIA");
        title.setFont(UITheme.getTitleFont(34));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("Interactive Memory Matching & Real-World Daily Decision Challenges");
        subtitle.setFont(UITheme.getFont(Font.PLAIN, 15));
        subtitle.setForeground(new Color(203, 213, 225));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        titleBox.add(title);
        titleBox.add(Box.createVerticalStrut(4));
        titleBox.add(subtitle);

        // Player profile chip & Sound Toggle
        JPanel playerBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 4));
        playerBar.setOpaque(false);

        JLabel playerBadge = new JLabel("PLAYER: " + playerName.toUpperCase() + " (" + playerAge + " YRS)");
        playerBadge.setFont(UITheme.getFont(Font.BOLD, 14));
        playerBadge.setForeground(new Color(251, 191, 36));
        playerBadge.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(251, 191, 36, 140), 1, true),
                BorderFactory.createEmptyBorder(5, 16, 5, 16)
        ));

        GradientButton editPlayerBtn = new GradientButton("SWITCH PLAYER", UITheme.GRADIENT_CYAN);
        editPlayerBtn.setFont(UITheme.getFont(Font.BOLD, 12));
        editPlayerBtn.setPreferredSize(new Dimension(135, 30));
        editPlayerBtn.setGlassMode(true);
        editPlayerBtn.addActionListener(e -> showPlayerSetup());

        GradientButton soundBtn = new GradientButton(SoundManager.isMuted() ? "SOUND: OFF" : "SOUND: ON", UITheme.GRADIENT_PRIMARY);
        soundBtn.setFont(UITheme.getFont(Font.BOLD, 12));
        soundBtn.setPreferredSize(new Dimension(120, 30));
        soundBtn.setGlassMode(true);
        soundBtn.addActionListener(e -> {
            boolean muted = SoundManager.toggleMute();
            soundBtn.setText(muted ? "SOUND: OFF" : "SOUND: ON");
        });

        playerBar.add(playerBadge);
        playerBar.add(editPlayerBtn);
        playerBar.add(soundBtn);

        header.add(titleBox, BorderLayout.NORTH);
        header.add(playerBar, BorderLayout.SOUTH);
        panel.add(header, BorderLayout.NORTH);

        // =====================================
        // GAME MODE CARDS
        // =====================================
        JPanel center = new JPanel(new GridLayout(1, 2, 28, 28));
        center.setOpaque(false);

        // Card 1: Matching Cards
        JPanel card1 = createGameModeCard(
                true,
                "MATCHING CARDS",
                "Explore 10 vibrant themes with unified card backs. Flip cards and match hidden pairs across 3 difficulty levels!",
                "PLAY MATCHING ->",
                UITheme.GRADIENT_PRIMARY,
                () -> showThemePanel()
        );

        // Card 2: Scenario Match
        JPanel card2 = createGameModeCard(
                false,
                "SCENARIO MATCH",
                "Read real-world daily situations and pick the right 2 cards out of 6. Test your everyday decision-making!",
                "PLAY SCENARIOS ->",
                UITheme.GRADIENT_SECONDARY,
                () -> showScenarioMode()
        );

        center.add(card1);
        center.add(card2);

        panel.add(center, BorderLayout.CENTER);

        // =====================================
        // BOTTOM NAVIGATION & QUICK STATS
        // =====================================
        JPanel bottom = new JPanel(new BorderLayout(12, 10));
        bottom.setOpaque(false);

        // Main Navigation Buttons Bar
        JPanel navBar = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 0));
        navBar.setOpaque(false);

        GradientButton dashBtn = new GradientButton("MY DASHBOARD", UITheme.GRADIENT_CYAN);
        dashBtn.setPreferredSize(new Dimension(180, 44));
        dashBtn.addActionListener(e -> showDashboard());

        GradientButton leadBtn = new GradientButton("LEADERBOARD", UITheme.GRADIENT_AMBER);
        leadBtn.setPreferredSize(new Dimension(180, 44));
        leadBtn.addActionListener(e -> showLeaderboard());

        GradientButton exitBtn = new GradientButton("EXIT GAME", UITheme.GRADIENT_SECONDARY);
        exitBtn.setPreferredSize(new Dimension(140, 44));
        exitBtn.setGlassMode(true);
        exitBtn.addActionListener(e -> System.exit(0));

        navBar.add(dashBtn);
        navBar.add(leadBtn);
        navBar.add(exitBtn);

        // Stats Badges Bar
        JPanel statsBar = new JPanel(new GridLayout(1, 4, 14, 14));
        statsBar.setOpaque(false);
        statsBar.setPreferredSize(new Dimension(1100, 75));

        DataManager.PlayerStats stats = DataManager.getPlayerStats(playerName);

        statsBar.add(new StatBadge("●", "Games Played", String.valueOf(stats.totalGamesPlayed), new Color(6, 182, 212)));
        statsBar.add(new StatBadge("★", "Total Score", String.valueOf(stats.totalScore), new Color(245, 158, 11)));
        statsBar.add(new StatBadge("▲", "Best Score", stats.bestScore + " pts", new Color(16, 185, 129)));

        String themeText = (lastLevel == 0) ? "None" : lastTheme + " (L" + lastLevel + ")";
        statsBar.add(new StatBadge("◆", "Last Played", themeText, new Color(139, 92, 246)));

        bottom.add(navBar, BorderLayout.NORTH);
        bottom.add(statsBar, BorderLayout.SOUTH);

        panel.add(bottom, BorderLayout.SOUTH);

        frame.setContentPane(panel);
        frame.revalidate();
        frame.repaint();
    }

    private static JPanel createGameModeCard(
            boolean isMatchingCard,
            String titleText,
            String description,
            String buttonText,
            Color[] gradient,
            Runnable onAction
    ) {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                UITheme.setRenderingHints(g2);
                int w = getWidth();
                int h = getHeight();

                // Glass card body
                g2.setColor(new Color(30, 41, 59, 210));
                g2.fill(new RoundRectangle2D.Double(0, 0, w, h, 24, 24));

                // Top gradient glow banner
                GradientPaint bannerGlow = new GradientPaint(
                        0, 0, new Color(gradient[0].getRed(), gradient[0].getGreen(), gradient[0].getBlue(), 70),
                        0, (float) (h * 0.45), new Color(0, 0, 0, 0)
                );
                g2.setPaint(bannerGlow);
                g2.fill(new RoundRectangle2D.Double(0, 0, w, h, 24, 24));

                // Border
                g2.setColor(new Color(gradient[0].getRed(), gradient[0].getGreen(), gradient[0].getBlue(), 140));
                g2.setStroke(new BasicStroke(1.8f));
                g2.draw(new RoundRectangle2D.Double(1, 1, w - 2, h - 2, 24, 24));

                // Vector Icon
                int icx = w / 2;
                int icy = 55;
                if (isMatchingCard) {
                    g2.setColor(new Color(255, 255, 255, 120));
                    g2.fill(new RoundRectangle2D.Double(icx - 26, icy - 20, 26, 36, 6, 6));
                    g2.setColor(gradient[0]);
                    g2.fill(new RoundRectangle2D.Double(icx - 8, icy - 14, 26, 36, 6, 6));
                    g2.setColor(Color.WHITE);
                    g2.draw(new RoundRectangle2D.Double(icx - 8, icy - 14, 26, 36, 6, 6));
                } else {
                    g2.setColor(gradient[0]);
                    g2.fillOval(icx - 14, icy - 18, 28, 28);
                    g2.setColor(Color.WHITE);
                    g2.fillRect(icx - 8, icy + 6, 16, 6);
                    g2.fillRect(icx - 5, icy + 12, 10, 4);
                }

                g2.dispose();
            }
        };

        card.setOpaque(false);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createEmptyBorder(85, 30, 24, 30));

        // Title
        JLabel title = new JLabel(titleText);
        title.setFont(UITheme.getTitleFont(23));
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Description
        JLabel desc = new JLabel("<html><center>" + description + "</center></html>");
        desc.setFont(UITheme.getFont(Font.PLAIN, 14));
        desc.setForeground(new Color(203, 213, 225));
        desc.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Play Button
        GradientButton btn = new GradientButton(buttonText, gradient);
        btn.setPreferredSize(new Dimension(240, 50));
        btn.setMaximumSize(new Dimension(240, 50));
        btn.setAlignmentX(Component.CENTER_ALIGNMENT);
        btn.addActionListener(e -> {
            SoundManager.playButtonClick();
            onAction.run();
        });

        card.add(title);
        card.add(Box.createVerticalStrut(10));
        card.add(desc);
        card.add(Box.createVerticalStrut(22));
        card.add(btn);
        card.add(Box.createVerticalGlue());

        return card;
    }

    // =========================================
    // DASHBOARD & LEADERBOARD NAVIGATION
    // =========================================

    public static void showDashboard() {
        SoundManager.playButtonClick();
        frame.setContentPane(new DashboardPanel());
        frame.revalidate();
        frame.repaint();
    }

    public static void showLeaderboard() {
        SoundManager.playButtonClick();
        frame.setContentPane(new LeaderboardPanel());
        frame.revalidate();
        frame.repaint();
    }

    // =========================================
    // THEME PANEL
    // =========================================

    public static void showThemePanel() {
        SoundManager.playButtonClick();
        frame.setContentPane(new ThemePanel());
        frame.revalidate();
        frame.repaint();
    }

    // =========================================
    // START MEMORY GAME
    // =========================================

    public static void startMemoryGame(String theme, int level) {
        SoundManager.playButtonClick();
        frame.setContentPane(new MemoryGamePanel(playerName, theme, level));
        frame.revalidate();
        frame.repaint();
    }

    // =========================================
    // SHOW MEMORY GAME
    // =========================================

    public static void showMemoryGame(String name, String theme, int level) {
        SoundManager.playButtonClick();
        frame.setContentPane(new MemoryGamePanel(name, theme, level));
        frame.revalidate();
        frame.repaint();
    }

    // =========================================
    // SAVE GAME RESULT
    // =========================================

    public static void saveGameResult(String theme, int level, int score, int moves, int time) {
        lastTheme = theme;
        lastLevel = level;
        lastScore = score;
        lastMoves = moves;
        lastTime = time;
    }

    // =========================================
    // ADD SCORE
    // =========================================

    public static void addScore(String name, int score) {
        lastScore = score;
    }

    // =========================================
    // SCENARIO MODE
    // =========================================

    public static void showScenarioMode() {
        SoundManager.playButtonClick();
        frame.setContentPane(new ScenarioModePanel(playerName, playerAge));
        frame.revalidate();
        frame.repaint();
    }

    // =========================================
    // SCENARIO GAME
    // =========================================

    public static void showScenarioGame(String name, int age, String difficulty) {
        SoundManager.playButtonClick();
        frame.setContentPane(new ScenarioGamePanel(name, age, difficulty));
        frame.revalidate();
        frame.repaint();
    }
}