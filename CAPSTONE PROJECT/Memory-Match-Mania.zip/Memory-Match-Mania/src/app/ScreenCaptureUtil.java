package app;

import gui.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class ScreenCaptureUtil {

    public static void main(String[] args) {
        System.out.println("Generating visual UI preview screenshots...");

        File screenshotsDir = new File("screenshots");
        if (!screenshotsDir.exists()) {
            screenshotsDir.mkdirs();
        }

        SwingUtilities.invokeLater(() -> {
            try {
                JFrame frame = new JFrame("Capture");
                frame.setSize(1200, 800);
                frame.setLayout(new BorderLayout());
                Main.frame = frame;

                // 1. Setup Screen
                PlayerSetupPanel setup = new PlayerSetupPanel(() -> {});
                captureComponent(setup, "screenshots/1_player_setup.png");

                // 2. Dashboard Screen
                Main.showDashboard();
                captureComponent((JComponent) frame.getContentPane(), "screenshots/2_dashboard.png");

                // 3. Theme Panel
                ThemePanel themePanel = new ThemePanel();
                captureComponent(themePanel, "screenshots/3_theme_selector.png");

                // 4. Memory Game
                MemoryGamePanel gamePanel = new MemoryGamePanel("Alex", "Animals", 1);
                captureComponent(gamePanel, "screenshots/4_memory_game.png");

                // 5. Scenario Game
                ScenarioGamePanel scenarioGame = new ScenarioGamePanel("Alex", 18, "MEDIUM");
                captureComponent(scenarioGame, "screenshots/5_scenario_game.png");

                System.out.println("Screenshots generated successfully in ./screenshots/ directory!");
                System.exit(0);
            } catch (Exception e) {
                e.printStackTrace();
                System.exit(1);
            }
        });
    }

    private static void captureComponent(JComponent comp, String outputPath) throws Exception {
        comp.setSize(1200, 800);
        layoutComponent(comp);

        BufferedImage image = new BufferedImage(1200, 800, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        comp.paint(g2);
        g2.dispose();

        ImageIO.write(image, "PNG", new File(outputPath));
        System.out.println("Saved: " + outputPath + " (bytes: " + new File(outputPath).length() + ")");
    }

    private static void layoutComponent(Component c) {
        c.doLayout();
        if (c instanceof Container) {
            for (Component child : ((Container) c).getComponents()) {
                layoutComponent(child);
            }
        }
    }
}
