package app;

import data.DataManager;
import data.GameRecord;
import gui.*;
import scenario.Scenario;
import scenario.ScenarioDatabase;
import util.ImageManager;
import util.SoundManager;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;

public class ComprehensiveTest {

    public static void main(String[] args) {
        System.out.println("Running comprehensive verification test for Memory Match Mania...");

        // 1. Initialize Sound, Image, and Data Managers
        SoundManager.init();
        ImageManager.init();
        DataManager.init();

        // 2. Verify Data Layer & Leaderboard
        System.out.println("Verifying Data Layer & Local Persistence...");
        DataManager.saveCompletedGame("Hari", 10, "Matching", "Fruits", "Medium", 90, 192, 24);
        DataManager.saveCompletedGame("Hari", 10, "Scenario", "Daily Life", "Hard", 120, 140, 18);

        DataManager.PlayerStats stats = DataManager.getPlayerStats("Hari");
        System.out.println("Player Hari Games: " + stats.totalGamesPlayed + ", Total Score: " + stats.totalScore);
        List<GameRecord> leaderboard = DataManager.getLeaderboard();
        System.out.println("Leaderboard Records: " + leaderboard.size());

        if (leaderboard.isEmpty()) {
            System.err.println("ERROR: Leaderboard should not be empty!");
            System.exit(1);
        }

        // 3. Verify Real-World Scenarios
        System.out.println("Verifying Scenarios (2 of 6 rules)...");
        for (Scenario s : ScenarioDatabase.getScenariosByDifficulty("EASY")) {
            validateScenario(s);
        }
        for (Scenario s : ScenarioDatabase.getScenariosByDifficulty("MEDIUM")) {
            validateScenario(s);
        }
        for (Scenario s : ScenarioDatabase.getScenariosByDifficulty("HARD")) {
            validateScenario(s);
        }

        // 4. Test UI Views & Capture Screenshots
        SwingUtilities.invokeLater(() -> {
            try {
                JFrame frame = new JFrame("Test Window");
                frame.setSize(1200, 800);
                Main.frame = frame;
                Main.playerName = "Hari";
                Main.playerAge = 10;

                File screenshotsDir = new File("screenshots");
                if (!screenshotsDir.exists()) screenshotsDir.mkdirs();

                // 1: Home Screen
                Main.showHomeScreen();
                captureComponent((JComponent) frame.getContentPane(), "screenshots/2_home_screen.png");

                // 2: Dashboard
                DashboardPanel dashPanel = new DashboardPanel();
                captureComponent(dashPanel, "screenshots/3_dashboard.png");

                // 3: Leaderboard
                LeaderboardPanel leadPanel = new LeaderboardPanel();
                captureComponent(leadPanel, "screenshots/4_leaderboard.png");

                // 4: Theme Selector
                ThemePanel themePanel = new ThemePanel();
                captureComponent(themePanel, "screenshots/5_theme_selector.png");

                // 5: Memory Matching Game with Unified Card Backs
                MemoryGamePanel memoryPanel = new MemoryGamePanel("Hari", "Fruits", 1);
                captureComponent(memoryPanel, "screenshots/6_memory_game.png");

                // 6: Scenario Game with 2x3 Grid of 6 Real-World Image Cards
                ScenarioGamePanel scenarioGame = new ScenarioGamePanel("Hari", 10, "EASY");
                captureComponent(scenarioGame, "screenshots/7_scenario_game.png");

                // 7: Dual-Side Firework Celebration Dialog
                CelebrationDialog dialog = new CelebrationDialog(
                        frame,
                        "★ LEVEL COMPLETED! ★",
                        "Hari",
                        90,
                        192,
                        2,
                        3,
                        "NEXT LEVEL ->",
                        () -> {},
                        () -> {},
                        () -> {}
                );
                captureComponentWithSize((JComponent) dialog.getContentPane(), "screenshots/8_celebration_dialog.png", 580, 500);

                System.out.println("ALL COMPREHENSIVE TESTS PASSED SUCCESSFULLY!");
                System.exit(0);

            } catch (Exception e) {
                e.printStackTrace();
                System.exit(1);
            }
        });
    }

    private static void validateScenario(Scenario s) {
        if (s.getCorrectCards().size() != 2) {
            System.err.println("ERROR: Scenario " + s.getId() + " has " + s.getCorrectCards().size() + " correct cards (expected exactly 2)!");
            System.exit(1);
        }
        if (s.getDistractorCards().size() != 4) {
            System.err.println("ERROR: Scenario " + s.getId() + " has " + s.getDistractorCards().size() + " distractors (expected exactly 4)!");
            System.exit(1);
        }
        if (s.getAllCardsShuffled().size() != 6) {
            System.err.println("ERROR: Scenario " + s.getId() + " does not have total 6 cards!");
            System.exit(1);
        }
    }

    private static void captureComponent(JComponent comp, String outputPath) throws Exception {
        captureComponentWithSize(comp, outputPath, 1200, 800);
    }

    private static void captureComponentWithSize(JComponent comp, String outputPath, int width, int height) throws Exception {
        comp.setSize(width, height);
        layoutComponent(comp);

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = image.createGraphics();
        comp.paint(g2);
        g2.dispose();

        ImageIO.write(image, "PNG", new File(outputPath));
        System.out.println("Saved: " + outputPath);
    }

    private static void layoutComponent(Component c) {
        c.doLayout();
        if (c instanceof Container) {
            for (Component child : ((Container) c).getComponents()) {
                layoutComponent(child);
            }
        }
    }
}
