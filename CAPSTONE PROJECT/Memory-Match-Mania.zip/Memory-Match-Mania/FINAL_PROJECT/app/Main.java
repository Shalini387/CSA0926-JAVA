package app;

import gui.PlayerSetupPanel;
import gui.MemoryGamePanel;

import javax.swing.*;
import java.awt.*;

public class Main {

    static JFrame frame;

    static String playerName = "Player";
    static int playerAge = 18;

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            frame = new JFrame("Memory Match Mania");

            frame.setSize(1440, 900);

            frame.setDefaultCloseOperation(
                    JFrame.EXIT_ON_CLOSE
            );

            frame.setLocationRelativeTo(null);

            showPlayerSetup();

            frame.setVisible(true);
        });
    }

    public static void showPlayerSetup() {

        PlayerSetupPanel panel =
                new PlayerSetupPanel(
                        () -> showDashboard()
                );

        frame.setContentPane(panel);

        frame.revalidate();
        frame.repaint();
    }

    public static void showDashboard() {

        JPanel dashboard =
                new JPanel(
                        new BorderLayout(25, 25)
                );

        dashboard.setBackground(
                new Color(247, 247, 255)
        );

        dashboard.setBorder(
                BorderFactory.createEmptyBorder(
                        40, 60, 40, 60
                )
        );

        // HEADER

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setOpaque(false);

        JLabel title =
                new JLabel(
                        "MEMORY MATCH MANIA"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        38
                )
        );

        title.setForeground(
                new Color(45, 45, 75)
        );

        JLabel playerInfo =
                new JLabel(
                        "Player: " +
                        playerName +
                        "    Age: " +
                        playerAge
                );

        playerInfo.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        18
                )
        );

        playerInfo.setForeground(
                new Color(100, 100, 130)
        );

        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                playerInfo,
                BorderLayout.EAST
        );

        dashboard.add(
                header,
                BorderLayout.NORTH
        );

        // CENTER

        JPanel center =
                new JPanel(
                        new GridLayout(
                                2,
                                3,
                                25,
                                25
                        )
                );

        center.setOpaque(false);

        center.add(
                createDashboardCard(
                        "SCORE",
                        "0",
                        "Current Score"
                )
        );

        center.add(
                createDashboardCard(
                        "BEST",
                        "0",
                        "Best Score"
                )
        );

        center.add(
                createDashboardCard(
                        "TIME",
                        "00:00",
                        "Game Time"
                )
        );

        center.add(
                createDashboardCard(
                        "MOVES",
                        "0",
                        "Total Moves"
                )
        );

        center.add(
                createDashboardCard(
                        "CARDS",
                        "0 / 8",
                        "Pairs Matched"
                )
        );

        center.add(
                createDashboardCard(
                        "PROGRESS",
                        "0%",
                        "Game Progress"
                )
        );

        dashboard.add(
                center,
                BorderLayout.CENTER
        );

        // BOTTOM

        JPanel bottom =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                20,
                                10
                        )
                );

        bottom.setOpaque(false);

        JButton startButton =
                createButton(
                        "START GAME"
                );

        JButton leaderboardButton =
                createButton(
                        "LEADERBOARD"
                );

        JButton exitButton =
                createButton(
                        "EXIT"
                );

        startButton.addActionListener(
                e -> showDifficultyDialog()
        );

        leaderboardButton.addActionListener(
                e -> JOptionPane.showMessageDialog(
                        frame,
                        "Leaderboard will be added here.",
                        "Leaderboard",
                        JOptionPane.INFORMATION_MESSAGE
                )
        );

        exitButton.addActionListener(
                e -> System.exit(0)
        );

        bottom.add(startButton);
        bottom.add(leaderboardButton);
        bottom.add(exitButton);

        dashboard.add(
                bottom,
                BorderLayout.SOUTH
        );

        frame.setContentPane(dashboard);

        frame.revalidate();
        frame.repaint();
    }

    // ================= DIFFICULTY =================

    private static void showDifficultyDialog() {

        String[] options = {
                "EASY - 4 x 4",
                "MEDIUM - 6 x 6",
                "HARD - 8 x 8"
        };

        String choice =
                (String) JOptionPane.showInputDialog(
                        frame,
                        "Select difficulty:",
                        "Choose Difficulty",
                        JOptionPane.QUESTION_MESSAGE,
                        null,
                        options,
                        options[0]
                );

        if (choice == null) {
            return;
        }

        int gridSize;

        if (choice.startsWith("EASY")) {

            gridSize = 4;

        } else if (choice.startsWith("MEDIUM")) {

            gridSize = 6;

        } else {

            gridSize = 8;
        }

        startMemoryGame(gridSize);
    }

    // ================= START GAME =================

    public static void startMemoryGame(
            int gridSize
    ) {

        MemoryGamePanel game =
                new MemoryGamePanel(
                        playerName,
                        gridSize
                );

        frame.setContentPane(game);

        frame.revalidate();
        frame.repaint();
    }

    // ================= DASHBOARD CARD =================

    private static JPanel createDashboardCard(
            String heading,
            String value,
            String description
    ) {

        JPanel card =
                new JPanel();

        card.setLayout(
                new BoxLayout(
                        card,
                        BoxLayout.Y_AXIS
                )
        );

        card.setBackground(
                Color.WHITE
        );

        card.setBorder(
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(
                                new Color(
                                        225,
                                        225,
                                        235
                                ),
                                2
                        ),
                        BorderFactory.createEmptyBorder(
                                25,
                                25,
                                25,
                                25
                        )
                )
        );

        JLabel headingLabel =
                new JLabel(heading);

        headingLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        headingLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        headingLabel.setForeground(
                new Color(
                        91,
                        82,
                        240
                )
        );

        JLabel valueLabel =
                new JLabel(value);

        valueLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        valueLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        34
                )
        );

        valueLabel.setForeground(
                new Color(
                        45,
                        45,
                        75
                )
        );

        JLabel descriptionLabel =
                new JLabel(description);

        descriptionLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        descriptionLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        descriptionLabel.setForeground(
                new Color(
                        120,
                        120,
                        145
                )
        );

        card.add(headingLabel);

        card.add(
                Box.createVerticalStrut(15)
        );

        card.add(valueLabel);

        card.add(
                Box.createVerticalStrut(10)
        );

        card.add(descriptionLabel);

        return card;
    }

    // ================= BUTTON =================

    private static JButton createButton(
            String text
    ) {

        JButton button =
                new JButton(text);

        button.setPreferredSize(
                new Dimension(
                        220,
                        55
                )
        );

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        16
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBackground(
                new Color(
                        91,
                        82,
                        240
                )
        );

        button.setFocusPainted(false);

        button.setBorder(
                BorderFactory.createEmptyBorder()
        );

        return button;
    }
}