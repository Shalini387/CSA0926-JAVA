package gui;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MemoryGamePanel extends JPanel {

    private final String playerName;

    private JLabel scoreLabel;
    private JLabel movesLabel;
    private JLabel timeLabel;
    private JLabel pairsLabel;

    private JPanel cardPanel;

    private List<String> cards;

    private JButton firstCard;
    private JButton secondCard;

    private boolean checking = false;

    private int score = 0;
    private int moves = 0;
    private int matchedPairs = 0;

    private Timer timer;
    private int seconds = 0;

    public MemoryGamePanel(String playerName) {

        this.playerName = playerName;

        setLayout(new BorderLayout(20, 20));

        setBackground(
                new Color(247, 247, 255)
        );

        setBorder(
                BorderFactory.createEmptyBorder(
                        25, 40, 25, 40
                )
        );

        createHeader();
        createGameBoard();
        startTimer();
    }

    // ================= HEADER =================

    private void createHeader() {

        JPanel header =
                new JPanel(new BorderLayout());

        header.setOpaque(false);

        JLabel title =
                new JLabel("MEMORY MATCH MANIA");

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        30
                )
        );

        title.setForeground(
                new Color(45, 45, 75)
        );

        JPanel stats =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.RIGHT,
                                25,
                                5
                        )
                );

        stats.setOpaque(false);

        scoreLabel =
                new JLabel("SCORE: 0");

        movesLabel =
                new JLabel("MOVES: 0");

        timeLabel =
                new JLabel("TIME: 00:00");

        pairsLabel =
                new JLabel("PAIRS: 0 / 8");

        Font statFont =
                new Font(
                        "Arial",
                        Font.BOLD,
                        15
                );

        scoreLabel.setFont(statFont);
        movesLabel.setFont(statFont);
        timeLabel.setFont(statFont);
        pairsLabel.setFont(statFont);

        stats.add(scoreLabel);
        stats.add(movesLabel);
        stats.add(timeLabel);
        stats.add(pairsLabel);

        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                stats,
                BorderLayout.EAST
        );

        add(
                header,
                BorderLayout.NORTH
        );
    }

    // ================= GAME BOARD =================

    private void createGameBoard() {

        cardPanel =
                new JPanel(
                        new GridLayout(
                                4,
                                4,
                                15,
                                15
                        )
                );

        cardPanel.setOpaque(false);

        createCards();

        add(
                cardPanel,
                BorderLayout.CENTER
        );
    }

    // ================= CREATE CARDS =================

    private void createCards() {

        cards =
                new ArrayList<>();

        String[] symbols = {
                "A", "B", "C", "D",
                "E", "F", "G", "H"
        };

        for (String symbol : symbols) {

            cards.add(symbol);
            cards.add(symbol);
        }

        Collections.shuffle(cards);

        for (int i = 0; i < cards.size(); i++) {

            JButton card =
                    createCardButton(i);

            cardPanel.add(card);
        }
    }

    // ================= CARD BUTTON =================

    private JButton createCardButton(int index) {

        JButton button =
                new JButton("?");

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        32
                )
        );

        // Correct method
        button.setFocusPainted(false);

        button.setBackground(
                new Color(91, 82, 240)
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBorder(
                BorderFactory.createLineBorder(
                        new Color(70, 65, 200),
                        2
                )
        );

        button.addActionListener(e -> {

            if (checking) {
                return;
            }

            if (button == firstCard) {
                return;
            }

            button.setText(
                    cards.get(index)
            );

            button.setEnabled(false);

            if (firstCard == null) {

                firstCard = button;

            } else {

                secondCard = button;

                moves++;

                movesLabel.setText(
                        "MOVES: " + moves
                );

                checkMatch();
            }
        });

        return button;
    }

    // ================= CHECK MATCH =================

    private void checkMatch() {

        checking = true;

        String first =
                firstCard.getText();

        String second =
                secondCard.getText();

        if (first.equals(second)) {

            score += 10;
            matchedPairs++;

            scoreLabel.setText(
                    "SCORE: " + score
            );

            pairsLabel.setText(
                    "PAIRS: " +
                    matchedPairs +
                    " / 8"
            );

            firstCard = null;
            secondCard = null;

            checking = false;

            if (matchedPairs == 8) {
                gameCompleted();
            }

        } else {

            Timer hideTimer =
                    new Timer(
                            700,
                            e -> {

                                firstCard.setText("?");
                                secondCard.setText("?");

                                firstCard.setEnabled(true);
                                secondCard.setEnabled(true);

                                firstCard = null;
                                secondCard = null;

                                checking = false;
                            }
                    );

            hideTimer.setRepeats(false);

            hideTimer.start();
        }
    }

    // ================= TIMER =================

    private void startTimer() {

        timer =
                new Timer(
                        1000,
                        e -> {

                            seconds++;

                            int minutes =
                                    seconds / 60;

                            int remainingSeconds =
                                    seconds % 60;

                            timeLabel.setText(
                                    String.format(
                                            "TIME: %02d:%02d",
                                            minutes,
                                            remainingSeconds
                                    )
                            );
                        }
                );

        timer.start();
    }

    // ================= GAME COMPLETE =================

    private void gameCompleted() {

        if (timer != null) {
            timer.stop();
        }

        JOptionPane.showMessageDialog(
                this,
                "Congratulations, " +
                        playerName +
                        "!\n\n" +
                        "Score: " +
                        score +
                        "\n" +
                        "Moves: " +
                        moves +
                        "\n" +
                        "Time: " +
                        timeLabel.getText().replace(
                                "TIME: ",
                                ""
                        ),
                "Game Completed",
                JOptionPane.INFORMATION_MESSAGE
        );
    }
}