package gui;

import app.Main;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MemoryGamePanel extends JPanel {

    private final String playerName;
    private final int gridSize;
    private final int totalPairs;

    private JLabel scoreLabel;
    private JLabel movesLabel;
    private JLabel timeLabel;
    private JLabel pairsLabel;
    private JLabel difficultyLabel;

    private JPanel cardPanel;

    private List<String> cards;

    private JButton firstCard;
    private JButton secondCard;

    private boolean checking = false;

    private int score = 0;
    private int moves = 0;
    private int matchedPairs = 0;

    private Timer timer;
    private int seconds = 0;

    public MemoryGamePanel(
            String playerName,
            int gridSize
    ) {

        this.playerName = playerName;
        this.gridSize = gridSize;

        totalPairs =
                (gridSize * gridSize) / 2;

        setLayout(
                new BorderLayout(
                        15,
                        15
                )
        );

        setBackground(
                new Color(
                        247,
                        247,
                        255
                )
        );

        setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        30,
                        20,
                        30
                )
        );

        createHeader();
        createGameBoard();
        createBottomPanel();
        startTimer();
    }

    // ================= HEADER =================

    private void createHeader() {

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setOpaque(false);

        JLabel title =
                new JLabel(
                        "MEMORY MATCH MANIA"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );

        title.setForeground(
                new Color(
                        45,
                        45,
                        75
                )
        );

        JLabel playerLabel =
                new JLabel(
                        "Player: " +
                        playerName
                );

        playerLabel.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );

        playerLabel.setForeground(
                new Color(
                        100,
                        100,
                        130
                )
        );

        JPanel titlePanel =
                new JPanel(
                        new GridLayout(
                                2,
                                1
                        )
                );

        titlePanel.setOpaque(false);

        titlePanel.add(title);
        titlePanel.add(playerLabel);

        difficultyLabel =
                new JLabel(
                        getDifficultyName()
                );

        difficultyLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        difficultyLabel.setForeground(
                new Color(
                        91,
                        82,
                        240
                )
        );

        scoreLabel =
                new JLabel("SCORE: 0");

        movesLabel =
                new JLabel("MOVES: 0");

        timeLabel =
                new JLabel("TIME: 00:00");

        pairsLabel =
                new JLabel(
                        "PAIRS: 0 / " +
                        totalPairs
                );

        Font statFont =
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                );

        scoreLabel.setFont(statFont);
        movesLabel.setFont(statFont);
        timeLabel.setFont(statFont);
        pairsLabel.setFont(statFont);

        JPanel stats =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.RIGHT,
                                15,
                                5
                        )
                );

        stats.setOpaque(false);

        stats.add(difficultyLabel);
        stats.add(scoreLabel);
        stats.add(movesLabel);
        stats.add(timeLabel);
        stats.add(pairsLabel);

        header.add(
                titlePanel,
                BorderLayout.WEST
        );

        header.add(
                stats,
                BorderLayout.EAST
        );

        add(
                header,
                BorderLayout.NORTH
        );
    }

    // ================= DIFFICULTY =================

    private String getDifficultyName() {

        if (gridSize == 4) {
            return "EASY";
        }

        if (gridSize == 6) {
            return "MEDIUM";
        }

        return "HARD";
    }

    // ================= GAME BOARD =================

    private void createGameBoard() {

        cardPanel =
                new JPanel(
                        new GridLayout(
                                gridSize,
                                gridSize,
                                8,
                                8
                        )
                );

        cardPanel.setOpaque(false);

        createCards();

        add(
                cardPanel,
                BorderLayout.CENTER
        );
    }

    // ================= CREATE CARDS =================

    private void createCards() {

        cards =
                new ArrayList<>();

        for (
                int i = 0;
                i < totalPairs;
                i++
        ) {

            String symbol =
                    String.valueOf(
                            (char) (
                                    'A' + i
                            )
                    );

            cards.add(symbol);
            cards.add(symbol);
        }

        Collections.shuffle(cards);

        for (
                int i = 0;
                i < cards.size();
                i++
        ) {

            JButton button =
                    createCardButton(i);

            cardPanel.add(button);
        }
    }

    // ================= CARD BUTTON =================

    private JButton createCardButton(
            int index
    ) {

        JButton button =
                new JButton("?");

        int fontSize = 28;

        if (gridSize == 6) {
            fontSize = 22;
        }

        if (gridSize == 8) {
            fontSize = 17;
        }

        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        fontSize
                )
        );

        button.setFocusPainted(false);

        button.setBackground(
                new Color(
                        91,
                        82,
                        240
                )
        );

        button.setForeground(
                Color.WHITE
        );

        button.setBorder(
                BorderFactory.createLineBorder(
                        new Color(
                                70,
                                65,
                                200
                        ),
                        1
                )
        );

        button.addActionListener(
                e -> {

                    if (checking) {
                        return;
                    }

                    if (button == firstCard) {
                        return;
                    }

                    button.setText(
                            cards.get(index)
                    );

                    button.setEnabled(false);

                    if (firstCard == null) {

                        firstCard = button;

                    } else {

                        secondCard = button;

                        moves++;

                        movesLabel.setText(
                                "MOVES: " +
                                moves
                        );

                        checkMatch();
                    }
                }
        );

        return button;
    }

    // ================= CHECK MATCH =================

    private void checkMatch() {

        checking = true;

        String first =
                firstCard.getText();

        String second =
                secondCard.getText();

        if (first.equals(second)) {

            score += 10;

            matchedPairs++;

            scoreLabel.setText(
                    "SCORE: " +
                    score
            );

            pairsLabel.setText(
                    "PAIRS: " +
                    matchedPairs +
                    " / " +
                    totalPairs
            );

            firstCard = null;
            secondCard = null;

            checking = false;

            if (
                    matchedPairs ==
                    totalPairs
            ) {

                gameCompleted();
            }

        } else {

            Timer hideTimer =
                    new Timer(
                            700,
                            e -> {

                                firstCard.setText("?");

                                secondCard.setText("?");

                                firstCard.setEnabled(true);

                                secondCard.setEnabled(true);

                                firstCard = null;
                                secondCard = null;

                                checking = false;
                            }
                    );

            hideTimer.setRepeats(false);

            hideTimer.start();
        }
    }

    // ================= BOTTOM PANEL =================

    private void createBottomPanel() {

        JPanel bottom =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                15,
                                5
                        )
                );

        bottom.setOpaque(false);

        JButton restartButton =
                new JButton(
                        "RESTART GAME"
                );

        JButton dashboardButton =
                new JButton(
                        "BACK TO DASHBOARD"
                );

        restartButton.setPreferredSize(
                new Dimension(
                        190,
                        45
                )
        );

        dashboardButton.setPreferredSize(
                new Dimension(
                        220,
                        45
                )
        );

        restartButton.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        dashboardButton.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );

        restartButton.setFocusPainted(false);

        dashboardButton.setFocusPainted(false);

        restartButton.addActionListener(
                e -> restartGame()
        );

        dashboardButton.addActionListener(
                e -> backToDashboard()
        );

        bottom.add(restartButton);
        bottom.add(dashboardButton);

        add(
                bottom,
                BorderLayout.SOUTH
        );
    }

    // ================= RESTART =================

    private void restartGame() {

        if (timer != null) {
            timer.stop();
        }

        score = 0;
        moves = 0;
        matchedPairs = 0;
        seconds = 0;

        firstCard = null;
        secondCard = null;

        checking = false;

        scoreLabel.setText(
                "SCORE: 0"
        );

        movesLabel.setText(
                "MOVES: 0"
        );

        timeLabel.setText(
                "TIME: 00:00"
        );

        pairsLabel.setText(
                "PAIRS: 0 / " +
                totalPairs
        );

        cardPanel.removeAll();

        createCards();

        cardPanel.revalidate();
        cardPanel.repaint();

        startTimer();
    }

    // ================= BACK TO DASHBOARD =================

    private void backToDashboard() {

        if (timer != null) {
            timer.stop();
        }

        Main.showDashboard();
    }

    // ================= TIMER =================

    private void startTimer() {

        timer =
                new Timer(
                        1000,
                        e -> {

                            seconds++;

                            int minutes =
                                    seconds / 60;

                            int remaining =
                                    seconds % 60;

                            timeLabel.setText(
                                    String.format(
                                            "TIME: %02d:%02d",
                                            minutes,
                                            remaining
                                    )
                            );
                        }
                );

        timer.start();
    }

    // ================= GAME COMPLETED =================

    private void gameCompleted() {

        if (timer != null) {
            timer.stop();
        }

        double accuracy = 0;

        if (moves > 0) {

            accuracy =
                    ((double) totalPairs /
                    moves) * 100.0;
        }

        if (accuracy > 100) {
            accuracy = 100;
        }

        int minutes =
                seconds / 60;

        int remainingSeconds =
                seconds % 60;

        String time =
                String.format(
                        "%02d:%02d",
                        minutes,
                        remainingSeconds
                );

        JPanel panel =
                new JPanel();

        panel.setLayout(
                new BoxLayout(
                        panel,
                        BoxLayout.Y_AXIS
                )
        );

        panel.setBorder(
                BorderFactory.createEmptyBorder(
                        15,
                        30,
                        15,
                        30
                )
        );

        JLabel title =
                new JLabel(
                        "GAME COMPLETED!"
                );

        title.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        28
                )
        );

        title.setForeground(
                new Color(
                        91,
                        82,
                        240
                )
        );

        JLabel player =
                new JLabel(
                        "Well done, " +
                        playerName +
                        "!"
                );

        player.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        player.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        18
                )
        );

        JLabel difficulty =
                new JLabel(
                        "Difficulty: " +
                        getDifficultyName()
                );

        JLabel scoreResult =
                new JLabel(
                        "Score: " +
                        score
                );

        JLabel movesResult =
                new JLabel(
                        "Moves: " +
                        moves
                );

        JLabel timeResult =
                new JLabel(
                        "Time: " +
                        time
                );

        JLabel accuracyResult =
                new JLabel(
                        String.format(
                                "Accuracy: %.1f%%",
                                accuracy
                        )
                );

        Font resultFont =
                new Font(
                        "Arial",
                        Font.PLAIN,
                        17
                );

        difficulty.setFont(resultFont);
        scoreResult.setFont(resultFont);
        movesResult.setFont(resultFont);
        timeResult.setFont(resultFont);
        accuracyResult.setFont(resultFont);

        difficulty.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        scoreResult.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        movesResult.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        timeResult.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        accuracyResult.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        panel.add(title);

        panel.add(
                Box.createVerticalStrut(12)
        );

        panel.add(player);

        panel.add(
                Box.createVerticalStrut(15)
        );

        panel.add(difficulty);

        panel.add(
                Box.createVerticalStrut(8)
        );

        panel.add(scoreResult);

        panel.add(
                Box.createVerticalStrut(8)
        );

        panel.add(movesResult);

        panel.add(
                Box.createVerticalStrut(8)
        );

        panel.add(timeResult);

        panel.add(
                Box.createVerticalStrut(8)
        );

        panel.add(accuracyResult);

        Object[] options = {
                "PLAY AGAIN",
                "BACK TO DASHBOARD"
        };

        int result =
                JOptionPane.showOptionDialog(
                        this,
                        panel,
                        "Game Results",
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.PLAIN_MESSAGE,
                        null,
                        options,
                        options[0]
                );

        if (result == 0) {

            restartGame();

        } else if (result == 1) {

            backToDashboard();
        }
    }
}