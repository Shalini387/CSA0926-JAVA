package gui;

import javax.swing.*;
import java.awt.*;

public class PlayerSetupPanel extends JPanel {

    private JTextField nameField;
    private JTextField ageField;

    public PlayerSetupPanel(Runnable startGame) {

        setLayout(new GridBagLayout());
        setBackground(new Color(247, 247, 255));

        JPanel card = new JPanel();
        card.setPreferredSize(new Dimension(600, 600));
        card.setBackground(Color.WHITE);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(
                        new Color(225, 225, 235), 2),
                BorderFactory.createEmptyBorder(
                        45, 55, 45, 55)
        ));

        JLabel title = new JLabel("MEMORY MATCH MANIA");
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        title.setFont(new Font("Arial", Font.BOLD, 34));
        title.setForeground(new Color(45, 45, 75));

        JLabel subtitle = new JLabel("Match. Remember. Think. Win!");
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        subtitle.setFont(new Font("Arial", Font.PLAIN, 18));
        subtitle.setForeground(new Color(110, 110, 145));

        card.add(title);
        card.add(Box.createVerticalStrut(10));
        card.add(subtitle);
        card.add(Box.createVerticalStrut(50));

        JLabel nameLabel = new JLabel("Player Name");
        nameLabel.setFont(new Font("Arial", Font.BOLD, 16));
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        nameField = new JTextField();
        nameField.setMaximumSize(new Dimension(450, 50));
        nameField.setFont(new Font("Arial", Font.PLAIN, 18));

        JLabel ageLabel = new JLabel("Age");
        ageLabel.setFont(new Font("Arial", Font.BOLD, 16));
        ageLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        ageField = new JTextField();
        ageField.setMaximumSize(new Dimension(450, 50));
        ageField.setFont(new Font("Arial", Font.PLAIN, 18));

        JLabel errorLabel = new JLabel(" ");
        errorLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        errorLabel.setForeground(new Color(220, 60, 60));
        errorLabel.setFont(new Font("Arial", Font.BOLD, 14));

        JButton startButton = new JButton("START GAME");
        startButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        startButton.setPreferredSize(new Dimension(240, 60));
        startButton.setMaximumSize(new Dimension(240, 60));
        startButton.setFont(new Font("Arial", Font.BOLD, 18));
        startButton.setForeground(Color.WHITE);
        startButton.setBackground(new Color(91, 82, 240));
        startButton.setFocusPainted(false);
        startButton.setBorder(BorderFactory.createEmptyBorder());

        startButton.addActionListener(e -> {

            String name = nameField.getText().trim();
            String ageText = ageField.getText().trim();

            if (name.isEmpty()) {
                errorLabel.setText("Name is required");
                return;
            }

            if (ageText.isEmpty()) {
                errorLabel.setText("Age is required");
                return;
            }

            try {

                int age = Integer.parseInt(ageText);

                if (age < 1 || age > 100) {
                    errorLabel.setText("Age must be between 1 and 100");
                    return;
                }

                errorLabel.setText("");

                startGame.run();

            } catch (NumberFormatException ex) {

                errorLabel.setText("Please enter a valid age");
            }
        });

        card.add(nameLabel);
        card.add(Box.createVerticalStrut(8));
        card.add(nameField);

        card.add(Box.createVerticalStrut(25));

        card.add(ageLabel);
        card.add(Box.createVerticalStrut(8));
        card.add(ageField);

        card.add(Box.createVerticalStrut(20));
        card.add(errorLabel);

        card.add(Box.createVerticalStrut(25));
        card.add(startButton);

        add(card);
    }
}